﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using Microsoft.Office.Interop.Excel;
using ESRI.ArcGIS.Geodatabase;
using System.Text.RegularExpressions;


namespace SLD_MV_Rings_Tool
{
   public class DrawNetworks
    {
        internal void DrawPowerCableNetWork(List<StartEndCellAddressesValues> lstPowerRingData, Microsoft.Office.Interop.Excel.Range ExcelRange, Microsoft.Office.Interop.Excel.Worksheet WorkSheet)
        {
            try
            {
                for (int i = 0; i < lstPowerRingData.Count; i++)
                {
                    string strStartCellValue = lstPowerRingData[i].StartValue;
                    string strEndCellValue = lstPowerRingData[i].EndValue;

                    int iStartRowAddr = Int32.Parse(lstPowerRingData[i].StartValuePosition.Split(',')[0]);
                    int iStartClmAddr = Int32.Parse(lstPowerRingData[i].StartValuePosition.Split(',')[1]);

                    int iEndRowAddr = Int32.Parse(lstPowerRingData[i].EndValuePostion.Split(',')[0]);
                    int iEndClmAddr = Int32.Parse(lstPowerRingData[i].EndValuePostion.Split(',')[1]);

                    (ExcelRange.Cells[iStartRowAddr, iStartClmAddr] as Microsoft.Office.Interop.Excel.Range).Value2 = strStartCellValue;
                    Microsoft.Office.Interop.Excel.Range cells = ExcelRange.Cells[iStartRowAddr, iStartClmAddr];
                    WorkSheet.Cells[iStartRowAddr, iStartClmAddr].Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                    WorkSheet.Cells[iStartRowAddr, iStartClmAddr].Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                    Microsoft.Office.Interop.Excel.Borders border = cells.Borders;
                    border.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
                    border.Weight = 3d;

                    (ExcelRange.Cells[iEndRowAddr, iEndClmAddr] as Microsoft.Office.Interop.Excel.Range).Value2 = strEndCellValue;
                    Microsoft.Office.Interop.Excel.Range Rcells = ExcelRange.Cells[iEndRowAddr, iEndClmAddr];
                    WorkSheet.Cells[iEndRowAddr, iEndClmAddr].Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                    WorkSheet.Cells[iEndRowAddr, iEndClmAddr].Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                    Microsoft.Office.Interop.Excel.Borders Bborder = Rcells.Borders;
                    Bborder.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
                    Bborder.Weight = 3d;


                    float lngXStart = (float)(WorkSheet.Cells[iStartRowAddr, iStartClmAddr].Left + WorkSheet.Cells[iStartRowAddr, iStartClmAddr].Width / 2);
                    float lngXEnd = (float)(WorkSheet.Cells[iEndRowAddr, iEndClmAddr].Left + WorkSheet.Cells[iEndRowAddr, iEndClmAddr].Width / 2);
                    float lngYStart = (float)(WorkSheet.Cells[iStartRowAddr, iStartClmAddr].Top + WorkSheet.Cells[iStartRowAddr, iStartClmAddr].Height / 2);
                    float lngYEnd = (float)(WorkSheet.Cells[iEndRowAddr, iEndClmAddr].Top + WorkSheet.Cells[iEndRowAddr, iEndClmAddr].Height / 2);
                    float x1 = 0;
                    float y1 = 0;
                    float x2 = 0;
                    float y2 = 0;

                    GetStartCellRightMid(lngXStart, lngYStart, iStartRowAddr, iStartClmAddr, WorkSheet,ref x1, ref y1);
                    GetEndCellLeftMid(lngXEnd, lngYEnd, iEndRowAddr, iEndClmAddr, WorkSheet ,ref x2, ref y2);

                    Shape objLineShape = WorkSheet.Shapes.AddLine(x1, y1, x2, y2);
                    objLineShape.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objLineShape.Line.Weight = 2;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetEndCellLeftMid(float lngXEnd, float lngYEnd, int iEndRowAddr, int iEndClmAddr, Microsoft.Office.Interop.Excel.Worksheet WorkSheet, ref float x2, ref float y2)
        {
            try
            {
                x2 = (float)(lngXEnd - (WorkSheet.Cells[iEndRowAddr, iEndClmAddr].Width / 2));
                y2 = (float)(lngYEnd);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetStartCellRightMid(float lngXStart, float lngYStart, int iStartRowAddr, int iStartClmAddr, Microsoft.Office.Interop.Excel.Worksheet WorkSheet, ref float x1, ref float y1)
        {  
            try
            {
                x1 = (float)(lngXStart + (WorkSheet.Cells[iStartRowAddr, iStartClmAddr].Width / 2));
                y1 = (float)(lngYStart);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        internal void DrawFiberCableNetWork(List<StartEndCellAddressesValues> lstConnectedNodes, List<StartEndCellAddressesValues> lstNotConnectedNodes, List<StartEndCellAddressesValues> lstNewlyConnectedNodes, List<StartEndCellAddressesValues> lstCoonectedWithInCircuit, Range ExcelRange, Worksheet WorkSheet, IFeatureClass pF_FiberCable)
        {
            try
            {
                //Connected Cables
                for (int i = 0; i < lstConnectedNodes.Count; i++)
                {
                    float lngXStart = 0;
                    float lngXEnd = 0;
                    float lngYStart = 0;
                    float lngYEnd = 0;
                    int iCnnStartRowAddr = 0;
                    int iCnnStartClmAddr = 0;
                    int iCnnEndRowAddr = 0;
                    int iCnnEndClmAddr = 0;
                    string strFromPointUpdated = string.Empty;
                    string strToPointUpdated = string.Empty;

                    DrawAllConnectedNodesWithFiber(lstConnectedNodes[i], ref strFromPointUpdated, ref strToPointUpdated, ref iCnnStartRowAddr, ref iCnnStartClmAddr, ref iCnnEndRowAddr, ref iCnnEndClmAddr, ref lngXStart, ref lngXEnd, ref lngYStart, ref lngYEnd, WorkSheet, ExcelRange);
                    
                   
                    float x1 = 0;
                    float y1 = 0;
                    float x2 = 0;
                    float y2 = 0;

                    GetStartCellConnected(lngXStart, lngYStart, iCnnStartRowAddr, iCnnStartClmAddr, WorkSheet, ref x1, ref y1);
                    GetEndCellConnected(lngXEnd, lngYEnd, iCnnEndRowAddr, iCnnEndClmAddr, WorkSheet, ref x2, ref y2);

                    float fCellHeight = (float)(WorkSheet.Cells[iCnnStartRowAddr, iCnnStartClmAddr].Height / 6);

                    GetNumberCables(strFromPointUpdated, strToPointUpdated, pF_FiberCable, WorkSheet, x1, y1, x2, y2, fCellHeight, iCnnStartRowAddr, iCnnStartClmAddr);
                }

                //Not Connected Nodes
                for (int i = 0; i < lstNotConnectedNodes.Count; i++)
                {
                    float lngXStart = 0;
                    float lngXEnd = 0;
                    float lngYStart = 0;
                    float lngYEnd = 0;

                    int iNotCnnStartRowAddr = 0;
                    int iNotCnnStartClmAddr = 0;
                    int iNotCnnEndRowAddr = 0;
                    int iNotCnnEndClmAddr = 0;

                    string strFromPointUpdated = string.Empty;
                    string strToPointUpdated = string.Empty;

                    DrawAllConnectedNodesWithFiber(lstNotConnectedNodes[i], ref strFromPointUpdated, ref strToPointUpdated, ref iNotCnnStartRowAddr, ref iNotCnnStartClmAddr, ref iNotCnnEndRowAddr, ref iNotCnnEndClmAddr, ref lngXStart, ref lngXEnd, ref lngYStart, ref lngYEnd, WorkSheet, ExcelRange);


                    float x1 = 0;
                    float y1 = 0;
                    float x2 = 0;
                    float y2 = 0;

                    GetStartCellConnected(lngXStart, lngYStart, iNotCnnStartRowAddr, iNotCnnStartClmAddr, WorkSheet, ref x1, ref y1);
                    GetEndCellConnected(lngXEnd, lngYEnd, iNotCnnEndRowAddr, iNotCnnEndClmAddr, WorkSheet, ref x2, ref y2);

                    Shape objNoFiberShape = WorkSheet.Shapes.AddLine(x1, y1, x2, y2);
                    objNoFiberShape.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objNoFiberShape.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineDash;
                    objNoFiberShape.Line.Weight = 1;
                }


                //Newly Connected Nodes
                for (int i = 0; i < lstNewlyConnectedNodes.Count; i++)
                {
                    float lngXStart = 0;
                    float lngXEnd = 0;
                    float lngYStart = 0;
                    float lngYEnd = 0;
                    int iNewlyStartRowAddr = 0;
                    int iNewlyStartClmAddr = 0;
                    int iNewlyEndRowAddr = 0;
                    int iNewlyEndClmAddr = 0;
                    string strFromPointUpdated = string.Empty;
                    string strToPointUpdated = string.Empty;
                    DrawAllConnectedNodesWithFiber(lstNewlyConnectedNodes[i], ref strFromPointUpdated, ref strToPointUpdated, ref iNewlyStartRowAddr, ref iNewlyStartClmAddr, ref iNewlyEndRowAddr, ref iNewlyEndClmAddr, ref lngXStart, ref lngXEnd, ref lngYStart, ref lngYEnd, WorkSheet, ExcelRange);
                    float fCellHeight = (float)(WorkSheet.Cells[iNewlyStartRowAddr, iNewlyStartClmAddr].Height);
                    float x1 = 0;
                    float y1 = 0;
                    float x2 = 0;
                    float y2 = 0;

                    GetStartCellMiddleBottom(lngXStart, lngYStart, iNewlyStartRowAddr, iNewlyStartClmAddr, WorkSheet, ref x1, ref y1);
                    GetEndCellLeftSplits(lngXEnd, lngYEnd, iNewlyEndRowAddr, iNewlyEndClmAddr, WorkSheet, ref x2, ref y2);

                    IQueryFilter qFilter = new QueryFilterClass();
                    qFilter.WhereClause = "CABLENAME LIKE '%" + strFromPointUpdated + "%' And CABLENAME LIKE '%" + strToPointUpdated + "%'"; ;
                    int intPLRowCount = pF_FiberCable.FeatureCount(qFilter);
                    if (intPLRowCount > 0)
                    {
                        float flGapHeight = fCellHeight / (intPLRowCount + 1);
                        for (int iLinesCounter = 0; iLinesCounter < intPLRowCount; iLinesCounter++)
                        {
                            Shape objLineShape = WorkSheet.Shapes.AddLine(x1, y1, x2, (y2 + (flGapHeight * (iLinesCounter + 1))));
                            objLineShape.Line.ForeColor.RGB = Color.Black.ToArgb();
                            objLineShape.Line.Weight = 1;
                        }
                    } 
                }

                //connected with in a circuit
                for (int i = 0; i < lstCoonectedWithInCircuit.Count; i++)
                {
                    float lngXStart = 0;
                    float lngXEnd = 0;
                    float lngYStart = 0;
                    float lngYEnd = 0;

                    int iInsideStartRowAddr = 0;
                    int iInsideStartClmAddr = 0;
                    int iInsideEndRowAddr = 0;
                    int iInsideEndClmAddr = 0;

                    string strFromPointUpdated = string.Empty;
                    string strToPointUpdated = string.Empty;

                    DrawAllConnectedNodesWithFiber(lstCoonectedWithInCircuit[i], ref strFromPointUpdated, ref strToPointUpdated, ref iInsideStartRowAddr, ref iInsideStartClmAddr, ref iInsideEndRowAddr, ref iInsideEndClmAddr, ref lngXStart, ref lngXEnd, ref lngYStart, ref lngYEnd, WorkSheet, ExcelRange);
                    CheckAndDrawWithInNetWork(strFromPointUpdated, strToPointUpdated,iInsideStartRowAddr, iInsideStartClmAddr, iInsideEndRowAddr, iInsideEndClmAddr, lngXStart, lngXEnd, lngYStart, lngYEnd, WorkSheet, pF_FiberCable);

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetNumberCables(string strFromPointUpdated, string strToPointUpdated, IFeatureClass pF_FiberCable, Worksheet sh, float x1, float y1, float x2, float y2, float fCellHeight, int rowCell_S,int ColumnCell_S)
        {
            try
            {

                IQueryFilter qFilter = new QueryFilterClass();
                qFilter.WhereClause = "CABLENAME LIKE '%" + strFromPointUpdated + "%' And CABLENAME LIKE '%" + strToPointUpdated + "%'"; ;
                int intPLRowCount = pF_FiberCable.FeatureCount(qFilter);
                if (intPLRowCount == 0)
                {
                    Shape objLineShape = sh.Shapes.AddLine(x1, y1, x2, y2);
                    objLineShape.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objLineShape.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineDash;
                    objLineShape.Line.Weight = 1;
                }
                else if (intPLRowCount == 1)
                {
                    Shape objLineShape = sh.Shapes.AddLine(Convert.ToSingle(x1), y1, x2, y2);
                    objLineShape.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objLineShape.Line.Weight = 1;
                }
                else if (intPLRowCount == 2)
                {
                    Range cellrange = sh.Cells[(rowCell_S), (ColumnCell_S + 1)];
                    cellrange.Select();

                    Shape objLineShape = sh.Shapes.AddLine(Convert.ToSingle(x1), (y1 + fCellHeight), x2, (y2 + fCellHeight));
                    objLineShape.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objLineShape.Line.Weight = 1;

                    Shape objLineShapeD = sh.Shapes.AddLine(Convert.ToSingle(x1), (y1 - fCellHeight), x2, (y2 - fCellHeight));
                    objLineShapeD.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objLineShapeD.Line.Weight = 1;
                }
                else
                {
                    Shape objLineShape = sh.Shapes.AddLine(Convert.ToSingle(x1), y1, x2, y2);
                    objLineShape.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objLineShape.Line.Weight = 1;
                    sh.Cells[(rowCell_S - 1), (ColumnCell_S + 1)].Value = ">2 Cables";
                }

            }
            catch
            {
                throw;
            }
        }

        private void GetEndCellConnected(float lngXEnd, float lngYEnd, int iCnnEndRowAddr, int iCnnEndClmAddr, Worksheet WorkSheet, ref float x2, ref float y2)
        {
            try
            {
                x2 = (float)(lngXEnd - (WorkSheet.Cells[iCnnEndRowAddr, iCnnEndClmAddr].Width / 2));
                y2 = (float)(lngYEnd);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetStartCellConnected(float lngXStart, float lngYStart, int iCnnStartRowAddr, int iCnnStartClmAddr, Worksheet WorkSheet, ref float x1, ref float y1)
        {
            try
            {
                x1 = (float)(lngXStart + (WorkSheet.Cells[iCnnStartRowAddr, iCnnStartRowAddr].Width / 2));
                y1 = (float)(lngYStart);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CheckAndDrawWithInNetWork(string strFromPointUpdated, string strToPointUpdated, int rowCell_S, int ColumnCell_S, int rowCell_E, int ColumnCell_E, float lngXStart, float lngXEnd, float lngYStart, float lngYEnd, Worksheet sh, IFeatureClass pF_FiberCable)
        {
            float fCellWidth = (float)(sh.Cells[rowCell_S, ColumnCell_S].Width);

            IQueryFilter qFilter = new QueryFilterClass();
            qFilter.WhereClause = "CABLENAME LIKE '%" + strFromPointUpdated + "%' And CABLENAME LIKE '%" + strToPointUpdated + "%'"; ;
            int intPLRowCount = pF_FiberCable.FeatureCount(qFilter);

            if (rowCell_S == rowCell_E)
            {
                if (intPLRowCount == 0)
                {
                    float x = (float)(lngXStart);
                    float y = (float)(lngYStart + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2));
                    float x1 = (float)(lngXStart);
                    float y1 = (float)(lngYStart + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2) + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2));
                    Shape objLineShape = sh.Shapes.AddLine(Convert.ToSingle(x), y, x1, y1);
                    objLineShape.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objLineShape.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineDash;
                    objLineShape.Line.Weight = 1;

                    float x2 = (float)(lngXStart);
                    float y2 = (float)(lngYStart + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2) + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2));
                    float x3 = (float)(lngXEnd);
                    float y3 = (float)(lngYEnd + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2) + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                    Shape objLineShape1 = sh.Shapes.AddLine(Convert.ToSingle(x2), y2, x3, y3);
                    objLineShape1.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objLineShape1.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineDash;
                    objLineShape1.Line.Weight = 1;

                    float x4 = (float)(lngXEnd);
                    float y4 = (float)(lngYEnd + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2) + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                    float x5 = (float)(lngXEnd);
                    float y5 = (float)(lngYEnd + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                    Shape objLineShape2 = sh.Shapes.AddLine(Convert.ToSingle(x4), y4, x5, y5);
                    objLineShape2.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objLineShape2.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineDash;
                    objLineShape2.Line.Weight = 1;
                }
                else if (intPLRowCount > 0)
                {
                    float x = (float)(lngXStart);
                    float y = (float)(lngYStart + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2));
                    float x1 = (float)(lngXStart);
                    float y1 = (float)(lngYStart + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2) + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2));
                    Shape objLineShape = sh.Shapes.AddLine(Convert.ToSingle(x), y, x1, y1);
                    objLineShape.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objLineShape.Line.Weight = 1;

                    float x2 = (float)(lngXStart);
                    float y2 = (float)(lngYStart + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2) + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2));
                    float x3 = (float)(lngXEnd);
                    float y3 = (float)(lngYEnd + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2) + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                    Shape objLineShape1 = sh.Shapes.AddLine(Convert.ToSingle(x2), y2, x3, y3);
                    objLineShape1.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objLineShape1.Line.Weight = 1;

                    float x4 = (float)(lngXEnd);
                    float y4 = (float)(lngYEnd + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2) + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));

                    float flGapWidth = fCellWidth / (intPLRowCount + 1);
                    for (int iLinesCounter = 0; iLinesCounter < intPLRowCount; iLinesCounter++)
                    {
                        float x5 = (float)((lngXEnd - (sh.Cells[rowCell_E, ColumnCell_E].Width / 2)) + (flGapWidth * (iLinesCounter + 1)));
                        float y5 = (float)(lngYEnd + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                        Shape objLineShape2 = sh.Shapes.AddLine(Convert.ToSingle(x4), y4, x5, y5);
                        objLineShape2.Line.ForeColor.RGB = Color.Black.ToArgb();
                        objLineShape2.Line.Weight = 1;
                    }


                }
            }
            else if (rowCell_S > rowCell_E)
            {
                float x = (float)(lngXStart);
                float y = (float)(lngYStart - (sh.Cells[rowCell_S, ColumnCell_S].Height / 2));
                float x1 = (float)(lngXStart);
                float y1 = (float)(lngYStart - (sh.Cells[rowCell_S, ColumnCell_S].Height / 2) - (sh.Cells[rowCell_S, ColumnCell_S].Height / 2));
                Shape objLineShape = sh.Shapes.AddLine(Convert.ToSingle(x), y, x1, y1);
                objLineShape.Line.ForeColor.RGB = Color.Black.ToArgb();
                objLineShape.Line.Weight = 1;

                if (intPLRowCount == 0)
                {
                    objLineShape.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineDash;

                    float x2 = (float)(lngXStart);
                    float y2 = (float)(lngYStart - (sh.Cells[rowCell_S, ColumnCell_S].Height / 2) - (sh.Cells[rowCell_S, ColumnCell_S].Height / 2));
                    float x3 = (float)(lngXEnd);
                    float y3 = (float)(lngYEnd + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2) + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                    Shape objLineShape1 = sh.Shapes.AddLine(Convert.ToSingle(x2), y2, x3, y3);
                    objLineShape1.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objLineShape1.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineDash;
                    objLineShape1.Line.Weight = 1;

                    float x4 = (float)(lngXEnd);
                    float y4 = (float)(lngYEnd + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2) + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                    float x5 = (float)(lngXEnd);
                    float y5 = (float)(lngYEnd + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                    Shape objLineShape2 = sh.Shapes.AddLine(Convert.ToSingle(x4), y4, x5, y5);
                    objLineShape2.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objLineShape2.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineDash;
                    objLineShape2.Line.Weight = 1;
                }
                else if (intPLRowCount > 0)
                {
                    float flGapWidth = fCellWidth / (intPLRowCount + 1);
                    for (int iLinesCounter = 0; iLinesCounter < intPLRowCount; iLinesCounter++)
                    {
                        float x2 = (float)(lngXStart);
                        float y2 = (float)(lngYStart - (sh.Cells[rowCell_S, ColumnCell_S].Height / 2) - (sh.Cells[rowCell_S, ColumnCell_S].Height / 2));
                        float x3 = (float)((lngXEnd - (sh.Cells[rowCell_E, ColumnCell_E].Width / 2)) + (flGapWidth * (iLinesCounter + 1)));
                        float y3 = (float)(lngYEnd + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2) + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                        Shape objLineShape1 = sh.Shapes.AddLine(Convert.ToSingle(x2), y2, x3, y3);
                        objLineShape1.Line.ForeColor.RGB = Color.Black.ToArgb();
                        objLineShape1.Line.Weight = 1;

                        float x4 = (float)((lngXEnd - (sh.Cells[rowCell_E, ColumnCell_E].Width / 2)) + (flGapWidth * (iLinesCounter + 1)));
                        float y4 = (float)(lngYEnd + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2) + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                        float x5 = (float)((lngXEnd - (sh.Cells[rowCell_E, ColumnCell_E].Width / 2)) + (flGapWidth * (iLinesCounter + 1)));
                        float y5 = (float)(lngYEnd + (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                        Shape objLineShape2 = sh.Shapes.AddLine(Convert.ToSingle(x4), y4, x5, y5);
                        objLineShape2.Line.ForeColor.RGB = Color.Black.ToArgb();
                        objLineShape2.Line.Weight = 1;

                    }
                }
            }
            else if (rowCell_S < rowCell_E)
            {
                float x = (float)(lngXStart);
                float y = (float)(lngYStart + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2));
                float x1 = (float)(lngXStart);
                float y1 = (float)(lngYStart + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2) + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2));
                Shape objLineShape = sh.Shapes.AddLine(Convert.ToSingle(x), y, x1, y1);
                objLineShape.Line.ForeColor.RGB = Color.Black.ToArgb();
                objLineShape.Line.Weight = 1;

                if (intPLRowCount == 0)
                {
                    objLineShape.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineDash;

                    float x2 = (float)(lngXStart);
                    float y2 = (float)(lngYStart + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2) + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2));
                    float x3 = (float)(lngXEnd);
                    float y3 = (float)(lngYEnd - (sh.Cells[rowCell_E, ColumnCell_E].Height / 2) - (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                    Shape objLineShape1 = sh.Shapes.AddLine(Convert.ToSingle(x2), y2, x3, y3);
                    objLineShape1.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objLineShape1.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineDash;
                    objLineShape1.Line.Weight = 1;

                    float x4 = (float)(lngXEnd);
                    float y4 = (float)(lngYEnd - (sh.Cells[rowCell_E, ColumnCell_E].Height / 2) - (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                    float x5 = (float)(lngXEnd);
                    float y5 = (float)(lngYEnd - (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                    Shape objLineShape2 = sh.Shapes.AddLine(Convert.ToSingle(x4), y4, x5, y5);
                    objLineShape2.Line.ForeColor.RGB = Color.Black.ToArgb();
                    objLineShape2.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineDash;
                    objLineShape2.Line.Weight = 1;
                }
                else if (intPLRowCount > 0)
                {
                    float flGapWidth = fCellWidth / (intPLRowCount + 1);
                    for (int iLinesCounter = 0; iLinesCounter < intPLRowCount; iLinesCounter++)
                    {
                        float x2 = (float)(lngXStart);
                        float y2 = (float)(lngYStart + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2) + (sh.Cells[rowCell_S, ColumnCell_S].Height / 2));
                        float x3 = (float)((lngXEnd - (sh.Cells[rowCell_E, ColumnCell_E].Width / 2)) + (flGapWidth * (iLinesCounter + 1)));
                        float y3 = (float)(lngYEnd - (sh.Cells[rowCell_E, ColumnCell_E].Height / 2) - (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                        Shape objLineShape1 = sh.Shapes.AddLine(Convert.ToSingle(x2), y2, x3, y3);
                        objLineShape1.Line.ForeColor.RGB = Color.Black.ToArgb();
                        objLineShape1.Line.Weight = 1;

                        float x4 = (float)((lngXEnd - (sh.Cells[rowCell_E, ColumnCell_E].Width / 2)) + (flGapWidth * (iLinesCounter + 1)));
                        float y4 = (float)(lngYEnd - (sh.Cells[rowCell_E, ColumnCell_E].Height / 2) - (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                        float x5 = (float)((lngXEnd - (sh.Cells[rowCell_E, ColumnCell_E].Width / 2)) + (flGapWidth * (iLinesCounter + 1)));
                        float y5 = (float)(lngYEnd - (sh.Cells[rowCell_E, ColumnCell_E].Height / 2));
                        Shape objLineShape2 = sh.Shapes.AddLine(Convert.ToSingle(x4), y4, x5, y5);
                        objLineShape2.Line.ForeColor.RGB = Color.Black.ToArgb();
                        objLineShape2.Line.Weight = 1;
                    }
                }

            }
        }

        private void DrawAllConnectedNodesWithFiber(StartEndCellAddressesValues lstALLTypeConnectedNodes, ref string strFromPointUpdated, ref string strToPointUpdated, ref int iAllStartRowAddr, ref int iAllStartClmAddr, ref int iAllEndRowAddr, ref int iAllEndClmAddr, ref float lngXStart, ref float lngXEnd, ref float lngYStart, ref float lngYEnd, Worksheet WorkSheet, Range ExcelRange)
        {

            string strAllStartCellValue = lstALLTypeConnectedNodes.StartValue.Split(',')[0];
            string strAllEndCellValue = lstALLTypeConnectedNodes.EndValue;

            strFromPointUpdated = GetUpdatedValues(strAllStartCellValue);
            strToPointUpdated = GetUpdatedValues(strAllEndCellValue);

            iAllStartRowAddr = Int32.Parse(lstALLTypeConnectedNodes.StartValuePosition.Split(',')[0]);
            iAllStartClmAddr = Int32.Parse(lstALLTypeConnectedNodes.StartValuePosition.Split(',')[1]);
            iAllEndRowAddr = Int32.Parse(lstALLTypeConnectedNodes.EndValuePostion.Split(',')[0]);
            iAllEndClmAddr = Int32.Parse(lstALLTypeConnectedNodes.EndValuePostion.Split(',')[1]);


            (ExcelRange.Cells[iAllStartRowAddr, iAllStartClmAddr] as Microsoft.Office.Interop.Excel.Range).Value2 = strAllStartCellValue;
            Microsoft.Office.Interop.Excel.Range cells = ExcelRange.Cells[iAllStartRowAddr, iAllStartClmAddr];
            WorkSheet.Cells[iAllStartRowAddr, iAllStartClmAddr].Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
            WorkSheet.Cells[iAllStartRowAddr, iAllStartClmAddr].Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
            Microsoft.Office.Interop.Excel.Borders border = cells.Borders;
            border.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
            border.Weight = 3d;

            (ExcelRange.Cells[iAllEndRowAddr, iAllEndClmAddr] as Microsoft.Office.Interop.Excel.Range).Value2 = strAllEndCellValue;
            Microsoft.Office.Interop.Excel.Range Rcells = ExcelRange.Cells[iAllEndRowAddr, iAllEndClmAddr];
            WorkSheet.Cells[iAllEndRowAddr, iAllEndClmAddr].Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
            WorkSheet.Cells[iAllEndRowAddr, iAllEndClmAddr].Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
            Microsoft.Office.Interop.Excel.Borders Bborder = Rcells.Borders;
            Bborder.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
            Bborder.Weight = 3d;

            lngXStart = (float)(WorkSheet.Cells[iAllStartRowAddr, iAllStartClmAddr].Left + WorkSheet.Cells[iAllStartRowAddr, iAllStartClmAddr].Width / 2);
            lngXEnd = (float)(WorkSheet.Cells[iAllEndRowAddr, iAllEndClmAddr].Left + WorkSheet.Cells[iAllEndRowAddr, iAllEndClmAddr].Width / 2);
            lngYStart = (float)(WorkSheet.Cells[iAllStartRowAddr, iAllStartClmAddr].Top + WorkSheet.Cells[iAllStartRowAddr, iAllStartClmAddr].Height / 2);
            lngYEnd = (float)(WorkSheet.Cells[iAllEndRowAddr, iAllEndClmAddr].Top + WorkSheet.Cells[iAllEndRowAddr, iAllEndClmAddr].Height / 2);
        }

        private string GetUpdatedValues(string TypeOfPoint)
        {
            try
            {
                string strFromPointUpdated = string.Empty;
                string strAlpha = Regex.Replace(TypeOfPoint, "[^a-zA-Z]", "");
                string strDigits = Regex.Replace(TypeOfPoint, "[^0-9]", "");
                if (strAlpha == "PT" || strAlpha == "PS")
                {
                    if (TypeOfPoint.Length != 6)
                    {
                        var newString = strDigits.PadLeft(4, '0');
                        strFromPointUpdated = strAlpha + newString;
                    }
                    else
                    {
                        strFromPointUpdated = TypeOfPoint;
                    }
                }
                else
                {    
                    if (strDigits != "")
                    {
                        strFromPointUpdated = strAlpha + "M" + strDigits;
                    }
                    else
                    {
                        strFromPointUpdated = strAlpha;
                    }


                }
                return strFromPointUpdated;

            }
            catch
            {
                return null;
            }
        }

        private void GetEndCellLeftSplits(float lngXEnd, float lngYEnd, int iNewlyEndRowAddr, int iNewlyEndClmAddr, Worksheet WorkSheet, ref float x2, ref float y2)
        {
            try
            {
                x2 = (float)(lngXEnd - (WorkSheet.Cells[iNewlyEndRowAddr, iNewlyEndClmAddr].Width / 2));
                y2 = (float)(lngYEnd - (WorkSheet.Cells[iNewlyEndRowAddr, iNewlyEndClmAddr].Height / 2));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetStartCellMiddleBottom(float lngXStart, float lngYStart, int iNewlyStartRowAddr, int iNewlyStartClmAddr, Worksheet WorkSheet, ref float x1, ref float y1)
        {
            try
            {
                x1 = (float)(lngXStart);
                y1 = (float)(lngYStart + (WorkSheet.Cells[iNewlyStartRowAddr, iNewlyStartClmAddr].Height / 2));

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        internal void DrawDefinations(Dictionary<string, string> dicCellValueAddrress, Range ExcelRange, Worksheet WorkSheet)
        {
            try
            {
                for (int i = 0; i < dicCellValueAddrress.Count; i++)
                {
                    string strValue = dicCellValueAddrress.ToArray()[i].Value;
                    int iRowVal = Int32.Parse(dicCellValueAddrress.ToArray()[i].Key.Split(',')[0]);
                    int iClmVal = Int32.Parse(dicCellValueAddrress.ToArray()[i].Key.Split(',')[1]);
                    (ExcelRange.Cells[iRowVal, iClmVal] as Microsoft.Office.Interop.Excel.Range).Value2 = strValue;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        internal void DrawLegend(int iMax, Range existingXlRange, Worksheet sh)
        {
            try
            {
                int iMaxNo = iMax + 3;
                int iincMax = iMaxNo + 6;

                existingXlRange = sh.Application.get_Range("B" + iMaxNo, "E" + iincMax);
                existingXlRange.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom].Color = Color.Black.ToArgb();
                existingXlRange.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom].Weight = 3d;
                existingXlRange.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeLeft].Color = Color.Black.ToArgb();
                existingXlRange.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeLeft].Weight = 3d;
                existingXlRange.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeRight].Color = Color.Black.ToArgb();
                existingXlRange.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeRight].Weight = 3d;
                existingXlRange.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeTop].Color = Color.Black.ToArgb();
                existingXlRange.Borders[Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeTop].Weight = 3d;



                //Green Line
                int iCellX = iMaxNo + 1;
                sh.Cells[iCellX, 4].Value = ":Cable Exist";
                sh.Cells[iCellX, 4].Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                //(existingXlRange.Cells[iCellX, "D"] as Microsoft.Office.Interop.Excel.Range).Value2 = ":Cable Exist";
                float x1 = 0;
                float y1 = 0;
                float x2 = 0;
                float y2 = 0;
                DrawColorLineInCell(sh, iCellX, 3, ref x1, ref y1, ref x2, ref y2);
                Shape objLineShape = sh.Shapes.AddLine(Convert.ToSingle(x1), y1, x2, y2);
                objLineShape.Line.ForeColor.RGB = Color.Black.ToArgb();
                objLineShape.Line.Weight = 1;



                int iTwoCellX = iMaxNo + 3;
                sh.Cells[iTwoCellX, 4].Value = ":Two Cables Exist";
                sh.Cells[iTwoCellX, 4].Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                //(existingXlRange.Cells[iCellX, "D"] as Microsoft.Office.Interop.Excel.Range).Value2 = ":Cable Exist";
                float fCellHeight = (float)(sh.Cells[iTwoCellX, 3].Height / 6);
                 x1 = 0;
                 y1 = 0;
                 x2 = 0;
                 y2 = 0;
                DrawColorLineInCell(sh, iTwoCellX, 3, ref x1, ref y1, ref x2, ref y2);
                Shape objLineShapeTwo = sh.Shapes.AddLine(Convert.ToSingle(x1), (y1 + fCellHeight), x2, (y2 + fCellHeight));
                objLineShapeTwo.Line.ForeColor.RGB = Color.Black.ToArgb();
                objLineShapeTwo.Line.Weight = 1;

                Shape objTwoLineShape = sh.Shapes.AddLine(Convert.ToSingle(x1), (y1 - fCellHeight), x2, (y2 - fCellHeight));
                objTwoLineShape.Line.ForeColor.RGB = Color.Black.ToArgb();
                objTwoLineShape.Line.Weight = 1;


                //RedLine

                int iCellXRed = iMaxNo + 5;
                sh.Cells[iCellXRed, 4].Value = ":No-Cable";
                sh.Cells[iCellXRed, 4].Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                //(existingXlRange.Cells[iCellXRed, "D"] as Microsoft.Office.Interop.Excel.Range).Value2 = ":No-Cable";
                 x1 = 0;
                 y1 = 0;
                 x2 = 0;
                 y2 = 0;
                DrawColorLineInCell(sh, iCellXRed, 3, ref x1, ref y1, ref x2, ref y2);
                Shape objLineShapeRed = sh.Shapes.AddLine(Convert.ToSingle(x1), y1, x2, y2);
                objLineShapeRed.Line.ForeColor.RGB = Color.Black.ToArgb();
                objLineShapeRed.Line.DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineDash;
                objLineShapeRed.Line.Weight = 1;
                iMaxNo = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DrawColorLineInCell(Worksheet sh, int iCellX, int p, ref float x1, ref float y1, ref float x2, ref float y2)
        {
            float lngXPoint = (float)(sh.Cells[iCellX, p].Left + sh.Cells[iCellX, p].Width / 2);
            float lngYPoint = (float)(sh.Cells[iCellX, p].Top + sh.Cells[iCellX, p].Height / 2);

            x1 = (float)(lngXPoint - (sh.Cells[iCellX, p].Width / 2));
            y1 = (float)(lngYPoint);

            x2 = (float)(lngXPoint + (sh.Cells[iCellX, p].Width / 2));
            y2 = (float)(lngYPoint);
        }
    }
}
