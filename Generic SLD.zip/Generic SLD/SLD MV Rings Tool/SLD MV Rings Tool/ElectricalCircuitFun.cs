﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.Geodatabase;
using System.Text.RegularExpressions;
using ESRI.ArcGIS.Geometry;
using System.Runtime.InteropServices;

namespace SLD_MV_Rings_Tool
{
   public class ElectricalCircuitFun
   {
       #region
       public Dictionary<IQueryFilter, int> dictQueryPatchLocation = new Dictionary<IQueryFilter, int>();
       StartEndCellAddressesValues objStartEndCellAddrVals;
      
       #endregion

       internal void ElectricalMainFunctionality(List<CellValAndAddress> lstElectricalCellPostionsVals, IFeatureClass pF_PatchLocation, IFeatureClass pF_FiberCable, List<StartEndCellAddressesValues> lstIncreasedElectricalCells, ref List<StartEndCellAddressesValues> lstConnectedNodes, ref List<StartEndCellAddressesValues> lstNotConnectedNodes, ref List<StartEndCellAddressesValues> lstNewlyConnectedNodes, ref List<StartEndCellAddressesValues> lstCoonectedWithInCircuit)
       {
           try
           {
               //get electrical cell address
               List<string> ElectricalOccupaidCellAddress = GetOccupaidElectricalCellsList(lstIncreasedElectricalCells);

               for (int i = 0; i < lstElectricalCellPostionsVals.Count; i++)
               {
                   string strCellValue = lstElectricalCellPostionsVals[i].CellValue;
                   //Check Customer type or Primary Type
                   string strNode = CheckTypeOfNode(strCellValue);
                   string strDigits = Regex.Replace(strCellValue, "[^0-9]", "");
                   //get list of gis end nodes when compare strCellValue with each node in gis
                   List<string> lstOfGISEndNodes = GetGISEndNodes(strCellValue, strNode, strDigits, pF_PatchLocation, pF_FiberCable);

                   //pending if node not available means no patchlocation
                   //discuss again if we want change then change

                   //make lstOfGISEndNodes to six digits
                   lstOfGISEndNodes = MakeListitemsSixDigits(lstOfGISEndNodes);

                   for (int j = 0; j < lstOfGISEndNodes.Count; j++)
                   {
                       string strAlpha = Regex.Replace(lstOfGISEndNodes[j], "[^a-zA-Z]", "");
                       if (!(strAlpha == "PT" || strAlpha == "PS"))
                       {
                           //to find nodeConvension in fiber cable
                           string strGISENDNode = FindNodeInGISName(strNode, lstOfGISEndNodes[j], pF_FiberCable);
                           bool isLetter = strGISENDNode.StartsWith("Z");
                           if (isLetter == true)
                           {
                               strGISENDNode = strGISENDNode.Remove(0, 1);
                               strGISENDNode = strGISENDNode.Remove(2, 1);
                               lstOfGISEndNodes[j] = strGISENDNode;
                           }
                           bool isLetters = strGISENDNode.StartsWith("SF");
                           if (isLetters == true)
                           {
                               strGISENDNode = strGISENDNode.Remove(0, 2);
                               lstOfGISEndNodes[j] = strGISENDNode;
                           }
                           bool islttr = strGISENDNode.StartsWith("ZD");
                           if (islttr == true)
                           {
                               strGISENDNode = strGISENDNode.Remove(0, 1);
                               lstOfGISEndNodes[j] = strGISENDNode;
                           }
                       }
                   }

                   //Check whether Cable is existed in previous list as startPoint
                   lstOfGISEndNodes = CheckConnectedCables(lstConnectedNodes, lstOfGISEndNodes);

                   //get list of power ring end nodes 
                   List<string> lstPowerRingEndNodes = GetPowerRingEndNodes(lstIncreasedElectricalCells, strCellValue);

                   string[] items1 = new string[lstPowerRingEndNodes.Count];
                   string[] items2 = new string[lstOfGISEndNodes.Count];

                   for (int m = 0; m < lstOfGISEndNodes.Count; m++)
                   {
                       for (int n = 0; n < lstPowerRingEndNodes.Count; n++)
                       {
                           //if (!(lstPowerRingEndNodes[n].StartsWith("PT") || lstPowerRingEndNodes[n].StartsWith("PS")))
                           //{
                           //    string strAlpha = Regex.Replace(lstPowerRingEndNodes[n], "[^a-zA-Z]", "");
                           //    string strDigit = Regex.Replace(lstPowerRingEndNodes[n], "[^0-9]", "");
                           //    lstPowerRingEndNodes[n] = strAlpha + "M" + strDigit;
                           //}
                           if (lstPowerRingEndNodes[n] == lstOfGISEndNodes[m])
                           {
                               //Get GISENDNode with required convention
                               string strGISEndNode = GetGISEndNode(lstOfGISEndNodes[m]);

                               //get both side nodes connections 1<->2(Node)<->3
                               GetSideBySideConnectedNodes(strGISEndNode, lstIncreasedElectricalCells, strNode, ref lstConnectedNodes);
                               //lstPowerRingEndNodes.RemoveAt(n);
                               //lstOfGISEndNodes.RemoveAt(m);

                               items1[n] = lstPowerRingEndNodes[n];
                               items2[m] = lstOfGISEndNodes[m];
                           }
                       }
                   }

                   //delete from lists:
                   for (int y = 0; y < items1.Length; y++)
                       if (!String.IsNullOrEmpty(items1[y]))
                           lstPowerRingEndNodes.Remove(items1[y]);
                   for (int z = 0; z < items2.Length; z++)
                       if (!String.IsNullOrEmpty(items2[z]))
                           lstOfGISEndNodes.Remove(items2[z]);

                   if (lstOfGISEndNodes.Count > 0)
                   {
                       for (int z = 0; z < lstOfGISEndNodes.Count; z++)
                       {
                           string strGISEndNode = GetGISEndNode(lstOfGISEndNodes[z]);

                           bool blnState = CheckGISNodesInElectricalData(strGISEndNode, lstIncreasedElectricalCells);
                           if (blnState == true)
                           {
                               //With In Circuit connected
                               GetConnectedNodesWithInCircuit(strCellValue, strGISEndNode, lstIncreasedElectricalCells, strNode, ref lstCoonectedWithInCircuit);
                           }
                           else
                           {
                               ////Newly Connected Nodes....
                               GetNewlyConnectedNodesList(strCellValue,strNode, strGISEndNode, lstIncreasedElectricalCells, ElectricalOccupaidCellAddress, ref lstNewlyConnectedNodes);
                           }
                       }
                   }

                   if (lstPowerRingEndNodes.Count > 0)
                   {
                       //Get Not Connected Nodes
                       GetSideBySideNotConnectedNodes(lstPowerRingEndNodes, lstIncreasedElectricalCells, strNode, ref lstNotConnectedNodes);
                   }
               }
             
           }
           catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
           }
       }

       private string GetGISEndNode(string lstOfGISEndNode)
       {
           string strGISEndNod=string.Empty;
           try
           {
               string strAlpha = Regex.Replace(lstOfGISEndNode, "[^a-zA-Z]", "");
               if (strAlpha == "PT" || strAlpha == "PS")
               {
                   if (lstOfGISEndNode.Length == 6)
                   {
                       string strDigit = Regex.Replace(lstOfGISEndNode, "[^0-9]", "");
                       //var newString = strDigit.PadLeft(4, '0');
                       var newString = strDigit.TrimStart(new Char[] { '0' });
                       strGISEndNod = strAlpha + newString;
                   }
                   else
                   {
                       strGISEndNod = lstOfGISEndNode;
                   }
               }
               else
               {
                   strGISEndNod = lstOfGISEndNode;
               }
               return strGISEndNod;
           }
           catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
               return strGISEndNod;
           }
       }

       private List<string> GetOccupaidElectricalCellsList(List<StartEndCellAddressesValues> lstIncreasedElectricalCells)
       {
           List<string> ElectricalOccupaidCellAddress = new List<string>();
           try
           {   
               for (int l = 0; l < lstIncreasedElectricalCells.Count; l++)
               {
                   string strStartCellAddrr = lstIncreasedElectricalCells[l].StartValuePosition;
                   string strEndCellAddrr = lstIncreasedElectricalCells[l].EndValuePostion;
                   if (!ElectricalOccupaidCellAddress.Contains(strStartCellAddrr))
                   {
                       ElectricalOccupaidCellAddress.Add(strStartCellAddrr);
                   }
                   if (!ElectricalOccupaidCellAddress.Contains(strEndCellAddrr))
                   {
                       ElectricalOccupaidCellAddress.Add(strEndCellAddrr);
                   }
               }
               return ElectricalOccupaidCellAddress;
           }
           catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
               return ElectricalOccupaidCellAddress;
           }
       }

       private List<string> MakeListitemsSixDigits(List<string> lstOfGISEndNodes)
       {
           try
           {
               for (int i = 0; i < lstOfGISEndNodes.Count; i++)
               {
                   string strAlpha = Regex.Replace(lstOfGISEndNodes[i], "[^a-zA-Z]", "");
                   if (strAlpha == "PT" || strAlpha == "PS")
                   {
                       if (lstOfGISEndNodes[i].Length != 6)
                       {
                           string strDigit = Regex.Replace(lstOfGISEndNodes[i], "[^0-9]", "");
                           var newString = strDigit.PadLeft(4, '0');
                           lstOfGISEndNodes[i] = strAlpha + newString;
                       }
                   }
               }
               return lstOfGISEndNodes;
           }
           catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
               return lstOfGISEndNodes;
           }

       }

       private void GetNewlyConnectedNodesList(string strCellValue,string strNode,string lstOfGISEndNode, List<StartEndCellAddressesValues> lstIncreasedElectricalCells,List<string> ElectricalOccupaidCellAddress, ref List<StartEndCellAddressesValues> lstNewlyConnectedNodes)
       {
           try
           {
               int iDrawNewCellIncreaments = 4;
               int iNewXPostion = 0;
               int iNewYPostion = 0;
               string strCellAddressFormat = string.Empty;
               string strStartValue = string.Empty;
               string strStartPostion = string.Empty;
               string strEndValue = lstOfGISEndNode;

               for (int i = 0; i < lstIncreasedElectricalCells.Count; i++)
               {
                   if (strCellValue == lstIncreasedElectricalCells[i].StartValue)
                   {
                       strStartValue = lstIncreasedElectricalCells[i].StartValue;
                       strStartPostion = lstIncreasedElectricalCells[i].StartValuePosition;

                   }
               }
               for (int j = 0; j < ElectricalOccupaidCellAddress.Count; j++)
               {
                   if (ElectricalOccupaidCellAddress[j] == strStartPostion)
                   {
                       if (ElectricalOccupaidCellAddress.ElementAtOrDefault(j + 1) != null)
                       {
                           string[] strFindEndCell = ElectricalOccupaidCellAddress.ElementAtOrDefault(j + 1).Split(',');
                            iNewXPostion = (Convert.ToInt32(strFindEndCell[0])) + iDrawNewCellIncreaments;
                            iNewYPostion = (Convert.ToInt32(strFindEndCell[1]));
                            strCellAddressFormat = iNewXPostion + "," + iNewYPostion;
                          
                           bool blnCondition = CheckCellIsFilledOrNot(strCellAddressFormat, ElectricalOccupaidCellAddress);
                           if (blnCondition != true)
                           {
                               objStartEndCellAddrVals = new StartEndCellAddressesValues
                               {
                                   StartValue = strStartValue + "," + strNode,
                                   StartValuePosition = strStartPostion,
                                   EndValue = strEndValue,
                                   EndValuePostion = strCellAddressFormat

                               };
                               lstNewlyConnectedNodes.Add(objStartEndCellAddrVals);
                               ElectricalOccupaidCellAddress.Add(strCellAddressFormat);
                           }
                           else
                           {
                               iNewXPostion = iNewXPostion + iDrawNewCellIncreaments;
                                strCellAddressFormat = iNewXPostion + "," + iNewYPostion;

                                objStartEndCellAddrVals = new StartEndCellAddressesValues
                                {
                                    StartValue = strStartValue + "," + strNode,
                                    StartValuePosition = strStartPostion,
                                    EndValue = strEndValue,
                                    EndValuePostion = strCellAddressFormat

                                };
                                lstNewlyConnectedNodes.Add(objStartEndCellAddrVals);
                                ElectricalOccupaidCellAddress.Add(strCellAddressFormat);
                           }
                       }
                   }
               }


           }
           catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
           }

       }

       private bool CheckCellIsFilledOrNot(string strCellAddressFormat, List<string> ElectricalOccupaidCellAddress)
       {
           bool blnCondition = false;
           
           foreach (var item2 in ElectricalOccupaidCellAddress)
           {
               if (item2 == strCellAddressFormat)
               {  
                   blnCondition = true;
                   break;
               }
           }
           return blnCondition;
       }

       private string FindNodeInGISName(string strNode, string p, IFeatureClass pF_FiberCable)
       {
           eh:
           string strGISENDNode = string.Empty;
           try
           {
               IQueryFilter qFilter = new QueryFilterClass();
               qFilter.WhereClause = "CABLENAME LIKE  '%" + strNode + "%' and CABLENAME LIKE '%" + p + "%'";
               int intPLRowCount = pF_FiberCable.FeatureCount(qFilter);
               if (intPLRowCount > 0)
               {
                   IFeatureCursor pPlFeaCur = pF_FiberCable.Search(qFilter, false);
                   if (pPlFeaCur != null)
                   {
                       IFeature pPlFeature = pPlFeaCur.NextFeature();
                       while (pPlFeature != null)
                       {
                           string[] strCableName = (Convert.ToString(pPlFeature.get_Value(pPlFeature.Fields.FindField("CABLENAME")))).Split('-');
                           string strFirstArg = strCableName[0];
                           string strSecondArg = strCableName[1];
                           if (strFirstArg.Contains(strNode))
                           {
                               strGISENDNode = strSecondArg;
                           }
                           else if (strSecondArg.Contains(strNode))
                           {
                               strGISENDNode = strFirstArg;
                           }
                           pPlFeature = pPlFeaCur.NextFeature();
                       }
                   }
               }
               else
               {
                   string strAlpha = Regex.Replace(strNode, "[^a-zA-Z]", "");
                   if (strAlpha == "PT" || strAlpha == "PS")
                   {
                       if (strNode.Length != 6)
                       {
                           string strDigit = Regex.Replace(strNode, "[^0-9]", "");
                           var newString = strDigit.PadLeft(4, '0');
                           strNode = strAlpha + newString;
                           goto eh;
                       }
                   }
               }
               return strGISENDNode;
           }
           catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
               return strGISENDNode;
           }
       }

       private void GetConnectedNodesWithInCircuit(string strCellValue,string lstOfGISEndNode, List<StartEndCellAddressesValues> lstIncreasedElectricalCells, string strNode, ref List<StartEndCellAddressesValues> lstCoonectedWithInCircuit)
       {
           try
           {
               string strStartValue = string.Empty;
               string strStartPostion = string.Empty;
               for (int i = 0; i < lstIncreasedElectricalCells.Count; i++)
               {
                   if (strCellValue == lstIncreasedElectricalCells[i].StartValue)
                   {
                       strStartValue = lstIncreasedElectricalCells[i].StartValue;
                       strStartPostion = lstIncreasedElectricalCells[i].StartValuePosition;
                       strCellValue = string.Empty;
                       break;
                   }
               }
               if (strCellValue != "" || strCellValue != null)
               {
                   for (int i = 0; i < lstIncreasedElectricalCells.Count; i++)
                   {
                       if (strCellValue == lstIncreasedElectricalCells[i].EndValue)
                       {
                           strStartValue = lstIncreasedElectricalCells[i].EndValue;
                           strStartPostion = lstIncreasedElectricalCells[i].EndValuePostion;
                           strCellValue = string.Empty;
                           break;
                       }
                   }
               }


               for (int j = 0; j < lstIncreasedElectricalCells.Count; j++)
               {
                   if (lstOfGISEndNode == lstIncreasedElectricalCells[j].StartValue)
                   {
                       string strEndValue = lstIncreasedElectricalCells[j].StartValue;
                       string strEndPostion = lstIncreasedElectricalCells[j].StartValuePosition;

                       objStartEndCellAddrVals = new StartEndCellAddressesValues
                       {
                           StartValue = strStartValue + "," + strNode,
                           StartValuePosition = strStartPostion,
                           EndValue = strEndValue,
                           EndValuePostion = strEndPostion

                       };
                       lstCoonectedWithInCircuit.Add(objStartEndCellAddrVals);
                       lstOfGISEndNode = string.Empty;
                       break;
                   }
               }
               if (lstOfGISEndNode != "" || lstOfGISEndNode != null)
               {
                   for (int j = 0; j < lstIncreasedElectricalCells.Count; j++)
                   {
                       if (lstOfGISEndNode == lstIncreasedElectricalCells[j].EndValue)
                       {
                           string strEndValue = lstIncreasedElectricalCells[j].EndValue;
                           string strEndPostion = lstIncreasedElectricalCells[j].EndValuePostion;

                           objStartEndCellAddrVals = new StartEndCellAddressesValues
                           {
                               StartValue = strStartValue + "," + strNode,
                               StartValuePosition = strStartPostion,
                               EndValue = strEndValue,
                               EndValuePostion = strEndPostion

                           };
                           lstCoonectedWithInCircuit.Add(objStartEndCellAddrVals);
                           lstOfGISEndNode = string.Empty;
                           break;
                       }
                   }
               }
               //delete duplications in list
               for (int i = 0; i < lstCoonectedWithInCircuit.Count; i++)
               {
                   for (int j = 0; j < lstCoonectedWithInCircuit.Count; j++)
                   {
                       if (lstCoonectedWithInCircuit[i].StartValue.Split(',')[0] == lstCoonectedWithInCircuit[j].EndValue && lstCoonectedWithInCircuit[i].StartValuePosition == lstCoonectedWithInCircuit[j].EndValuePostion &&
                           lstCoonectedWithInCircuit[i].EndValue == lstCoonectedWithInCircuit[j].StartValue.Split(',')[0] && lstCoonectedWithInCircuit[i].EndValuePostion == lstCoonectedWithInCircuit[j].StartValuePosition)
                       {
                           lstCoonectedWithInCircuit.Remove(lstCoonectedWithInCircuit[i]);
                           break;
                       }
                   }     
               }

           }
           catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
           }
       }

       private bool CheckGISNodesInElectricalData(string lstOfGISEndNode, List<StartEndCellAddressesValues> lstIncreasedElectricalCells)
       {
           bool blnState = false;
           try
           {
               for (int j = 0; j < lstIncreasedElectricalCells.Count; j++)
               {
                   if (lstOfGISEndNode == lstIncreasedElectricalCells[j].StartValue || lstOfGISEndNode == lstIncreasedElectricalCells[j].EndValue)
                   {
                       blnState = true;
                   }
               }
               return blnState;
           }
           catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
               return blnState;

           }
       }

       private void GetSideBySideNotConnectedNodes(List<string> lstPowerRingEndNodes, List<StartEndCellAddressesValues> lstIncreasedElectricalCells, string strNode, ref List<StartEndCellAddressesValues> lstNotConnectedNodes)
       {
           string strGISEndNod = string.Empty;

           try
           {
               if (lstPowerRingEndNodes.Count > 0)
               {
                   for (int i = 0; i < lstPowerRingEndNodes.Count; i++)
                   {
                       string strAlpha = Regex.Replace(lstPowerRingEndNodes[i], "[^a-zA-Z]", "");
                       if (strAlpha == "PT" || strAlpha == "PS")
                       {
                           if (lstPowerRingEndNodes[i].Length == 6)
                           {
                               string strDigit = Regex.Replace(lstPowerRingEndNodes[i], "[^0-9]", "");
                               //var newString = strDigit.PadLeft(4, '0');
                               var newString = strDigit.TrimStart(new Char[] { '0' });
                               strGISEndNod = strAlpha + newString;
                           }
                           else
                           {
                               strGISEndNod = lstPowerRingEndNodes[i];
                           }
                       }
                       else
                       {
                           strGISEndNod = lstPowerRingEndNodes[i];
                       }
                       for (int j = 0; j < lstIncreasedElectricalCells.Count; j++)
                       {
                           if (strGISEndNod == lstIncreasedElectricalCells[j].EndValue)
                           {
                               objStartEndCellAddrVals = new StartEndCellAddressesValues
                               {
                                   StartValue = lstIncreasedElectricalCells[j].StartValue + "," + strNode,
                                   StartValuePosition = lstIncreasedElectricalCells[j].StartValuePosition,
                                   EndValue = lstIncreasedElectricalCells[j].EndValue,
                                   EndValuePostion = lstIncreasedElectricalCells[j].EndValuePostion

                               };
                               lstNotConnectedNodes.Add(objStartEndCellAddrVals);
                           }
                       }
                   }
               }
           }
           catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
           }
       }

       private void GetSideBySideConnectedNodes(string lstOfGISEndNode, List<StartEndCellAddressesValues> lstIncreasedElectricalCells, string strNode, ref List<StartEndCellAddressesValues> lstConnectedNodes)
       {
           try
           {

               for (int j = 0; j < lstIncreasedElectricalCells.Count; j++)
               {
                   if (lstOfGISEndNode.Length > 0)
                   {
                       if (lstOfGISEndNode == lstIncreasedElectricalCells[j].EndValue)
                       {
                           objStartEndCellAddrVals = new StartEndCellAddressesValues
                           {
                               StartValue = lstIncreasedElectricalCells[j].StartValue + "," + strNode,
                               StartValuePosition = lstIncreasedElectricalCells[j].StartValuePosition,
                               EndValue = lstIncreasedElectricalCells[j].EndValue,
                               EndValuePostion = lstIncreasedElectricalCells[j].EndValuePostion

                           };
                           lstConnectedNodes.Add(objStartEndCellAddrVals);
                       }
                   }
               }
           }
           catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
           }
       }

       private List<string> CheckConnectedCables(List<StartEndCellAddressesValues> lstConnectedNodes, List<string> lstOfGISEndNodes)
       {
           string strGISEndNod = string.Empty;
           try
           {
               if (lstConnectedNodes.Count > 0)
               {
                   for (int i = 0; i < lstConnectedNodes.Count; i++)
                   {
                       string strStartNode = lstConnectedNodes[i].StartValue.Split(',')[1];
                       string strEndNode = lstConnectedNodes[i].EndValue;
                       string strStartNode1 = lstConnectedNodes[i].StartValue.Split(',')[0];
                       for (int j = 0; j < lstOfGISEndNodes.Count; j++)
                       {
                           string strAlpha = Regex.Replace(lstOfGISEndNodes[j], "[^a-zA-Z]", "");
                           if (strAlpha == "PT" || strAlpha == "PS")
                           {
                               if (lstOfGISEndNodes[j].Length == 6)
                               {
                                   string strDigit = Regex.Replace(lstOfGISEndNodes[j], "[^0-9]", "");
                                   //var newString = strDigit.PadLeft(4, '0');
                                   var newString = strDigit.TrimStart(new Char[] { '0' });
                                   strGISEndNod = strAlpha + newString;
                               }
                               else
                               {
                                   strGISEndNod = lstOfGISEndNodes[j];
                               }
                           }
                           else
                           {
                               strGISEndNod = lstOfGISEndNodes[j];
                           }
                           if (strStartNode == strGISEndNod || strStartNode1 == strGISEndNod || strEndNode == strGISEndNod)
                           {
                               lstOfGISEndNodes.RemoveAt(j);
                           }
                       }
                   }
               }
               return lstOfGISEndNodes;
           }
           catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
               return lstOfGISEndNodes;
           }
       }

       private List<string> GetPowerRingEndNodes(List<StartEndCellAddressesValues> lstIncreasedElectricalCells, string strCellValue)
       {
           List<string> lstPowerRingEndNodes = new List<string>();
           try
           {
               List<string> strExcelEndCbl = new List<string>();
               for (int i = 0; i < lstIncreasedElectricalCells.Count; i++)
               {
                   if (lstIncreasedElectricalCells[i].StartValue == strCellValue)
                   {
                       string strEndValue = lstIncreasedElectricalCells[i].EndValue;
                       string strAlpha = Regex.Replace(strEndValue, "[^a-zA-Z]", "");
                       if (strAlpha == "PT" || strAlpha == "PS")
                       {
                           if (strEndValue.Length != 6)
                           {
                               string strDigit = Regex.Replace(strEndValue, "[^0-9]", "");
                               var newString = strDigit.PadLeft(4, '0');
                               strEndValue = strAlpha + newString;
                           }
                       }
                       strExcelEndCbl.Add(strEndValue);
                       lstPowerRingEndNodes = strExcelEndCbl.Distinct().ToList();
                   }
               }
               return lstPowerRingEndNodes;
           }
           catch
           {
               return lstPowerRingEndNodes;
           }
       }

        private List<string> GetGISEndNodes(string strCellValue, string strNode, string strDigits, IFeatureClass pF_PatchLocation, IFeatureClass pF_FiberCable)
        {
            List<string> lstOfGISEndNodes = new List<string>();
            try
            {
            eh:
                List<string> strGISEndCbl = new List<string>();
                dictQueryPatchLocation = queryFilter(strNode, "NAME", pF_PatchLocation);
                var de = dictQueryPatchLocation.GetEnumerator();
                de.MoveNext();
                var anElement = de.Current;
                if (anElement.Value >= 1)
                {
                    IFeatureCursor pfeaCur = pF_PatchLocation.Search(anElement.Key, false);
                    if (pfeaCur != null)
                    {
                        string strCableBuilt = BuildCable(strCellValue, strDigits, strNode);
                        IQueryFilter qFilter = new QueryFilterClass();
                        qFilter.WhereClause = strCableBuilt;
                        int intPLRowCount = pF_FiberCable.FeatureCount(qFilter);
                        if (intPLRowCount > 0)
                        {
                            IFeatureCursor pPlFeaCur = pF_FiberCable.Search(qFilter, false);
                            if (pPlFeaCur != null)
                            {
                                IFeature pPlFeature = pPlFeaCur.NextFeature();
                                while (pPlFeature != null)
                                {
                                    string strCableName = Convert.ToString(pPlFeature.get_Value(pPlFeature.Fields.FindField("CABLENAME")));
                                    IGeometry pGeom = pPlFeature.Shape;
                                    string plNames = getPLLocation(pGeom, pF_PatchLocation, strNode);
                                    if (plNames != "")
                                    {
                                        strGISEndCbl.Add(plNames);
                                        lstOfGISEndNodes = strGISEndCbl.Distinct().ToList();
                                    }
                                    pPlFeature = pPlFeaCur.NextFeature();
                                }
                            }
                        }
                        else
                        {
                            return lstOfGISEndNodes;
                        }
                    }
                }
                else
                {
                    string strPatch = "No-PatchLoaction";
                    if (strPatch == "No-PatchLoaction")
                    {
                        string strAlpha = Regex.Replace(strNode, "[^a-zA-Z]", "");
                        if (strAlpha == "PT" || strAlpha == "PS")
                        {
                            if (strNode.Length != 6)
                            {
                                string strDigit = Regex.Replace(strNode, "[^0-9]", "");
                                var newString = strDigit.PadLeft(4, '0');
                                strNode = strAlpha + newString;
                                goto eh;
                            }
                            else
                            {
                                return lstOfGISEndNodes;
                            }
                        }
                        else
                        {
                           return lstOfGISEndNodes;
                        }
                    }

                }

                return lstOfGISEndNodes;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return lstOfGISEndNodes;
            }
        }
        private string getPLLocation(IGeometry iGeo, IFeatureClass pF_PatchLocation, string StrPlName)
        {
            string plName = string.Empty;
            try
            {
                SpatialFilter pSpatialFilter = new SpatialFilterClass();
                pSpatialFilter.SpatialRel = esriSpatialRelEnum.esriSpatialRelIntersects;
                pSpatialFilter.Geometry = iGeo;
                int intPLRowCount = pF_PatchLocation.FeatureCount(pSpatialFilter);
                if (intPLRowCount > 0)
                {
                    IFeatureCursor pPlFeaCur = pF_PatchLocation.Search(pSpatialFilter, false);
                    if (pPlFeaCur != null)
                    {
                        IFeature pPlFeature = pPlFeaCur.NextFeature();
                        while (pPlFeature != null)
                        {
                            if (StrPlName.ToUpper() != Convert.ToString(pPlFeature.get_Value(pPlFeature.Fields.FindField("NAME"))).ToUpper())
                            {
                                plName = Convert.ToString(pPlFeature.get_Value(pPlFeature.Fields.FindField("NAME")));
                            }
                            pPlFeature = pPlFeaCur.NextFeature();
                        }
                        Marshal.ReleaseComObject(pPlFeaCur);
                    }
                }
                return plName;
            }
            catch
            {
                return plName;
            }
        }

        private string BuildCable(string strCellValue, string strDigits, string strNode)
        {
            string strBuiltedCable = string.Empty;
            string strStartValue = string.Empty;
            try
            {
                string strAlpha = Regex.Replace(strCellValue, "[^a-zA-Z]", "");
                if (strAlpha == "PT" || strAlpha == "PS")
                {
                    if (strCellValue.Length != 6)
                    {
                        string strDigit = Regex.Replace(strCellValue, "[^0-9]", "");
                        var newString = strDigit.PadLeft(4, '0');
                        strStartValue = strAlpha + newString;
                    }
                    else
                    {
                        strStartValue = strCellValue;
                    }
                }
                else
                {
                    strStartValue = strNode + strDigits;
                }

                strBuiltedCable = "CABLENAME LIKE '%" + strStartValue + "%'";

                return strBuiltedCable;
            }
            catch
            {
                return null;
            }
        }
        private Dictionary<IQueryFilter, int> queryFilter(string val, string field, IFeatureClass fc)
        {
            try
            {
                Dictionary<IQueryFilter, int> fm = new Dictionary<IQueryFilter, int>();
                int featureCount = 0;
                IQueryFilter queryFiltevr = new QueryFilterClass();
                queryFiltevr.WhereClause = field + "=" + "'" + val + "'";
                featureCount = fc.FeatureCount(queryFiltevr);
                fm.Add(queryFiltevr, featureCount);
                return fm;
            }
            catch
            {
                throw;
            }
            finally
            {
            }
        }

        private string CheckTypeOfNode(string strCellValue)
        {
            string TypeOfNode = string.Empty;
            try
            {
                string strAlpha = Regex.Replace(strCellValue, "[^a-zA-Z]", "");
                if (strAlpha == "PT" || strAlpha == "PS")
                {
                    //Customer Type
                    TypeOfNode = strCellValue;

                }
                else
                {
                    //Primary Type
                    TypeOfNode = strAlpha + "M";
                }
                return TypeOfNode;
            }
            catch
            {
                return null;
            }
        }
    }
}
