﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using System.Windows.Forms;

namespace SLD_MV_Rings_Tool
{
    public class GISFunctionalities
    {

        internal void GetFeaWorkspace(IMap pMap, out IWorkspace pWorkSpace, out IFeatureWorkspace pFeatureWorkspace, out IFeatureLayer pFeatureLayer, string strCableLayerName)
        {
            pWorkSpace = null;
            pFeatureWorkspace = null;
            pFeatureLayer = null;
            if (pMap.LayerCount > 0)
            {
                for (int nCnt = 0; nCnt < pMap.LayerCount; nCnt++)
                {
                    ILayer pTempLayer = pMap.get_Layer(nCnt);
                    IFeatureLayer pflayer = null;
                eh:
                    if (pTempLayer is IGroupLayer)
                    {
                        ICompositeLayer pCompLyr = (ICompositeLayer)pTempLayer;

                        for (int iInt = 0; iInt < pCompLyr.Count; iInt++)
                        {
                            pTempLayer = pCompLyr.get_Layer(iInt);
                            if (pTempLayer is IGroupLayer)
                                goto eh;
                            pflayer = pCompLyr.get_Layer(iInt) as IFeatureLayer;

                            if (pflayer != null)
                            {
                                //pFeatLayer = pComprLayer as IFeatureLayer;
                                if (((IDataset)(pflayer).FeatureClass).Name.ToUpper().Contains(strCableLayerName))
                                {
                                    pFeatureLayer = pTempLayer as IFeatureLayer;
                                    pWorkSpace = ((IDataset)(pflayer.FeatureClass)).Workspace;
                                    if (pWorkSpace != null)
                                    {
                                        pFeatureWorkspace = pWorkSpace as IFeatureWorkspace;
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        pflayer = pTempLayer as IFeatureLayer;
                        if (((IDataset)(pflayer).FeatureClass).Name.ToUpper().Contains(strCableLayerName))
                        {
                            pFeatureLayer = pTempLayer as IFeatureLayer;
                            pWorkSpace = ((IDataset)(pflayer.FeatureClass)).Workspace;
                            if (pWorkSpace != null)
                            {
                                pFeatureWorkspace = pWorkSpace as IFeatureWorkspace;
                            }
                            break;
                        }
                    }
                }
            }
        }

        internal void openFeatureClassTables(ref IFeatureClass pF_PatchLocation, ref IFeatureClass pF_FiberCable, IFeatureWorkspace pFeatureWorkspace, string strCableLayerNamepl, string strCableLayerNamefb, IFeatureLayer pFeatLayer, IWorkspace pWorkSpace)
        {
            try
            {
                if (pFeatureWorkspace != null)
                {
                    IDataset dataset = null;
                    try
                    {
                        pF_PatchLocation = pFeatureWorkspace.OpenFeatureClass(strCableLayerNamepl);
                        pF_FiberCable = pFeatureWorkspace.OpenFeatureClass(strCableLayerNamefb);
                    }

                    catch
                    {
                        try
                        {
                            if (((IDataset)(pFeatLayer.FeatureClass)).Name.Contains("."))
                            {
                                string[] name = ((IDataset)(pFeatLayer.FeatureClass)).Name.Split('.');

                                pF_PatchLocation = pFeatureWorkspace.OpenFeatureClass(name[name.Length - 2].ToString() + "." + strCableLayerNamepl);
                                pF_FiberCable = pFeatureWorkspace.OpenFeatureClass(name[name.Length - 2].ToString() + "." + strCableLayerNamefb);
                            }
                        }
                        catch
                        {
                            IEnumDataset datasets = pWorkSpace.get_Datasets(esriDatasetType.esriDTFeatureDataset);
                            dataset = null;
                            while ((dataset = datasets.Next()) != null)
                            {
                                if (dataset.Name.ToUpper().Contains("FIBERDATASET"))
                                {
                                    if (dataset.Type == esriDatasetType.esriDTFeatureDataset)
                                    {
                                        string name = dataset.Name;
                                        IFeatureDataset fDS = pFeatureWorkspace.OpenFeatureDataset(dataset.Name);
                                        IEnumDataset enumDS = fDS.Subsets;
                                        IDataset ds;
                                        enumDS.Reset();
                                        while ((ds = enumDS.Next()) != null)
                                        {

                                            if (ds.Name.ToUpper().Contains(strCableLayerNamepl))
                                            {
                                                pF_PatchLocation = pFeatureWorkspace.OpenFeatureClass(ds.Name);
                                            }
                                            if (ds.Name.ToUpper().Contains(strCableLayerNamefb))
                                            {
                                                pF_FiberCable = pFeatureWorkspace.OpenFeatureClass(ds.Name);
                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                else
                {
                    MessageBox.Show("FetureWorkspace is NULL", "SLD MV Rings", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }
    }
}
