﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.ArcMapUI;
using System.Windows.Forms;
using ESRI.ArcGIS.Geodatabase;

namespace SLD_MV_Rings_Tool
{
    public class MVRing : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        #region Variable Declaration
        IMap pMap;
        IMxDocument m_MxDoc;
        SLDMVRingForm sldMVRingFrm;

        #endregion

        public MVRing()
        {
        }

        protected override void OnClick()
        {            
            ArcMap.Application.CurrentTool = null;
            m_MxDoc = (IMxDocument)ArcMap.Application.Document;
            pMap = m_MxDoc.FocusMap;
            try
            {
                //check required layers exist or not
                Boolean blnIsLayer = IsLayerExist();
                if (blnIsLayer == true)
                {
                    Boolean fromFound = false;
                    foreach (Form item in Application.OpenForms)
                    {
                        if (item.Name == "SLDMVRingForm")
                        {
                            fromFound = true;
                        }
                    }
                    if (fromFound == false)
                    {
                        if (sldMVRingFrm == null || sldMVRingFrm.IsDisposed)
                        {
                            sldMVRingFrm = new SLDMVRingForm(ArcMap.Application);
                        }
                        if (!sldMVRingFrm.Visible)
                        {
                            sldMVRingFrm.Show(ArcMap.Application as IWin32Window);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        protected override void OnUpdate()
        {
            Enabled = ArcMap.Application != null;
        }

        private Boolean IsLayerExist()
        {
            string strLayers = "";
            Boolean isCable = false;
            Boolean isPL = false;

            for (int nCnt = 0; nCnt < pMap.LayerCount; nCnt++)
            {
                ILayer pTempLayer = pMap.get_Layer(nCnt);
                IFeatureLayer pflayer = null;
            eh:
                if (pTempLayer is IGroupLayer)
                {
                    ICompositeLayer pCompLyr = (ICompositeLayer)pTempLayer;

                    for (int iInt = 0; iInt < pCompLyr.Count; iInt++)
                    {
                        pTempLayer = pCompLyr.get_Layer(iInt);
                        if (pTempLayer is IGroupLayer)
                            goto eh;
                        pflayer = pCompLyr.get_Layer(iInt) as IFeatureLayer;

                        if (pflayer != null)
                        {
                            if (((IDataset)(pflayer).FeatureClass).Name.ToUpper().Contains("FIBEROPTICCABLE") == true)
                            {
                                isCable = true;

                            }
                            if (((IDataset)(pflayer).FeatureClass).Name.ToUpper().Contains("PATCHLOCATION") == true)
                            {
                                isPL = true;
                                //strLayers = strLayers + ", PL";
                            }
                        }
                    }
                }
                else
                {
                    pflayer = pTempLayer as IFeatureLayer;
                    if (((IDataset)(pflayer).FeatureClass).Name.ToUpper().Contains("FIBEROPTICCABLE") == true)
                    {
                        isCable = true;

                    }
                    if (((IDataset)(pflayer).FeatureClass).Name.ToUpper().Contains("PATCHLOCATION") == true)
                    {
                        isPL = true;
                        //strLayers = strLayers + ", PL";
                    }
                }
            }
            if (isCable == false)
            {
                strLayers = strLayers + ", FIBERCABLE";
            }
            if (isPL == false)
            {
                strLayers = strLayers + ", PL";
            }
            if (strLayers != "")
            {
                strLayers = strLayers.Substring(1, strLayers.Length - 1);
                MessageBox.Show(strLayers + " Layer is not found on the map, Please add the Layer", "SLD MV Rings", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
