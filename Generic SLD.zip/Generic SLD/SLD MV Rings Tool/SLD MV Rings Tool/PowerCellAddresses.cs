﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace SLD_MV_Rings_Tool
{
    class PowerCellAddresses
    {
        #region varibale declaration
        List<KeyValuePair<string, string>> lstOfDrawnedVal = new List<KeyValuePair<string, string>>();
        List<CellValAndAddress> lstDrawnedCellPostion=new List<CellValAndAddress>();
        ComparedCellPosition objComparedLst;
        List<ComparedCellPosition> lstSecondTypeCellPostions = new List<ComparedCellPosition>();
        CellValAndAddress clssCelladdress;
        string strPreviousStartPoint = string.Empty;
        #endregion

        internal List<CellValAndAddress> GetAllPowerNwCellAddress(Dictionary<string, SheetExtraction> cellDiversionsDictionary, List<string> lstOfOccupiedCellAddress, List<CellValAndAddress> lstHighestRowCellPostions, int ibaseCellStartX, ref List<ComparedCellPosition> lstSecondTypeCellPos)
        {
            try
            {
                string strMaxPostion = string.Empty;
                string strCommonValue = string.Empty;
                List<KeyValuePair<string, string>> lstOfCellDivertPostion = new List<KeyValuePair<string, string>>();
                for (int i = 0; i < cellDiversionsDictionary.Count; i++)
                {
                    string strCellDiversePostion=cellDiversionsDictionary.ToArray()[i].Value.CellDiversionAddress;
                    string strRow = cellDiversionsDictionary.ToArray()[i].Key;
                    string key = strRow.Split()[0];
                    string key_ID = Regex.Split(key, @"[^\d]")[4];
                    lstOfCellDivertPostion.Add(new KeyValuePair<string, string>(key_ID, strCellDiversePostion));     
                }
                List<SheetExtraction> lstHashTableData = ConvertHashTableToList(cellDiversionsDictionary);

                for (int j = 0; j < lstOfCellDivertPostion.Count; j++)
                {
                    //where node is split with values
                    GetMaxNodeAndCommnVal(lstOfCellDivertPostion, ref strMaxPostion, ref strCommonValue);

                    for (int k = lstOfCellDivertPostion.Count - 1; k >= 0; k--)
                    {
                        if (lstOfCellDivertPostion[k].ToString() == strCommonValue)
                        {
                            lstOfCellDivertPostion.Remove(lstOfCellDivertPostion[k]);
                        }
                    }
                    //get max node cell value and postion need to placed
                    List<KeyValuePair<string, string>> lstOfPlacedValues = GetMaxNodeNetwork(lstHashTableData, strMaxPostion);                     

                   // List<KeyValuePair<string, string>> lstOfPlaced_values = DeleteDrawCells(lstOfPlacedValues, lstSecondTypeCellPostions);

                    lstOfPlacedValues = DeleteDrawCells(lstOfPlacedValues, lstSecondTypeCellPostions);

                   
                    //Get All Cell Address
                    lstDrawnedCellPostion = GetListOfCellAddress(lstOfPlacedValues, strMaxPostion, ibaseCellStartX, lstOfOccupiedCellAddress);
                    lstHighestRowCellPostions.AddRange(lstDrawnedCellPostion);
                    lstSecondTypeCellPos = lstSecondTypeCellPostions;
                }
                lstOfDrawnedVal.Clear();
                lstDrawnedCellPostion.Clear();
                return lstHighestRowCellPostions;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        private List<KeyValuePair<string, string>> DeleteDrawCells(List<KeyValuePair<string, string>> lstOfPlacedValues, List<ComparedCellPosition> lstSecondTypeCellPostions)
        {
            try
            {

                for (int i = lstOfPlacedValues.Count - 1; i >= 0; i--)
                {
                    for (int j = 0; j < lstSecondTypeCellPostions.Count; j++)
                    {
                        if (lstOfPlacedValues[i].Key == lstSecondTypeCellPostions[j].StartPoint && lstOfPlacedValues[i].Value == lstSecondTypeCellPostions[j].EndPoint)
                        {
                            lstOfPlacedValues.RemoveAt(i);
                            break;
                        }
                    }
                }
                return lstOfPlacedValues;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return lstOfPlacedValues;
            }
        }

        private List<CellValAndAddress> GetListOfCellAddress(List<KeyValuePair<string, string>> lstOfPlacedValues, string strMaxPostion, int ibaseCellStartX, List<string> lstOfOccupiedCellAddress)
        {
            try
            {
                int ExVal = 4;
                int x3 = 4;
                int drawPosition = 0;
                int incVal = 3;
                List<string> lstCellAddresses=new List<string>();
               
                for (int i = 0; i < lstOfOccupiedCellAddress.Count; i++)
                {
                    if (lstOfOccupiedCellAddress[i] == strMaxPostion)
                    {
                        if (lstOfOccupiedCellAddress.ElementAtOrDefault(i + 1) != null)
                        {
                           List<string> lstPlacedCells = lstOfOccupiedCellAddress.GetRange((i + 1), lstOfPlacedValues.Count);

                           int iRowWiseX = (ibaseCellStartX - x3);
                            for (int j = 0; j < lstPlacedCells.Count; j++)
                            {
                                string drawAtPostion = lstPlacedCells[j].Split(',')[1];
                                string strCellAddressFormat = iRowWiseX + "," + drawAtPostion;
                                lstCellAddresses.Add(strCellAddressFormat);

                            }
                          bool blnCondition =  CheckCellIsFilledOrNot(lstCellAddresses, lstOfOccupiedCellAddress);

                          if (blnCondition != true)
                          {
                              lstDrawnedCellPostion = GetCellsPostions(lstOfPlacedValues, lstCellAddresses, lstOfOccupiedCellAddress);
                              blnCondition = false;
                          }
                          else
                          {
                              lstCellAddresses.Clear();
                              iRowWiseX = (iRowWiseX - ExVal);
                              for (int j = 0; j < lstPlacedCells.Count; j++)
                              {
                                  string drawAtPostion = lstPlacedCells[j].Split(',')[1];
                                  string strCellAddressFormat = iRowWiseX + "," + drawAtPostion;

                                  lstCellAddresses.Add(strCellAddressFormat);
                              }                             
                              blnCondition = CheckCellIsFilledOrNot(lstCellAddresses, lstOfOccupiedCellAddress);
                              lstDrawnedCellPostion = GetCellsPostions(lstOfPlacedValues, lstCellAddresses, lstOfOccupiedCellAddress);
                          }
                        }
                        else
                        {
                            string _Postion = lstOfOccupiedCellAddress[i];
                            string drawAtPostion = _Postion.Split(',')[1];
                            int iRowWiseX = (ibaseCellStartX - x3);
                            for (int j = 0; j < lstOfPlacedValues.Count; j++)
                            {
                                drawPosition = drawPosition + incVal;

                                int y = drawPosition;

                                string strCellAddressFormat = iRowWiseX + "," + y;
                                lstCellAddresses.Add(strCellAddressFormat);
                            }
                            bool blnCondition = CheckCellIsFilledOrNot(lstCellAddresses, lstOfOccupiedCellAddress);

                            if (blnCondition != true)
                            {
                                lstDrawnedCellPostion = GetCellsPostions(lstOfPlacedValues, lstCellAddresses, lstOfOccupiedCellAddress);
                                blnCondition = false;
                            }
                            else
                            {
                                int x = (iRowWiseX - ExVal); int y = drawPosition;
                                string strCellAddressFormat = x + "," + y;
                                lstCellAddresses.Add(strCellAddressFormat);
                                lstDrawnedCellPostion = GetCellsPostions(lstOfPlacedValues, lstCellAddresses, lstOfOccupiedCellAddress);
                                blnCondition = false;
                            }
                        }
                    }
                }
                return lstDrawnedCellPostion;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        public List<CellValAndAddress> GetCellsPostions(List<KeyValuePair<string, string>> lstOfPlacedValues, List<string> lstCellAddresses, List<string> lstOfOccupiedCellAddress)
        {
            try
            {
                string strPreviousStartPoint = string.Empty;
                if (lstOfDrawnedVal.Count == 0)
                {
                    for (int i = 0; i < lstOfPlacedValues.Count; i++)
                    {
                        string _findStartValue = lstOfPlacedValues[i].Value;
                        string _findEndValue = lstOfPlacedValues[i].Key;

                        if (i == 0)
                        {
                            clssCelladdress = new CellValAndAddress { CellAddress = lstCellAddresses[i], CellValue = _findEndValue };
                            lstDrawnedCellPostion.Add(clssCelladdress);
                            strPreviousStartPoint = _findEndValue;
                        }
                        else
                        {
                            if (_findStartValue == strPreviousStartPoint)
                            {

                                clssCelladdress = new CellValAndAddress { CellAddress = lstCellAddresses[i], CellValue = _findEndValue };
                                lstDrawnedCellPostion.Add(clssCelladdress);
                                strPreviousStartPoint = _findEndValue;
                            }
                        }

                        lstOfDrawnedVal.Add(new KeyValuePair<string, string>(_findEndValue, _findStartValue));

                        objComparedLst = new ComparedCellPosition { StartPoint = _findStartValue, EndPoint = _findEndValue, CellPostion = lstCellAddresses[i] };
                        lstSecondTypeCellPostions.Add(objComparedLst);
                    }
                    lstOfOccupiedCellAddress.AddRange(lstCellAddresses);

                }
                else
                {
                    lstDrawnedCellPostion = GetNotFilledCells(lstOfDrawnedVal, lstOfPlacedValues, lstCellAddresses, lstOfOccupiedCellAddress);
                }
                return lstDrawnedCellPostion;
            }
           
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        bool check = true;
        private List<CellValAndAddress> GetNotFilledCells(List<KeyValuePair<string, string>> lstOfDrawnedVal, List<KeyValuePair<string, string>> lstOfPlacedValues, List<string> lstCellAddresses, List<string> lstOfOccupiedCellAddress)
        {
            try
            {
                for (int i = 0; i < lstOfPlacedValues.Count; i++)
                {
                    if (lstOfDrawnedVal.Contains(lstOfPlacedValues[i]) != true)
                    {
                        check = false;
                        string _findStartValue = lstOfPlacedValues[i].Value;
                        string _findEndValue = lstOfPlacedValues[i].Key;

                        if (i == 0)
                        {
                            clssCelladdress = new CellValAndAddress { CellAddress = lstCellAddresses[i], CellValue = _findEndValue };
                            lstDrawnedCellPostion.Add(clssCelladdress);
                            strPreviousStartPoint = _findEndValue;
                        }
                        else
                        {
                            if (_findStartValue == strPreviousStartPoint)
                            {

                                clssCelladdress = new CellValAndAddress { CellAddress = lstCellAddresses[i], CellValue = _findEndValue };
                                lstDrawnedCellPostion.Add(clssCelladdress);
                                strPreviousStartPoint = _findEndValue;
                            }
                        }
                        lstOfDrawnedVal.Add(new KeyValuePair<string, string>(_findEndValue, _findStartValue));
                        objComparedLst = new ComparedCellPosition { StartPoint = _findStartValue, EndPoint = _findEndValue, CellPostion = lstCellAddresses[i] };
                        lstSecondTypeCellPostions.Add(objComparedLst);
                    }
                }
                if (check == false)
                {
                    lstOfOccupiedCellAddress.AddRange(lstCellAddresses);
                    check = true;
                }

                return lstDrawnedCellPostion;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        public bool CheckCellIsFilledOrNot(List<string> lstCellAddresses, List<string> OccupiedCells)
        {
            bool blnCondition = false;
            foreach (var item1 in OccupiedCells)
            {
                string match = null;
                foreach (var item2 in lstCellAddresses)
                {
                    if (item2 == item1)
                    {
                        match = item1;
                        blnCondition = true;
                        break;
                    }
                }
                if (match != null)
                    break;
            }
            return blnCondition;
        }

        private List<KeyValuePair<string, string>> GetMaxNodeNetwork(List<SheetExtraction> lstHashTableData, string strMaxPostion)
        {
            try
            {
                List<KeyValuePair<string, string>> lstOfPlacesToDraw = new List<KeyValuePair<string, string>>();
                List<KeyValuePair<string, string>> lstOfPlacedValues = new List<KeyValuePair<string, string>>();
                for (int i = 0; i < lstHashTableData.Count; i++)
                {
                    if (lstHashTableData.ToArray()[i].CellDiversionAddress == strMaxPostion)
                    {
                        var valuesTodraw = lstHashTableData.ToArray()[i];

                        string strFromDrawValue = valuesTodraw.StartCellValue;

                        string strToDrawValue = valuesTodraw.EndCellValue;

                        lstOfPlacesToDraw.Add(new KeyValuePair<string, string>(strToDrawValue, strFromDrawValue));
                        lstOfPlacedValues = lstOfPlacesToDraw.Distinct().ToList();
                    }
                }
                return lstOfPlacedValues;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        private void GetMaxNodeAndCommnVal(List<KeyValuePair<string, string>> lstOfCellDivertPostion, ref string strMaxPostion, ref string strCommonValue)
        {
            var postion = lstOfCellDivertPostion.GroupBy(x => x);
            var maxCount = postion.Max(g => g.Count());
            var mostCommons = postion.Where(x => x.Count() == maxCount).Select(x => x.Key).ToArray();
            strCommonValue = mostCommons[0].ToString();
            strMaxPostion = mostCommons[0].Value;            
        }

        private List<SheetExtraction> ConvertHashTableToList(Dictionary<string, SheetExtraction> cellDiversionsDictionary)
        {
            List<SheetExtraction> lstHashTableData = new List<SheetExtraction>();
            var listofObjects = cellDiversionsDictionary.ToDictionary(x => x.Key, x => x.Value).Values.ToList();
            foreach (var item in listofObjects)
                lstHashTableData.Add(item);
            return lstHashTableData;
        }
    }
    public class ComparedCellPosition
    {
        public string StartPoint { get; set; }
        public string EndPoint { get; set; }
        public string CellPostion { get; set; }
    }
}
