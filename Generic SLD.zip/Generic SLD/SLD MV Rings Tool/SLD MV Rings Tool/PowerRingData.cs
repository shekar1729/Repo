﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;

namespace SLD_MV_Rings_Tool
{
    public class PowerRingData
    {
        #region
        List<string[]> lstColumnNames = new List<string[]>();
        List<string> lstOfOccupiedCellAddress = new List<string>();
        CellValAndAddress clssCellValWithAddr;
        SheetExtraction clssSheetExtraction;
        PowerCellAddresses clssPowerCellAddress = new PowerCellAddresses();
        StartEndCellAddressesValues objStartEndCellAddrVal;
        #endregion

        internal List<StartEndCellAddressesValues> GetPowerRingData(int intCurrentRowCount, object[,] objClmNames, int ibaseCellStartX, int ibaseCellStartY,ref List<CellValAndAddress> lstPowerCellAfterShifted)
        {
            List<StartEndCellAddressesValues> lstPowerRingData = new List<StartEndCellAddressesValues>();
            try
            {
                //get row wise max count 
                List<int> lstMaxColumnCount = GetDataExcludeMaxRow(intCurrentRowCount, objClmNames);
                //get hightest row in given excelsheet
                List<string> lstHighestRows = RemoveMaxCountOfRow(lstMaxColumnCount, objClmNames);

                //get Cells address of hightest row
                List<CellValAndAddress> lstHighestRowCellPostions = GetHighestRowCellsAddr(lstHighestRows, ibaseCellStartX, ibaseCellStartY);

                //original list of highest cells
                List<CellValAndAddress> OriginallstHighestRowCellPostions = new List<CellValAndAddress>();
                OriginallstHighestRowCellPostions.AddRange(lstHighestRowCellPostions);

                //get diversion cell address with table
                Dictionary<string, SheetExtraction> cellDiversionsDictionary = GetCellsDiversions(lstHighestRows, lstColumnNames, lstHighestRowCellPostions);

                List<ComparedCellPosition> lstSecondTypeCellPostions = new List<ComparedCellPosition>();

                //get all cell address with value
                List<CellValAndAddress> lstPowerCellAddrAndValues = clssPowerCellAddress.GetAllPowerNwCellAddress(cellDiversionsDictionary, lstOfOccupiedCellAddress, lstHighestRowCellPostions, ibaseCellStartX, ref lstSecondTypeCellPostions);

                //cells shifting with appearanceses
                lstPowerCellAfterShifted = CellShifting(lstPowerCellAddrAndValues);
                if (lstSecondTypeCellPostions.Count != 0)
                    lstSecondTypeCellPostions = CellShifting(lstSecondTypeCellPostions);

                //Calculate Secondary cells [startPoint,startPointPosition,endPoint,endPointPostion]
                List<StartEndCellAddressesValues> SecondaryCellAddrVal = SecondaryCellsAddrValue(OriginallstHighestRowCellPostions, lstSecondTypeCellPostions);

                //Calculate Primary one Address list [startPoint,startPointPosition,endPoint,endPointPostion]
                 lstPowerRingData = PrimaryCellsAddrValue(OriginallstHighestRowCellPostions);

                //Maintain one Address list [startPoint,startPointPosition,endPoint,endPointPostion]
                //MainObjectList.....
                //.....
                //......
                 lstPowerRingData.AddRange(SecondaryCellAddrVal); // pending with drawing in Excel
                 lstColumnNames.Clear();
                 lstOfOccupiedCellAddress.Clear();
                 lstSecondTypeCellPostions.Clear();
                 return lstPowerRingData;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return lstPowerRingData;
            }
            
        }

        private List<int> GetDataExcludeMaxRow(int intCurrentRowCount, object[,] objClmNames)
        {
            List<string> lstClmName = new List<string>();
            List<int> lstMaxColumnCount = new List<int>();
            try
            {
                for (int v = 1; v <= intCurrentRowCount; v++)
                {

                    for (int colIndex = 1; colIndex <= objClmNames.GetLength(1); colIndex++)
                    {
                        if (objClmNames[v, colIndex] != null && !string.IsNullOrEmpty(objClmNames[v, colIndex].ToString()))
                        {
                            lstClmName.Add(objClmNames[v, colIndex].ToString());
                        }
                    }
                    lstColumnNames.Add(lstClmName.ToArray());
                    lstMaxColumnCount.Add(lstClmName.Count);
                    lstClmName.Clear();
                }
                return lstMaxColumnCount;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        private List<string> RemoveMaxCountOfRow(List<int> lstMaxColumnCount, object[,] objClmNames)
        {
            try
            {
                List<string> lstHighestRows = new List<string>();
                int intMaxValue = lstMaxColumnCount.Max();
                int intMaxIndex = lstMaxColumnCount.ToList().IndexOf(intMaxValue);

                for (int colIndex = 1; colIndex <= objClmNames.GetLength(1); colIndex++)
                {
                    if (objClmNames[intMaxIndex + 1, colIndex] != null && !string.IsNullOrEmpty(objClmNames[intMaxIndex + 1, colIndex].ToString()))
                    {
                        lstHighestRows.Add(objClmNames[intMaxIndex + 1, colIndex].ToString());
                    }
                }
                lstMaxColumnCount.Clear();
                if (lstColumnNames.Count > 1)
                {
                    lstColumnNames.RemoveAt(intMaxIndex);
                }
                return lstHighestRows;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        private List<CellValAndAddress> GetHighestRowCellsAddr(List<string> lstHighestRows, int ibaseCellStartX, int ibaseCellStartY)
        {
            //int baseCellYinc = 2;
            //Open the configuration file using the dll location
            Configuration myDllConfig = ConfigurationManager.OpenExeConfiguration(this.GetType().Assembly.Location);
            // Get the appSettings section
            AppSettingsSection myDllConfigAppSettings = (AppSettingsSection)myDllConfig.GetSection("appSettings");
            // return the desired field 
            int baseCellYinc = Int32.Parse(myDllConfigAppSettings.Settings["DistanceBetweenTwoCells"].Value);
            
            try
            {
                List<CellValAndAddress> lstHighestRowCellPostions = new List<CellValAndAddress>();
                string strCellValue = string.Empty;
                for (int m = 0; m < lstHighestRows.Count; m++)
                {
                    if (m == 0)
                    {
                        strCellValue = lstHighestRows[m];
                        string strCellAddressFormat = ibaseCellStartX + "," + ibaseCellStartY;
                        lstOfOccupiedCellAddress.Add(strCellAddressFormat);
                        clssCellValWithAddr = new CellValAndAddress { CellValue = strCellValue, CellAddress = strCellAddressFormat };
                        lstHighestRowCellPostions.Add(clssCellValWithAddr);

                    }
                    else
                    {
                        ibaseCellStartY = ibaseCellStartY + baseCellYinc;
                        strCellValue = lstHighestRows[m];
                        string strCellAddressFormat = ibaseCellStartX + "," + ibaseCellStartY;
                        lstOfOccupiedCellAddress.Add(strCellAddressFormat);
                        clssCellValWithAddr = new CellValAndAddress { CellValue = strCellValue, CellAddress = strCellAddressFormat };
                        lstHighestRowCellPostions.Add(clssCellValWithAddr);
                    }
                }
                ibaseCellStartY = baseCellYinc;
                return lstHighestRowCellPostions;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        private Dictionary<string, SheetExtraction> GetCellsDiversions(List<string> lstHighestRows, List<string[]> lstColumnNames, List<CellValAndAddress> lstHighestRowCellPostions)
        {
            try
            {
                List<string> lstOriginalHighestRow = new List<string>();
                Dictionary<string, SheetExtraction> cellDiversionsDictionary = new Dictionary<string, SheetExtraction>();
                lstOriginalHighestRow.AddRange(lstHighestRows);
                for (int i = 0; i < lstColumnNames.Count; i++)
                {
                    int j = 0; int k = 0;
                    j = 0; k = 0;
                    string[] strArrayClmValues = lstColumnNames[i];

                    for (int m = 0; m < strArrayClmValues.Length; m++)
                    {
                        var columnValue = strArrayClmValues[m];

                        while (j < lstHighestRows.Count)
                        {
                            string strComparedValue = lstHighestRows[j];

                            if (columnValue == strComparedValue)
                            {
                                j++;
                                break;
                            }
                            else
                            {
                                string[] strArrayReversedValues = strArrayClmValues.Reverse().ToArray();

                                while (k < strArrayReversedValues.Length)
                                {
                                    string strReversedValue = strArrayReversedValues[k];

                                    if (strReversedValue == strComparedValue)
                                    {
                                        k++; j++;
                                        break;
                                    }
                                    else
                                    {
                                        if (k != 0 || j != 0)
                                        {
                                            if (k != 0)
                                            {
                                                if (strArrayReversedValues[k - 1] == lstHighestRows[j - 1])
                                                {
                                                    string strCellAddress = GetCelladdress(lstHighestRows[j - 1], lstHighestRowCellPostions);
                                                    if (!cellDiversionsDictionary.ContainsKey("Row-" + (i + 1) + " has "))
                                                    {
                                                        string strStartCircuitValue = lstHighestRows[j - 1];
                                                        string strEndCircuitValue = strArrayReversedValues[k];
                                                        clssSheetExtraction = new SheetExtraction { RowNumber = (i + 1).ToString(), CellDiversionAddress = strCellAddress, StartCellValue = strStartCircuitValue, EndCellValue = strEndCircuitValue };
                                                        cellDiversionsDictionary.Add("Row-" + (i + 1) + " has ", clssSheetExtraction);
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        string strStartCircuitValue = strArrayReversedValues[k - 1];
                                                        string strEndCircuitValue = strArrayReversedValues[k];
                                                        clssSheetExtraction = new SheetExtraction { RowNumber = (i + 1).ToString(), CellDiversionAddress = strCellAddress, StartCellValue = strStartCircuitValue, EndCellValue = strEndCircuitValue };
                                                        cellDiversionsDictionary.Add("Row-" + (i + 1) + " has " + strArrayReversedValues[k - 1] + "", clssSheetExtraction);
                                                        break;
                                                    }
                                                }
                                            }

                                            else
                                            {
                                                string strCellAddress = GetCelladdress(lstHighestRows[j - 1], lstHighestRowCellPostions);
                                                if (!cellDiversionsDictionary.ContainsKey("Row-" + (i + 1) + " has "))
                                                {
                                                    string strStartCircuitValue = lstHighestRows[j - 1];
                                                    string strEndCircuitValue = columnValue;
                                                    clssSheetExtraction = new SheetExtraction { RowNumber = (i + 1).ToString(), CellDiversionAddress = strCellAddress, StartCellValue = strStartCircuitValue, EndCellValue = strEndCircuitValue };
                                                    cellDiversionsDictionary.Add("Row-" + (i + 1) + " has ", clssSheetExtraction);
                                                    break;
                                                }
                                                else
                                                {
                                                    string strStartCircuitValue = strArrayClmValues[m - 1];
                                                    string strEndCircuitValue = columnValue;
                                                    clssSheetExtraction = new SheetExtraction { RowNumber = (i + 1).ToString(), CellDiversionAddress = strCellAddress, StartCellValue = strStartCircuitValue, EndCellValue = strEndCircuitValue };
                                                    cellDiversionsDictionary.Add("Row-" + (i + 1) + " has " + strArrayClmValues[m - 1] + "", clssSheetExtraction);
                                                    break;
                                                }
                                            }
                                        }

                                        else
                                        {
                                            var clmValue = columnValue;
                                            for (int n = 0; n < lstHighestRows.Count; n++)
                                            {
                                                var checkComparedValue = lstHighestRows[n];

                                                if (checkComparedValue == clmValue)
                                                {
                                                    if (n != 0 || m != 0)
                                                    {
                                                        if (m != 0)
                                                        {
                                                            if (lstHighestRows[n - 1] != strArrayClmValues[m - 1])
                                                            {
                                                                string strCellAddress = GetCelladdress(checkComparedValue, lstHighestRowCellPostions);
                                                                if (!cellDiversionsDictionary.ContainsKey("Row-" + (i + 1) + " has "))
                                                                {
                                                                    string strStartCircuitValue = checkComparedValue;
                                                                    string strEndCircuitValue = strArrayClmValues[m - 1];
                                                                    clssSheetExtraction = new SheetExtraction { RowNumber = (i + 1).ToString(), CellDiversionAddress = strCellAddress, StartCellValue = strStartCircuitValue, EndCellValue = strEndCircuitValue };
                                                                    cellDiversionsDictionary.Add("Row-" + (i + 1) + " has ", clssSheetExtraction);

                                                                    break;
                                                                }
                                                                else
                                                                {
                                                                    string strStartCircuitValue = strArrayClmValues[m - 2];
                                                                    string strEndCircuitValue = strArrayClmValues[m - 1];
                                                                    clssSheetExtraction = new SheetExtraction { RowNumber = (i + 1).ToString(), CellDiversionAddress = strCellAddress, StartCellValue = strStartCircuitValue, EndCellValue = strEndCircuitValue };
                                                                    cellDiversionsDictionary.Add("Row-" + (i + 1) + " has " + strArrayClmValues[m - 2] + "", clssSheetExtraction);
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        else
                                                        {
                                                            lstHighestRows.Reverse();
                                                            break;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    if (n != 0 && m != 0)
                                                    {
                                                        if (lstHighestRows[n - 1] == strArrayClmValues[m - 1])
                                                        {
                                                            if (lstHighestRows[n] != strArrayClmValues[m])
                                                            {
                                                                string strCellAddress = GetCelladdress(lstHighestRows[n - 1], lstHighestRowCellPostions);
                                                                if (!cellDiversionsDictionary.ContainsKey("Row-" + (i + 1) + " has another Diversion "))
                                                                {
                                                                    string strStartCircuitValue = lstHighestRows[n - 1];
                                                                    string strEndCircuitValue = strArrayClmValues[m];
                                                                    clssSheetExtraction = new SheetExtraction { RowNumber = (i + 1).ToString(), CellDiversionAddress = strCellAddress, StartCellValue = strStartCircuitValue, EndCellValue = strEndCircuitValue };
                                                                    cellDiversionsDictionary.Add("Row-" + (i + 1) + " has another Diversion ", clssSheetExtraction);
                                                                    break;
                                                                }
                                                                else
                                                                {
                                                                    string strStartCircuitValue = strArrayClmValues[m - 1];
                                                                    string strEndCircuitValue = strArrayClmValues[m];
                                                                    clssSheetExtraction = new SheetExtraction { RowNumber = (i + 1).ToString(), CellDiversionAddress = strCellAddress, StartCellValue = strStartCircuitValue, EndCellValue = strEndCircuitValue };
                                                                    cellDiversionsDictionary.Add("Row-" + (i + 1) + " has another Diversion " + strArrayClmValues[m - 1] + "", clssSheetExtraction);
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    break;
                                }
                                break;
                            }

                        }
                    }
                    if (!lstHighestRows.SequenceEqual(lstOriginalHighestRow))
                    {
                        lstHighestRows.Reverse();
                    }
                }
                return cellDiversionsDictionary;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }
        //get cell wise addresses of highest row
        private string GetCelladdress(string p, List<CellValAndAddress> lstHighestRowCellPostions)
        {
            try
            {
                string strHighestRowAddr = string.Empty;
                for (int i = 0; i < lstHighestRowCellPostions.Count; i++)
                {
                    if (p == lstHighestRowCellPostions[i].CellValue)
                    {
                        strHighestRowAddr = lstHighestRowCellPostions[i].CellAddress;
                    }
                }
                return strHighestRowAddr;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        private List<CellValAndAddress> CellShifting(List<CellValAndAddress> lstPowerCellAddrAndValues)
        {
            List<int> lstOfCells = new List<int>();
            int iRows = 0;
            int iFixedVal = 4;
            try
            {
                for (int i = 0; i < lstPowerCellAddrAndValues.Count; i++)
                {
                    string strPostion = lstPowerCellAddrAndValues[i].CellAddress;
                    var postionCells = strPostion.Split(',');
                    int rowCell = Int32.Parse(postionCells[0]);
                    lstOfCells.Add(rowCell);
                }
                List<int> lstunique = lstOfCells.Distinct().ToList();
                iRows = lstunique.Min();

                int iDelAddVal = iRows - iFixedVal;

                for (int j = 0; j < lstPowerCellAddrAndValues.Count; j++)
                {
                    string strCellPostion = lstPowerCellAddrAndValues[j].CellAddress;
                    var varPostionCells = strCellPostion.Split(',');
                    string strSplitCellsY = varPostionCells[1];

                    string strStartpoX = (Int32.Parse(varPostionCells[0]) - iDelAddVal).ToString();

                    string strCellPostionFormat = strStartpoX + "," + strSplitCellsY;

                    lstPowerCellAddrAndValues[j].CellAddress = strCellPostionFormat;
                }

                return lstPowerCellAddrAndValues;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return lstPowerCellAddrAndValues;
            }
        }

        private List<ComparedCellPosition> CellShifting(List<ComparedCellPosition> lstSecondTypeCellPostions)
        {
            List<int> lstOfCells = new List<int>();
            int iRows = 0;
            int iFixedVal = 4;
            try
            {
                for (int i = 0; i < lstSecondTypeCellPostions.Count; i++)
                {
                    string Postion = lstSecondTypeCellPostions[i].CellPostion;
                    var postionCells = Postion.Split(',');
                    int rowCell = Int32.Parse(postionCells[0]);
                    lstOfCells.Add(rowCell);
                }
                List<int> lstunique = lstOfCells.Distinct().ToList();
                iRows = lstunique.Min();

                int iDelAddVal = iRows - iFixedVal;


                for (int j = 0; j < lstSecondTypeCellPostions.Count; j++)
                {
                    string strCellPostion = lstSecondTypeCellPostions[j].CellPostion;
                    var varPostionCells = strCellPostion.Split(',');
                    string strSplitCellsY = varPostionCells[1];
                    string strStartpoX = (Int32.Parse(varPostionCells[0]) - iDelAddVal).ToString();

                    string strCellPostionFormat = strStartpoX + "," + strSplitCellsY;
                    lstSecondTypeCellPostions[j].CellPostion = strCellPostionFormat;
                }

                return lstSecondTypeCellPostions;
            }
            catch
            {
                throw;
            }
        }

        private List<StartEndCellAddressesValues> SecondaryCellsAddrValue(List<CellValAndAddress> lstHighestRowCellPostions, List<ComparedCellPosition> lstSecondTypeCellPostions)
        {
            List<StartEndCellAddressesValues> SecondaryCellAddrVal = new List<StartEndCellAddressesValues>();
            try
            {
                for (int i = 0; i < lstHighestRowCellPostions.Count; i++)
                {
                    for (int j = 0; j < lstSecondTypeCellPostions.Count; j++)
                    {
                        if (lstSecondTypeCellPostions.ToArray()[j].StartPoint == lstHighestRowCellPostions.ToArray()[i].CellValue)
                        {
                            string StartValue = lstHighestRowCellPostions.ToArray()[i].CellValue;
                            string StartValuePosition = lstHighestRowCellPostions.ToArray()[i].CellAddress;
                            string EndValue = lstSecondTypeCellPostions.ToArray()[j].EndPoint;
                            string EndValuePosition = lstSecondTypeCellPostions.ToArray()[j].CellPostion;
                            objStartEndCellAddrVal = new StartEndCellAddressesValues { StartValue = StartValue, StartValuePosition = StartValuePosition, EndValue = EndValue, EndValuePostion = EndValuePosition };
                            SecondaryCellAddrVal.Add(objStartEndCellAddrVal);
                        }

                    }
                }
                for (int k = 0; k < lstSecondTypeCellPostions.Count; k++)
                {
                    string _endPoint_S = lstSecondTypeCellPostions.ToArray()[k].EndPoint;
                    string _cellPostion_S = lstSecondTypeCellPostions.ToArray()[k].CellPostion;
                    for (int l = 0; l < lstSecondTypeCellPostions.Count; l++)
                    {
                        if (_endPoint_S == lstSecondTypeCellPostions.ToArray()[l].StartPoint)
                        {
                            string _endPoint = lstSecondTypeCellPostions.ToArray()[l].EndPoint;
                            string _cellPostion = lstSecondTypeCellPostions.ToArray()[l].CellPostion;
                            objStartEndCellAddrVal = new StartEndCellAddressesValues { StartValue = _endPoint_S, StartValuePosition = _cellPostion_S, EndValue = _endPoint, EndValuePostion = _cellPostion };
                            SecondaryCellAddrVal.Add(objStartEndCellAddrVal);
                        }
                    }
                }
                return SecondaryCellAddrVal;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return SecondaryCellAddrVal;
            }
        }

        private List<StartEndCellAddressesValues> PrimaryCellsAddrValue(List<CellValAndAddress> OriginallstHighestRowCellPostions)
        {
            List<StartEndCellAddressesValues> PrimaryCellsAddrVal = new List<StartEndCellAddressesValues>();
            try
            {
                for (int i = 0; i < OriginallstHighestRowCellPostions.Count; i++)
                {
                    string strStartVal = OriginallstHighestRowCellPostions[i].CellValue;
                    string strStartPosition = OriginallstHighestRowCellPostions[i].CellAddress;
                    if (OriginallstHighestRowCellPostions.ElementAtOrDefault(i + 1) != null)
                    {
                        string strEndVal = OriginallstHighestRowCellPostions[i + 1].CellValue;
                        string strEndPosition = OriginallstHighestRowCellPostions[i + 1].CellAddress;
                        objStartEndCellAddrVal = new StartEndCellAddressesValues { StartValue = strStartVal, StartValuePosition = strStartPosition, EndValue = strEndVal, EndValuePostion = strEndPosition };
                        PrimaryCellsAddrVal.Add(objStartEndCellAddrVal);
                    }
                }
                return PrimaryCellsAddrVal;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return PrimaryCellsAddrVal;
            }
        }

        
    }
}
