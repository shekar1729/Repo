﻿namespace SLD_MV_Rings_Tool
{
    partial class SLDMVRingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SLDMVRingForm));
            this.brnBrowseSelect = new System.Windows.Forms.Button();
            this.btnBrowsePath = new System.Windows.Forms.Button();
            this.lblSelectFile = new System.Windows.Forms.Label();
            this.lblReportPath = new System.Windows.Forms.Label();
            this.txtBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.firstListBox = new System.Windows.Forms.ListBox();
            this.secondListBox = new System.Windows.Forms.ListBox();
            this.right = new System.Windows.Forms.Button();
            this.left = new System.Windows.Forms.Button();
            this.btnSld = new System.Windows.Forms.Button();
            this.lblProcess = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // brnBrowseSelect
            // 
            this.brnBrowseSelect.Location = new System.Drawing.Point(494, 9);
            this.brnBrowseSelect.Name = "brnBrowseSelect";
            this.brnBrowseSelect.Size = new System.Drawing.Size(75, 23);
            this.brnBrowseSelect.TabIndex = 0;
            this.brnBrowseSelect.Text = "Browse";
            this.brnBrowseSelect.UseVisualStyleBackColor = true;
            this.brnBrowseSelect.Click += new System.EventHandler(this.BrowseExcelAndValidate);
            // 
            // btnBrowsePath
            // 
            this.btnBrowsePath.Location = new System.Drawing.Point(494, 39);
            this.btnBrowsePath.Name = "btnBrowsePath";
            this.btnBrowsePath.Size = new System.Drawing.Size(75, 24);
            this.btnBrowsePath.TabIndex = 0;
            this.btnBrowsePath.Text = "Browse";
            this.btnBrowsePath.UseVisualStyleBackColor = true;
            this.btnBrowsePath.Click += new System.EventHandler(this.btnBrowsePath_Click);
            // 
            // lblSelectFile
            // 
            this.lblSelectFile.AutoSize = true;
            this.lblSelectFile.Location = new System.Drawing.Point(14, 13);
            this.lblSelectFile.Name = "lblSelectFile";
            this.lblSelectFile.Size = new System.Drawing.Size(56, 13);
            this.lblSelectFile.TabIndex = 1;
            this.lblSelectFile.Text = "SelectFile:";
            // 
            // lblReportPath
            // 
            this.lblReportPath.AutoSize = true;
            this.lblReportPath.Location = new System.Drawing.Point(14, 42);
            this.lblReportPath.Name = "lblReportPath";
            this.lblReportPath.Size = new System.Drawing.Size(67, 13);
            this.lblReportPath.TabIndex = 1;
            this.lblReportPath.Text = "Report Path:";
            // 
            // txtBox1
            // 
            this.txtBox1.Location = new System.Drawing.Point(87, 9);
            this.txtBox1.Name = "txtBox1";
            this.txtBox1.ReadOnly = true;
            this.txtBox1.Size = new System.Drawing.Size(392, 20);
            this.txtBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(87, 39);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(392, 20);
            this.textBox2.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.firstListBox);
            this.groupBox1.Controls.Add(this.secondListBox);
            this.groupBox1.Controls.Add(this.right);
            this.groupBox1.Controls.Add(this.left);
            this.groupBox1.Location = new System.Drawing.Point(17, 69);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(543, 235);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select sheet";
            // 
            // firstListBox
            // 
            this.firstListBox.FormattingEnabled = true;
            this.firstListBox.Location = new System.Drawing.Point(6, 17);
            this.firstListBox.Name = "firstListBox";
            this.firstListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.firstListBox.Size = new System.Drawing.Size(224, 212);
            this.firstListBox.TabIndex = 7;
            // 
            // secondListBox
            // 
            this.secondListBox.FormattingEnabled = true;
            this.secondListBox.Location = new System.Drawing.Point(317, 17);
            this.secondListBox.Name = "secondListBox";
            this.secondListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.secondListBox.Size = new System.Drawing.Size(217, 212);
            this.secondListBox.TabIndex = 8;
            // 
            // right
            // 
            this.right.Location = new System.Drawing.Point(236, 84);
            this.right.Name = "right";
            this.right.Size = new System.Drawing.Size(75, 32);
            this.right.TabIndex = 9;
            this.right.Text = ">";
            this.right.UseVisualStyleBackColor = true;
            this.right.Click += new System.EventHandler(this.right_Click);
            // 
            // left
            // 
            this.left.Location = new System.Drawing.Point(236, 122);
            this.left.Name = "left";
            this.left.Size = new System.Drawing.Size(75, 31);
            this.left.TabIndex = 9;
            this.left.Text = "<";
            this.left.UseVisualStyleBackColor = true;
            this.left.Click += new System.EventHandler(this.left_Click);
            // 
            // btnSld
            // 
            this.btnSld.Enabled = false;
            this.btnSld.Location = new System.Drawing.Point(469, 310);
            this.btnSld.Name = "btnSld";
            this.btnSld.Size = new System.Drawing.Size(94, 23);
            this.btnSld.TabIndex = 14;
            this.btnSld.Text = "Generate SLD";
            this.btnSld.UseVisualStyleBackColor = true;
            this.btnSld.Click += new System.EventHandler(this.btnGenerateSLD_Click);
            // 
            // lblProcess
            // 
            this.lblProcess.AutoSize = true;
            this.lblProcess.Location = new System.Drawing.Point(23, 319);
            this.lblProcess.Name = "lblProcess";
            this.lblProcess.Size = new System.Drawing.Size(0, 13);
            this.lblProcess.TabIndex = 15;
            // 
            // SLDMVRingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(575, 339);
            this.Controls.Add(this.lblProcess);
            this.Controls.Add(this.btnSld);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.txtBox1);
            this.Controls.Add(this.lblReportPath);
            this.Controls.Add(this.lblSelectFile);
            this.Controls.Add(this.btnBrowsePath);
            this.Controls.Add(this.brnBrowseSelect);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SLDMVRingForm";
            this.Text = "SLD MVRing Form";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button brnBrowseSelect;
        private System.Windows.Forms.Button btnBrowsePath;
        private System.Windows.Forms.Label lblSelectFile;
        private System.Windows.Forms.Label lblReportPath;
        private System.Windows.Forms.TextBox txtBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox firstListBox;
        private System.Windows.Forms.ListBox secondListBox;
        private System.Windows.Forms.Button right;
        private System.Windows.Forms.Button left;
        private System.Windows.Forms.Button btnSld;
        private System.Windows.Forms.Label lblProcess;
    }
}