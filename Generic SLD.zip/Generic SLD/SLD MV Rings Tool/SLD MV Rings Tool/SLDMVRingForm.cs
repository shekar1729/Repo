﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using Microsoft.Office.Interop.Excel;
using ESRI.ArcGIS.Framework;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.Geodatabase;
using System.Reflection;

namespace SLD_MV_Rings_Tool
{
    public partial class SLDMVRingForm : Form
    {
        #region Variable Declaration
        global::ESRI.ArcGIS.Framework.IApplication globalESRIArcGISFrameworkIApplication;
        IMxDocument pMxDoc;
        public IMap pMap;
        private IWorkspace pWorkSpace;
        private IFeatureWorkspace pFeatureWorkspace;
        private IFeatureLayer pFeatLayer;
        public IFeatureClass pF_PatchLocation, pF_FiberCable;
        string strCableLayerName = "FIBEROPTICCABLE";
        string strCableLayerNamepl = "PatchLocation";
        string strCableLayerNamefb = "FiberOpticCable";
        private IMouseCursor appCursor;
        Microsoft.Office.Interop.Excel.Application xlApplication;
        Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
        Microsoft.Office.Interop.Excel.Worksheet xlWorksheet;
        int ibaseCellStartX = 12;
        int ibaseCellStartY = 2;
        CellValAndAddress clssCellValWithAddr;
        PowerRingData objPowerRingData = new PowerRingData();
        GISFunctionalities objGisClass = new GISFunctionalities();
        ElectricalCircuitFun objElectricalFun = new ElectricalCircuitFun();
        DrawNetworks objClssDrawNetwork = new DrawNetworks();
        StartEndCellAddressesValues objStartEndCellAddrVals;

        //create excel objects
        Microsoft.Office.Interop.Excel.Application Application;
        Microsoft.Office.Interop.Excel.Workbook WorkBook;
        Microsoft.Office.Interop.Excel.Worksheet WorkSheet;
        Microsoft.Office.Interop.Excel.Range ExcelRange;
        #endregion

        public SLDMVRingForm(global::ESRI.ArcGIS.Framework.IApplication globalESRIArcGISFrameworkIApplication)
        {
            InitializeComponent();
            this.globalESRIArcGISFrameworkIApplication = globalESRIArcGISFrameworkIApplication;
            pMxDoc = globalESRIArcGISFrameworkIApplication.Document as IMxDocument;
            pMap = pMxDoc.FocusMap;
        }

        private void btnSld_Click(object sender, EventArgs e)
        {

        }

        //Input Validatiopns
        //Browse input Excelfile into textbox and validate 
        private void BrowseExcelAndValidate(object sender, EventArgs e)
        {
            try
            {
                using (OpenFileDialog dlgFileOpen = new OpenFileDialog() { Filter = "EXCEL|*.xlsx", ValidateNames = true })
                {
                    if (dlgFileOpen.ShowDialog() == DialogResult.OK)
                    {
                        dlgFileOpen.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                        dlgFileOpen.Multiselect = false;
                        dlgFileOpen.ValidateNames = true;
                        dlgFileOpen.DereferenceLinks = false;
                        dlgFileOpen.Filter = "EXCEL|*.xlsx";
                        string strFileName = dlgFileOpen.FileName;
                        txtBox1.Text = dlgFileOpen.FileName;
                        appCursor = new MouseCursorClass();
                        appCursor.SetCursor(2);
                        //Validate is this Excel File or Not
                        if (txtBox1.Text != "" && txtBox1.Text != null)
                        {
                            string strFileExt = System.IO.Path.GetExtension(txtBox1.Text);

                            if ((strFileExt != ".xlsx") || (string.IsNullOrEmpty(txtBox1.Text)))
                            {
                                MessageBox.Show("Please select excel file only..!");
                                appCursor.SetCursor(0);
                            }
                            else
                            {
                                //Load excel sheets into firstlistbox
                                if (!LoadExcelsheetsIntoListBox(txtBox1.Text))
                                {
                                    MessageBox.Show("Couldn't load the excelsheets for given excel file..");
                                } 
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please select excel file to proceed", "Input Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            appCursor.SetCursor(0);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //load excelsheets into firstlistbox
        private bool LoadExcelsheetsIntoListBox(string ExcelPath)
        {
            try
            {
                firstListBox.Items.Clear();
                secondListBox.Items.Clear();
                if (secondListBox.Items.Count < 1)
                {
                    btnSld.Enabled = false;
                    xlApplication = new Microsoft.Office.Interop.Excel.Application();
                    xlWorkBook = xlApplication.Workbooks.Open(ExcelPath);
                    String[] strExcelSheets = new String[xlWorkBook.Worksheets.Count];

                    int i = 0;
                    foreach (Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet in xlWorkBook.Worksheets)
                    {                       
                        strExcelSheets[i] = xlWorkSheet.Name;
                        i++;
                    }
                    for (int x = 0; x < strExcelSheets.Length; x++)
                    {
                        firstListBox.Items.Add(strExcelSheets.ElementAt(x));
                        firstListBox.Sorted = true;
                        appCursor.SetCursor(0);
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                if (xlApplication != null)
                {
                    xlApplication.Quit();
                    Marshal.ReleaseComObject(xlApplication);
                    Marshal.ReleaseComObject(xlWorkBook);                   
                }
            }
        }

        //Move firstlistbox items to secondlistbox 
        private void right_Click(object sender, EventArgs e)
        {
            MoveListBoxItems(firstListBox, secondListBox);
            if (secondListBox.Items.Count < 1)
            {
                btnSld.Enabled = false;
            }
            else
            {
                btnSld.Enabled = true;
            }
        }

        //Move secondlistbox items to firstlistbox
        private void left_Click(object sender, EventArgs e)
        {
            MoveListBoxItems(secondListBox, firstListBox);
            if (secondListBox.Items.Count < 1)
            {
                btnSld.Enabled = false;
            }
            else
            {
                btnSld.Enabled = true;
            }
        }

        private void MoveListBoxItems(System.Windows.Forms.ListBox source, System.Windows.Forms.ListBox destination)
        {
            System.Windows.Forms.ListBox.SelectedObjectCollection sourceItems = source.SelectedItems;
            foreach (var item in sourceItems)
            {
                destination.Items.Add(item);
            }
            int total = source.SelectedItems.Count;
            for (int i = 0; i < total; i++)
            {
                source.Items.Remove(source.SelectedItems[0]);
            }
        }

        //browse folder path for mvRings sheets
        private void btnBrowsePath_Click(object sender, EventArgs e)
        {
            try
            {
                FolderBrowserDialog folderDlg = new FolderBrowserDialog();
                folderDlg.ShowNewFolderButton = true;
                DialogResult result = folderDlg.ShowDialog();
                if (result == DialogResult.OK)
                {
                    textBox2.Text = folderDlg.SelectedPath;
                    Environment.SpecialFolder root = folderDlg.RootFolder;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }       
        }

        //Generate SLD
        private void btnGenerateSLD_Click(object sender, EventArgs e)
        {
            List<CellValAndAddress> lstPowerCellAfterShifted = new List<CellValAndAddress>();
            try
            {
                xlApplication = new Microsoft.Office.Interop.Excel.Application();
                xlWorkBook = xlApplication.Workbooks.Open(txtBox1.Text); 
                string strError = string.Empty;
                appCursor = new MouseCursorClass();
                appCursor.SetCursor(2);
                //disable all buttons
                btnSld.Enabled = false;
                brnBrowseSelect.Enabled = false;
                btnBrowsePath.Enabled = false;
                //update label
                lblProcess.Text = "";
                lblProcess.Refresh();
                lblProcess.Text = "Processing...";
                //validate form
                if (!ValidateMVRingsForm(ref strError))
                {
                    MessageBox.Show(strError);
                    lblProcess.Text = "";
                    brnBrowseSelect.Enabled = true;
                    btnBrowsePath.Enabled = true;
                    btnSld.Enabled = true;
                    appCursor.SetCursor(0);
                }
                else
                {
                    for (int i = 0; i < secondListBox.Items.Count; i++)
                    {
                        //Excel Input 
                        //pending with notepad and paints
                        string strSheetName = secondListBox.Items[i].ToString();                        
                        xlWorksheet = (Worksheet)xlWorkBook.Sheets[strSheetName];
                        Microsoft.Office.Interop.Excel.Range range = (Microsoft.Office.Interop.Excel.Range)xlWorksheet.Columns[1];
                        int intCurrentRowCount = range.CurrentRegion.Rows.Count;
                        int intCurrentColCount = range.CurrentRegion.Columns.Count;
                        Range dataRange = xlWorksheet.UsedRange;
                        object[,] objClmNames = (object[,])dataRange.get_Value(XlRangeValueDataType.xlRangeValueDefault);

                        //get powerRing Data[startCellValue,startCellAddress,endCellValue,endCellAddress]
                        List<StartEndCellAddressesValues> lstPowerRingData = objPowerRingData.GetPowerRingData(intCurrentRowCount, objClmNames, ibaseCellStartX, ibaseCellStartY, ref lstPowerCellAfterShifted);

                        //lstPowerCellAfterShifted = (
                        //    from o in lstPowerCellAfterShifted
                        //    orderby o.CellAddress, o.CellValue
                        //    group o by o.CellValue into g
                        //    select g.First()).ToList();

                        lstPowerCellAfterShifted = lstPowerCellAfterShifted.GroupBy(x => x.CellValue).Select(y => y.First()).ToList();

                        int iMinRow = 0;
                        int iMaxFiber=0;

                        //calculate the Electric circuits cell postions to extend and defination
                        int iRowExtend = CalElectricRowToExtend(lstPowerCellAfterShifted, ref iMinRow);

                        //Increase power rings address to draw electrical cell address 
                        List<StartEndCellAddressesValues> lstIncreasedElectricalCells = ElectricalAddress(lstPowerRingData, iRowExtend);

                        //get Electrical cell postions like [Postions, Values]
                        List<CellValAndAddress> lstElectricalCellPostionsVals = CalElectricalCellPossVals(lstPowerCellAfterShifted,iRowExtend);

                        //calculate min cell postion of fiber ring
                        int iPowerMinRow = CalPowerMinCellAddrr(lstElectricalCellPostionsVals ,ref iMaxFiber);

                        //The Main Functionality begins from here...
                        //get Connected all nodes from input node and FiberConnection between nodes and Cables
                        //First Try to Find the Which type of node i.e (Input Nodes)
                        //Get CutomerTypes Node or Primary TypeNodes
                        //Check Fiberconnections
                        //Get FeatureWorkspace
                        objGisClass.GetFeaWorkspace(pMap, out pWorkSpace, out pFeatureWorkspace, out pFeatLayer, strCableLayerName);
                        //open featureClass tables
                        objGisClass.openFeatureClassTables(ref pF_PatchLocation, ref pF_FiberCable, pFeatureWorkspace, strCableLayerNamepl, strCableLayerNamefb, pFeatLayer, pWorkSpace);
                        
                        //ElectricalFunctionality
                        List<StartEndCellAddressesValues> lstConnectedNodes = new List<StartEndCellAddressesValues>();
                        List<StartEndCellAddressesValues> lstNotConnectedNodes = new List<StartEndCellAddressesValues>();
                        List<StartEndCellAddressesValues> lstNewlyConnectedNodes = new List<StartEndCellAddressesValues>();
                        List<StartEndCellAddressesValues> lstCoonectedWithInCircuit = new List<StartEndCellAddressesValues>();


                        //Electrical Circuit Functionalities and Real Time Objects
                        objElectricalFun.ElectricalMainFunctionality(lstElectricalCellPostionsVals, pF_PatchLocation, pF_FiberCable, lstIncreasedElectricalCells, ref lstConnectedNodes, ref lstNotConnectedNodes, ref lstNewlyConnectedNodes, ref lstCoonectedWithInCircuit);


                        //Create Excel to Print N/W
                        CreateNewExcel(strSheetName, textBox2.Text);

                        //draw power cable network
                        objClssDrawNetwork.DrawPowerCableNetWork(lstPowerRingData, ExcelRange,WorkSheet);

                        //Draw Fiber cable network
                        objClssDrawNetwork.DrawFiberCableNetWork(lstConnectedNodes, lstNotConnectedNodes, lstNewlyConnectedNodes, lstCoonectedWithInCircuit, ExcelRange, WorkSheet, pF_FiberCable);

                        //POWER CABLE RING,FIBER CABLE RING address
                        Dictionary<string, string> dicCellValueAddrress = new Dictionary<string, string>();
                        string strVal= "2";
                        int iVal = 2;
                       // string strPower = (iMinRow - iVal).ToString();
                        string strPowerFormat = (iMinRow - iVal + "," + strVal).ToString();
                        string strFiberFormat = (iPowerMinRow - iVal + "," + strVal).ToString();
                        dicCellValueAddrress.Add(strPowerFormat, "POWER CABLE RING");
                        dicCellValueAddrress.Add(strFiberFormat, "FIBER CABLE RING");

                        //
                        objClssDrawNetwork.DrawDefinations(dicCellValueAddrress,ExcelRange, WorkSheet);
                        
                        //Draw Legend
                        if (lstNewlyConnectedNodes.Count > 0)
                        {
                            List<int> lstRows = new List<int>();
                            for (int k = 0; k < lstNewlyConnectedNodes.Count; k++)
                            {
                                int strPosition = Int32.Parse(lstNewlyConnectedNodes[k].EndValuePostion.Split(',')[0]);
                                lstRows.Add(strPosition);
                            }
                            List<int> lstUniqueRows = lstRows.Distinct().ToList();
                            int iMaxNewCell = lstUniqueRows.Max();

                            objClssDrawNetwork.DrawLegend(iMaxNewCell, ExcelRange, WorkSheet);

                        }
                        else
                        {
                            //iMaxFiber
                            //Draw legend
                            objClssDrawNetwork.DrawLegend(iMaxFiber, ExcelRange, WorkSheet);
                        }

                        lstConnectedNodes.Clear();
                        lstNotConnectedNodes.Clear();
                        lstNewlyConnectedNodes.Clear();
                        lstCoonectedWithInCircuit.Clear();
                        Application.ActiveWindow.DisplayGridlines = false;
                        WorkSheet.Columns.Locked = true;
                        WorkSheet.Rows.Locked = true;
                        WorkSheet.Protect(UserInterfaceOnly: true);
                        WorkBook.Close(SaveChanges: true);
                        Application.Quit();
                        lblProcess.Text = (i + 1) + " Out of " + secondListBox.Items.Count + " SLD Generated.";
                        appCursor.SetCursor(2);
                        if (Application != null)
                        {
                            //clear newly created excel objects
                            Application.Quit();
                            Marshal.ReleaseComObject(Application);
                            Marshal.ReleaseComObject(WorkBook);
                            Marshal.ReleaseComObject(WorkSheet);
                        }
                    }
                    appCursor.SetCursor(0);
                    lblProcess.Text = "Report generated successfully";   
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                btnSld.Enabled = true;
                brnBrowseSelect.Enabled = true;
                btnBrowsePath.Enabled = true;
                if (xlApplication != null)
                {
                    xlApplication.Quit();
                    Marshal.ReleaseComObject(xlApplication);
                    Marshal.ReleaseComObject(xlWorkBook);
                    Marshal.ReleaseComObject(xlWorksheet);
                }
            }
        }

        private void CreateNewExcel(string strSheetName, string p)
        {
            try
            {
                int xlrowCount = 0;
                int xlcolCount = 0;
                object misValue = Missing.Value;
                Application = new Microsoft.Office.Interop.Excel.Application();
                WorkBook = Application.Workbooks.Add(misValue);
                WorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)WorkBook.Worksheets.get_Item(1);
                ExcelRange = WorkSheet.UsedRange;
                xlrowCount = ExcelRange.Rows.Count;
                xlcolCount = ExcelRange.Columns.Count;
                string strOutFileName = string.Format("SLD_MVRing_" + strSheetName + "_{0:yyyy-MM-dd_hh-mm-ss}", DateTime.Now);
                WorkBook.SaveAs(p + "\\" + strOutFileName + ".xlsx", misValue, misValue, misValue, misValue, misValue, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private int CalPowerMinCellAddrr(List<CellValAndAddress> lstElectricalCellPostionsVals,ref int iMaxFiber)
        {
            int iPowerMinRow = 0;
            List<int> lstRows = new List<int>();
            try
            {
                for (int i = 0; i < lstElectricalCellPostionsVals.Count; i++)
                {
                    int strPosition = Int32.Parse(lstElectricalCellPostionsVals[i].CellAddress.Split(',')[0]);
                    lstRows.Add(strPosition);
                }
                List<int> lstUniqueRows = lstRows.Distinct().ToList();
                iPowerMinRow = lstUniqueRows.Min();
                iMaxFiber = lstUniqueRows.Max();
                return iPowerMinRow;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return iPowerMinRow;
            }
        }

        private List<StartEndCellAddressesValues> ElectricalAddress(List<StartEndCellAddressesValues> lstPowerRingData, int iRowExtend)
        {
            List<StartEndCellAddressesValues> lstIncreasedElectricalCells = new List<StartEndCellAddressesValues>();
            try
            {
                for (int i = 0; i < lstPowerRingData.Count; i++)
                {
                    //Increased StartValue Postions
                    string strStartValuePostion = lstPowerRingData[i].StartValuePosition;
                    string strStartRowCell = ((Int32.Parse(strStartValuePostion.Split(',')[0])) + iRowExtend).ToString();
                    string strStartColumnCell = strStartValuePostion.Split(',')[1];
                    string strStartCellAddressFormat = strStartRowCell + "," + strStartColumnCell;
                    string strStartCellValue = lstPowerRingData[i].StartValue;

                    //Increased EndValue Postions
                    string strEndValuePostion = lstPowerRingData[i].EndValuePostion;
                    string strEndRowCell = ((Int32.Parse(strEndValuePostion.Split(',')[0])) + iRowExtend).ToString();
                    string strEndColumnCell = strEndValuePostion.Split(',')[1];
                    string strEndCellAddressFormat = strEndRowCell + "," + strEndColumnCell;
                    string strEndCellValue = lstPowerRingData[i].EndValue;

                    objStartEndCellAddrVals = new StartEndCellAddressesValues { StartValue = strStartCellValue, StartValuePosition = strStartCellAddressFormat, EndValue = strEndCellValue, EndValuePostion = strEndCellAddressFormat };
                    lstIncreasedElectricalCells.Add(objStartEndCellAddrVals);
                }
                return lstIncreasedElectricalCells;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return lstIncreasedElectricalCells;
            }
        }

        private List<CellValAndAddress> CalElectricalCellPossVals(List<CellValAndAddress> lstPowerCellAfterShifted, int iRowExtend)
        {
            List<CellValAndAddress> lstElectricalCellPostionsVals = new List<CellValAndAddress>();
            try
            {
                for (int i = 0; i < lstPowerCellAfterShifted.Count; i++)
                {
                    string strRowCell = ((Int32.Parse(lstPowerCellAfterShifted[i].CellAddress.Split(',')[0])) + iRowExtend).ToString();
                    string strColumnCell = lstPowerCellAfterShifted[i].CellAddress.Split(',')[1];
                    string strCellAddressFormat = strRowCell + "," + strColumnCell;
                    string strCellValue = lstPowerCellAfterShifted[i].CellValue;
                    clssCellValWithAddr = new CellValAndAddress { CellValue = strCellValue, CellAddress = strCellAddressFormat };
                    lstElectricalCellPostionsVals.Add(clssCellValWithAddr);
                }
                return lstElectricalCellPostionsVals;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return lstElectricalCellPostionsVals;
            }
        }

        private int CalElectricRowToExtend(List<CellValAndAddress> lstPowerCellAfterShifted,ref int iMinRow)
        {
            int iRowExtend = 0;
            List<int> lstRows = new List<int>();
            try
            {
                for (int i = 0; i < lstPowerCellAfterShifted.Count; i++)
                {
                    int strPosition = Int32.Parse(lstPowerCellAfterShifted[i].CellAddress.Split(',')[0]);
                    lstRows.Add(strPosition);
                }
                List<int> lstUniqueRows = lstRows.Distinct().ToList();
                iRowExtend = lstUniqueRows.Max();
                iMinRow = lstUniqueRows.Min();
                return iRowExtend;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return iRowExtend;
            }
        }

       

        

        

      

       
       
        private bool ValidateMVRingsForm(ref string strError)
        {
            try
            {               
                if (secondListBox.Items.Count > 0)
                {
                    if (string.IsNullOrEmpty(textBox2.Text))
                    {
                        strError = "Please select folder to generate MVRings reports..";
                        return false;
                    }                   
                }
                else
                {
                    strError = "Please move selected sheets to second listbox...";
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        

       

        
       
    }
    public class SheetExtraction
    {
        public string RowNumber { get; set; }
        public string CellDiversionAddress { get; set; }
        public string StartCellValue { get; set; }
        public string EndCellValue { get; set; }
    }

    public class CellValAndAddress
    {
        public string CellValue { get; set; }
        public string CellAddress { get; set; }
    }

    public class StartEndCellAddressesValues
    {
        public string StartValue { get; set; }
        public string StartValuePosition { get; set; }
        public string EndValue { get; set; }
        public string EndValuePostion { get; set; }
    }
}
