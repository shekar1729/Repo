﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Framework;
using System.Windows.Forms;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geodatabase;

namespace cemOTDRTrace
{
    public class clsCemOTDRTrace : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        #region Global Variables
        IMxDocument m_MxDoc;
        IMap pMap;
        IActiveView pActiveView;
        frmCemOTDRTraceSelector objOTDRtraceSelector = new frmCemOTDRTraceSelector();
        #endregion

        ///// <summary>
        ///// Constructor
        ///// </summary>
        public clsCemOTDRTrace()
        {
        }

        protected override void OnClick()
        {
            //
            //  TODO: Sample code showing how to access button host
            //
            ArcMap.Application.CurrentTool = null;

            m_MxDoc = (IMxDocument)ArcMap.Application.Document;
            pMap = m_MxDoc.FocusMap;
            pActiveView = (IActiveView)pMap;

            Boolean blnIsLayer = IsLayerExist();
            if (blnIsLayer == true)
            {
                Boolean fromFound = false;
                foreach (Form item in Application.OpenForms)
                {
                    if (item.Name == "frmCemOTDRTraceSelector")
                    {
                        fromFound = true;
                    }
                }
                if (fromFound == false)
                {
                    objOTDRtraceSelector = new frmCemOTDRTraceSelector();
                    objOTDRtraceSelector.pMap = pMap;
                    objOTDRtraceSelector.pActiveView = pActiveView;
                    //objOTDRtraceSelector.Show(new ArcMapWindow(ArcMap.Application));
                    objOTDRtraceSelector.Show(ArcMap.Application as IWin32Window);
                }
                else
                {
                    objOTDRtraceSelector.pMap = pMap;
                    objOTDRtraceSelector.pActiveView = pActiveView;
                }
            }
        }

        protected override void OnUpdate()
        {
            try
            {
                IExtension editExtension = ArcMap.Application.FindExtensionByName("Fiber Manager");
                if (editExtension != null)
                {
                    var extensionManager = (IExtensionManager)ArcMap.Application;
                    for (int i = 0; i < extensionManager.ExtensionCount; i++)
                    {
                        var extension = extensionManager.Extension[i];
                        var config = extension as IExtensionConfig;
                        if (extension.Name == editExtension.Name)
                        {
                            if (config.State == esriExtensionState.esriESEnabled)
                            {
                                Enabled = true;
                            }
                            else
                                Enabled = false;
                        }
                    }
                }
                else
                    Enabled = false;
            }
            catch
            {
                Enabled = false;
            }
        }

        public class ArcMapWindow : System.Windows.Forms.IWin32Window
        {
            private IApplication m_app;
            public ArcMapWindow(IApplication application)
            {
                m_app = application;
            }

            public System.IntPtr Handle
            {
                get { return new IntPtr(m_app.hWnd); }
            }

        }

        /// <summary>
        /// function to check required layers avaialbale or not on open map
        /// </summary>
        /// <returns></returns>
        private Boolean IsLayerExist()
        {
            ILayer pLayer = null;
            string strLayers = "";
            string strTempValidate = "";
            Boolean isSplice = false;
            Boolean isPL = false;
            Boolean isCable = false;

            for (int nCnt = 0; nCnt < pMap.LayerCount; nCnt++)
            {
                ILayer pTempLayer = pMap.get_Layer(nCnt);
                IFeatureLayer pflayer = null;
            eh:
                if (pTempLayer is IGroupLayer)
                {
                    ICompositeLayer pCompLyr = (ICompositeLayer)pTempLayer;

                    for (int iInt = 0; iInt < pCompLyr.Count; iInt++)
                    {
                        pTempLayer = pCompLyr.get_Layer(iInt);
                        if (pTempLayer is IGroupLayer)
                            goto eh;
                        pflayer = pCompLyr.get_Layer(iInt) as IFeatureLayer;

                        if (pflayer != null)
                        {
                            if (((IDataset)(pflayer).FeatureClass).Name.ToUpper().Contains("SPLICEPOINT") == true)
                            {
                                isSplice = true;
                                //strLayers = strLayers + ", SPLICE";
                            }
                            if (((IDataset)(pflayer).FeatureClass).Name.ToUpper().Contains("FIBEROPTICCABLE") == true)
                            {
                                isCable = true;
                                //strLayers = strLayers + ", FIBERCABLE";
                            }
                            if (((IDataset)(pflayer).FeatureClass).Name.ToUpper().Contains("PATCHLOCATION") == true)
                            {
                                isPL = true;
                                //strLayers = strLayers + ", PL";
                            }
                            //if (((IDataset)(pflayer).FeatureClass).Name.ToUpper().Contains("FIBEROPTICCABLE"))
                            //{
                            //    islayerExists = true;
                            //}
                        }
                    }
                }
                else
                {
                    pflayer = pTempLayer as IFeatureLayer;
                    if (((IDataset)(pflayer).FeatureClass).Name.ToUpper().Contains("SPLICEPOINT") == true)
                    {
                        isSplice = true;
                        //strLayers = strLayers + ", SPLICE";
                    }
                    if (((IDataset)(pflayer).FeatureClass).Name.ToUpper().Contains("FIBEROPTICCABLE") == true)
                    {
                        isCable = true;
                        //strLayers = strLayers + ", FIBERCABLE";
                    }
                    if (((IDataset)(pflayer).FeatureClass).Name.ToUpper().Contains("PATCHLOCATION") == true)
                    {
                        isPL = true;
                        //strLayers = strLayers + ", PL";
                    }
                }
            }



            //for (Int32 inti = 0; inti < pMap.LayerCount; inti++)
            //{
            //    pLayer = pMap.get_Layer(inti);
            //    strTempValidate = strTempValidate + "," + pLayer.Name.ToUpper();
            //}

            if (isSplice == false)
            {
                strLayers = strLayers + ", SPLICE";
            }
            if (isCable == false)
            {
                strLayers = strLayers + ", FIBERCABLE";
            }
            if (isPL == false)
            {
                strLayers = strLayers + ", PL";
            }

            if (strLayers != "")
            {
                strLayers = strLayers.Substring(1, strLayers.Length - 1);
                MessageBox.Show(strLayers + " Layer(s)/Table(s) are not found on the map, Please add these Layer(s)/Table(s)", "OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            else
            {
                return true;
            }
        }
    }

}
