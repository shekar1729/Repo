﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.Geometry;

namespace cemOTDRTrace
{
    public class clsCommonFunctions
    {
        /// <summary>
        /// Get Feature Workspace
        /// </summary>
        public void GetFeaWorkspace(IMap pMap, out IWorkspace pWorkSpace, out IFeatureWorkspace pFeatureWorkspace, out IFeatureLayer pFeatureLayer)
        {
            pWorkSpace = null;
            pFeatureWorkspace = null;
            pFeatureLayer = null;
            if (pMap.LayerCount > 0)
            {
                for (int nCnt = 0; nCnt < pMap.LayerCount; nCnt++)
                {
                    ILayer pTempLayer = pMap.get_Layer(nCnt);
                    IFeatureLayer pflayer = null;
                eh:
                    if (pTempLayer is IGroupLayer)
                    {
                        ICompositeLayer pCompLyr = (ICompositeLayer)pTempLayer;

                        for (int iInt = 0; iInt < pCompLyr.Count; iInt++)
                        {
                            pTempLayer = pCompLyr.get_Layer(iInt);
                            if (pTempLayer is IGroupLayer)
                                goto eh;
                            pflayer = pCompLyr.get_Layer(iInt) as IFeatureLayer;

                            if (pflayer != null)
                            {
                                //pFeatLayer = pComprLayer as IFeatureLayer;
                                if (((IDataset)(pflayer).FeatureClass).Name.ToUpper().Contains("FIBEROPTICCABLE"))
                                {
                                    pFeatureLayer = pTempLayer as IFeatureLayer;
                                    pWorkSpace = ((IDataset)(pflayer.FeatureClass)).Workspace;
                                    if (pWorkSpace != null)
                                    {
                                        pFeatureWorkspace = pWorkSpace as IFeatureWorkspace;
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        //pFeatLayer = pTempLayer as IFeatureLayer;
                        pflayer = pTempLayer as IFeatureLayer;
                        if (((IDataset)(pflayer).FeatureClass).Name.ToUpper().Contains("FIBEROPTICCABLE"))
                        {
                            pFeatureLayer = pTempLayer as IFeatureLayer;
                            pWorkSpace = ((IDataset)(pflayer.FeatureClass)).Workspace;
                            if (pWorkSpace != null)
                            {
                                pFeatureWorkspace = pWorkSpace as IFeatureWorkspace;
                            }
                            break;
                        }
                    }
                }

                //IFeatureLayer pFeatLayer = pMap.get_Layer(0) as IFeatureLayer;
                //pFeatureLayer = pFeatLayer;
                //pWorkSpace = ((IDataset)(pFeatLayer.FeatureClass)).Workspace;
                //if (pWorkSpace != null)
                //{
                //    pFeatureWorkspace = pWorkSpace as IFeatureWorkspace;
                //}
            }
        }

        /// <summary>
        /// Fill all cable names into the combobox
        /// </summary>
        /// <param name="cmbCables">form combobox control</param>
        /// <param name="FiberCableFC">Fiber Optic Cable feature class</param>
        /// <param name="DataCollection">String Collection onject to fill the cable names</param>
        public void FillData(ComboBox cboObject, IFeatureClass pFC, string strFieldName)
        {
            try
            {
                AutoCompleteStringCollection DataCollection = new AutoCompleteStringCollection();
                List<string> lstTemp = new List<string>();
                int idx = pFC.Fields.FindField(strFieldName);
                if (idx == -1)
                {
                    throw new Exception(string.Format(
                        "field {0} not found in {1}",
                        strFieldName, ((IDataset)pFC).Name));
                }
                if (strFieldName == "CABLENAME")
                    DataCollection.Add("--Enter Cable Name--");
                IQueryFilter pQF = new QueryFilterClass();
                IQueryFilterDefinition queryFilterDefinition = (IQueryFilterDefinition)pQF;
                if (strFieldName == "CABLENAME")
                {
                    pQF.SubFields = "CABLENAME";
                    queryFilterDefinition.PostfixClause = "ORDER BY CABLENAME";
                }
                IFeatureCursor pCur = pFC.Search(pQF, false);
                if (pCur != null)
                {
                    IFeature pFea = pCur.NextFeature();
                    while (pFea != null)
                    {
                        string strCableName = pFea.get_Value(idx) is DBNull ? "<Null>" : pFea.get_Value(idx).ToString();
                        if (!string.IsNullOrEmpty(strCableName.Trim()) && strCableName != "<Null>")
                        {
                            if (!DataCollection.Contains(strCableName))
                            {
                                DataCollection.Add(pFea.get_Value(pFea.Fields.FindField(strFieldName)).ToString());
                            }
                        }
                        pFea = pCur.NextFeature();
                    }
                    cboObject.DataSource = DataCollection;
                    cboObject.SelectedIndex = 0;
                    Marshal.ReleaseComObject(pCur);
                    GC.Collect();
                }
            }
            catch
            {
                throw;
            }
            finally
            {

            }
        }

        /// <summary>
        /// Read Application Path
        /// </summary>
        public string ReadAppPath()
        {
            try
            {
                string appPath = string.Empty;
                System.Reflection.AssemblyName executingAssemblyName = System.Reflection.Assembly.GetExecutingAssembly().GetName();
                appPath = System.IO.Path.GetDirectoryName(executingAssemblyName.CodeBase);
                if (appPath.IndexOf("file:\\") >= 0)
                {
                    appPath = appPath.Replace("file:\\", "");
                }
                return appPath;
            }
            catch
            {
                return string.Empty;
            }
        }
    }
}
