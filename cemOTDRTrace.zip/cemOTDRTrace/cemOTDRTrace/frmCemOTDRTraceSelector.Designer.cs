﻿namespace cemOTDRTrace
{
    partial class frmCemOTDRTraceSelector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCemOTDRTraceSelector));
            this.label1 = new System.Windows.Forms.Label();
            this.lblCable1 = new System.Windows.Forms.Label();
            this.lblSelectCable = new System.Windows.Forms.Label();
            this.lblCable2 = new System.Windows.Forms.Label();
            this.txtReservedLength2 = new System.Windows.Forms.TextBox();
            this.txtReservedLength1 = new System.Windows.Forms.TextBox();
            this.lblReservedLength2 = new System.Windows.Forms.Label();
            this.lblReservedLength1 = new System.Windows.Forms.Label();
            this.lblDistance1 = new System.Windows.Forms.Label();
            this.txtDistance2 = new System.Windows.Forms.TextBox();
            this.txtDistance1 = new System.Windows.Forms.TextBox();
            this.lblDistance2 = new System.Windows.Forms.Label();
            this.btnTrace = new System.Windows.Forms.Button();
            this.txtStrandNo = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cboCables = new CEM_Fiber_ToolBar.Common.Controls.CablesCombox.EasyCompletionComboBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(323, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Strand No :";
            // 
            // lblCable1
            // 
            this.lblCable1.AutoSize = true;
            this.lblCable1.Location = new System.Drawing.Point(3, 18);
            this.lblCable1.Name = "lblCable1";
            this.lblCable1.Size = new System.Drawing.Size(35, 13);
            this.lblCable1.TabIndex = 10;
            this.lblCable1.Text = "Card1";
            // 
            // lblSelectCable
            // 
            this.lblSelectCable.AutoSize = true;
            this.lblSelectCable.Location = new System.Drawing.Point(6, 8);
            this.lblSelectCable.Name = "lblSelectCable";
            this.lblSelectCable.Size = new System.Drawing.Size(73, 13);
            this.lblSelectCable.TabIndex = 8;
            this.lblSelectCable.Text = "Select Cable :";
            // 
            // lblCable2
            // 
            this.lblCable2.AutoSize = true;
            this.lblCable2.Location = new System.Drawing.Point(3, 72);
            this.lblCable2.Name = "lblCable2";
            this.lblCable2.Size = new System.Drawing.Size(35, 13);
            this.lblCable2.TabIndex = 13;
            this.lblCable2.Text = "Card2";
            // 
            // txtReservedLength2
            // 
            this.txtReservedLength2.Enabled = false;
            this.txtReservedLength2.Location = new System.Drawing.Point(401, 66);
            this.txtReservedLength2.Name = "txtReservedLength2";
            this.txtReservedLength2.Size = new System.Drawing.Size(115, 20);
            this.txtReservedLength2.TabIndex = 6;
            this.txtReservedLength2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReservedLength2_KeyPress);
            // 
            // txtReservedLength1
            // 
            this.txtReservedLength1.Enabled = false;
            this.txtReservedLength1.Location = new System.Drawing.Point(401, 14);
            this.txtReservedLength1.Name = "txtReservedLength1";
            this.txtReservedLength1.Size = new System.Drawing.Size(115, 20);
            this.txtReservedLength1.TabIndex = 4;
            this.txtReservedLength1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtReservedLength1_KeyPress);
            // 
            // lblReservedLength2
            // 
            this.lblReservedLength2.AutoSize = true;
            this.lblReservedLength2.Location = new System.Drawing.Point(308, 72);
            this.lblReservedLength2.Name = "lblReservedLength2";
            this.lblReservedLength2.Size = new System.Drawing.Size(89, 13);
            this.lblReservedLength2.TabIndex = 15;
            this.lblReservedLength2.Text = "Reserved Length";
            // 
            // lblReservedLength1
            // 
            this.lblReservedLength1.AutoSize = true;
            this.lblReservedLength1.Location = new System.Drawing.Point(308, 18);
            this.lblReservedLength1.Name = "lblReservedLength1";
            this.lblReservedLength1.Size = new System.Drawing.Size(92, 13);
            this.lblReservedLength1.TabIndex = 12;
            this.lblReservedLength1.Text = "Reserved Length:";
            // 
            // lblDistance1
            // 
            this.lblDistance1.AutoSize = true;
            this.lblDistance1.Location = new System.Drawing.Point(109, 18);
            this.lblDistance1.Name = "lblDistance1";
            this.lblDistance1.Size = new System.Drawing.Size(52, 13);
            this.lblDistance1.TabIndex = 11;
            this.lblDistance1.Text = "Distance:";
            // 
            // txtDistance2
            // 
            this.txtDistance2.Enabled = false;
            this.txtDistance2.Location = new System.Drawing.Point(167, 70);
            this.txtDistance2.Name = "txtDistance2";
            this.txtDistance2.Size = new System.Drawing.Size(134, 20);
            this.txtDistance2.TabIndex = 5;
            this.txtDistance2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDistance2_KeyPress);
            // 
            // txtDistance1
            // 
            this.txtDistance1.Enabled = false;
            this.txtDistance1.Location = new System.Drawing.Point(167, 15);
            this.txtDistance1.Name = "txtDistance1";
            this.txtDistance1.Size = new System.Drawing.Size(134, 20);
            this.txtDistance1.TabIndex = 3;
            this.txtDistance1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDistance1_KeyPress);
            // 
            // lblDistance2
            // 
            this.lblDistance2.AutoSize = true;
            this.lblDistance2.Location = new System.Drawing.Point(109, 73);
            this.lblDistance2.Name = "lblDistance2";
            this.lblDistance2.Size = new System.Drawing.Size(52, 13);
            this.lblDistance2.TabIndex = 14;
            this.lblDistance2.Text = "Distance:";
            // 
            // btnTrace
            // 
            this.btnTrace.Location = new System.Drawing.Point(456, 144);
            this.btnTrace.Name = "btnTrace";
            this.btnTrace.Size = new System.Drawing.Size(75, 23);
            this.btnTrace.TabIndex = 7;
            this.btnTrace.Text = "Trace";
            this.btnTrace.UseVisualStyleBackColor = true;
            this.btnTrace.Click += new System.EventHandler(this.btnTrace_Click);
            // 
            // txtStrandNo
            // 
            this.txtStrandNo.Enabled = false;
            this.txtStrandNo.Location = new System.Drawing.Point(390, 5);
            this.txtStrandNo.Name = "txtStrandNo";
            this.txtStrandNo.Size = new System.Drawing.Size(141, 20);
            this.txtStrandNo.TabIndex = 2;
            this.txtStrandNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtStrandNo_KeyPress);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblCable1);
            this.panel1.Controls.Add(this.txtDistance1);
            this.panel1.Controls.Add(this.lblDistance2);
            this.panel1.Controls.Add(this.lblCable2);
            this.panel1.Controls.Add(this.txtDistance2);
            this.panel1.Controls.Add(this.lblDistance1);
            this.panel1.Controls.Add(this.txtReservedLength2);
            this.panel1.Controls.Add(this.lblReservedLength1);
            this.panel1.Controls.Add(this.lblReservedLength2);
            this.panel1.Controls.Add(this.txtReservedLength1);
            this.panel1.Location = new System.Drawing.Point(9, 37);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(522, 101);
            this.panel1.TabIndex = 16;
            // 
            // cboCables
            // 
            this.cboCables.FormattingEnabled = true;
            this.cboCables.Location = new System.Drawing.Point(82, 5);
            this.cboCables.Name = "cboCables";
            this.cboCables.Size = new System.Drawing.Size(234, 21);
            this.cboCables.TabIndex = 1;
            this.cboCables.TabStop = false;
            this.cboCables.SelectedIndexChanged += new System.EventHandler(this.cboCables_SelectedIndexChanged);
            this.cboCables.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cboCables_MouseClick_1);
            // 
            // frmCemOTDRTraceSelector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(537, 172);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cboCables);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblSelectCable);
            this.Controls.Add(this.btnTrace);
            this.Controls.Add(this.txtStrandNo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmCemOTDRTraceSelector";
            this.Text = "CEM OTDR Trace Selector";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmCemOTDRTraceSelector_FormClosing);
            this.Load += new System.EventHandler(this.frmCemOTDRTraceSelector_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCable1;
        private System.Windows.Forms.Label lblSelectCable;
        private System.Windows.Forms.Label lblCable2;
        private System.Windows.Forms.TextBox txtReservedLength2;
        private System.Windows.Forms.TextBox txtReservedLength1;
        private System.Windows.Forms.Label lblReservedLength2;
        private System.Windows.Forms.Label lblReservedLength1;
        private System.Windows.Forms.Label lblDistance1;
        private System.Windows.Forms.TextBox txtDistance2;
        private System.Windows.Forms.TextBox txtDistance1;
        private System.Windows.Forms.Label lblDistance2;
        private System.Windows.Forms.Button btnTrace;
        private System.Windows.Forms.TextBox txtStrandNo;
        private CEM_Fiber_ToolBar.Common.Controls.CablesCombox.EasyCompletionComboBox cboCables;
        private System.Windows.Forms.Panel panel1;
    }
}