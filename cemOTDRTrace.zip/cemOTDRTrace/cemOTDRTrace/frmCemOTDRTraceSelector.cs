﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.ArcMapUI;

namespace cemOTDRTrace
{
    public partial class frmCemOTDRTraceSelector : Form
    {
        #region Global Variables
        public IFeature pFeature;
        public IMap pMap;
        private IFeatureWorkspace pFeatureWorkspace;
        private IWorkspace pWorkSpace;
        private IFeatureLayer pFeatLayer;
        public IActiveView pActiveView;
        private IMouseCursor appCursor;
        private Dictionary<string, IRow> distBacksidePorts = new Dictionary<string, IRow>();
        private Dictionary<string, IRow> distFrontsidePorts = new Dictionary<string, IRow>();
        private Dictionary<int, IRow> dist1Fibers = new Dictionary<int, IRow>();
        private Dictionary<int, IRow> dist2Fibers = new Dictionary<int, IRow>();
        private Dictionary<int, IRow> distBuffers = new Dictionary<int, IRow>();
        private IRelationshipClass pRackRelationshipClass, pPatchpanelRelationshipClass, pPPCardRelationshipClass, pFPRelationshipClass, pBPRelationshipClass, pBuffertubeRelationshipClass, pFiberRelationshipClass;
        clsCommonFunctions objclsCommonFunctions = new clsCommonFunctions();
        private IFeatureClass pPatchLocationFC, pFiberCableFC, pSpliceFC,pPTLocationFC;
        private IFeature pCable1Fea, pCable2Fea;
        private ITable pF_FiberTable, pF_BuffertubeTable, pF_FIBERCONNECTIONOBJECT, pF_RACK, pF_PATCHPANELCARD, pF_FRONTSIDEPORT, pF_BACKSIDEPORT, pF_PATCHPANEL, pF_PTFRONTSIDEPORT, pF_PTBACKSIDEPORT, pF_PTPANEL;
        private string PL1Name, PL2Name;
        private Dictionary<string, List<string>> lstFiberToTrace = new Dictionary<string, List<string>>();
        IGraphicsContainer graphicsContainer;
        ITopologicalOperator resultPolyline;
        double totalCableLength;
        string cable1GlobalId;
        string cable2GlobalId;
        IPoint fromPoint1, fromPoint2, toPoint1, toPoint2;
        IPolyline pPolyLine;
        string PLName;

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        public frmCemOTDRTraceSelector()
        {
            IMouseCursor mouseCur = new MouseCursor();
            mouseCur.SetCursor(2);
            InitializeComponent();
        }

        private void frmCemOTDRTraceSelector_Load(object sender, EventArgs e)
        {
            appCursor = new MouseCursorClass();
            try
            {
                appCursor.SetCursor(2);
                //Get workspace and feature workspace
                objclsCommonFunctions.GetFeaWorkspace(pMap, out pWorkSpace, out pFeatureWorkspace, out pFeatLayer);
                //Open required featureclasses and tables
                OpenFeatureClassesAndTables();
                //Fill cable names in the combobox
                objclsCommonFunctions.FillData(cboCables, pFiberCableFC, "CABLENAME");
            }
            catch
            {
            }
            finally
            {
                appCursor.SetCursor(0);
            }
        }

        /// <summary>
        /// Function to Open feature classes and tables.
        /// </summary>
        private void OpenFeatureClassesAndTables()
        {            
            try
            {                
                if (pFeatureWorkspace != null)
                {
                    IDataset dataset = null;
                    #region Open feature classes
                    try
                    {
                        pPatchLocationFC = pFeatureWorkspace.OpenFeatureClass("PatchLocation");
                        pFiberCableFC = pFeatureWorkspace.OpenFeatureClass("FiberOpticCable");
                        pSpliceFC = pFeatureWorkspace.OpenFeatureClass("SplicePoint");
                        pPTLocationFC = pFeatureWorkspace.OpenFeatureClass("PtLocation");
                    }
                    catch
                    {
                        try
                        {
                            if (((IDataset)(pFeatLayer.FeatureClass)).Name.Contains("."))
                            {
                                string[] name = ((IDataset)(pFeatLayer.FeatureClass)).Name.Split('.');
                                pPatchLocationFC = pFeatureWorkspace.OpenFeatureClass(name[name.Length - 2].ToString() + ".PatchLocation");
                                pFiberCableFC = pFeatureWorkspace.OpenFeatureClass(name[name.Length - 2].ToString() + ".FiberOpticCable");
                                pSpliceFC = pFeatureWorkspace.OpenFeatureClass(name[name.Length - 2].ToString() + ".SplicePoint");
                                pPTLocationFC = pFeatureWorkspace.OpenFeatureClass(name[name.Length - 2].ToString() + ".PtLocation");
                            }
                        }
                        catch
                        {
                            IEnumDataset datasets = pWorkSpace.get_Datasets(esriDatasetType.esriDTFeatureDataset);
                            dataset = null;
                            while ((dataset = datasets.Next()) != null)
                            {
                                if (dataset.Name.ToUpper().Contains("FIBERDATASET"))
                                {
                                    if (dataset.Type == esriDatasetType.esriDTFeatureDataset)
                                    {
                                        string name = dataset.Name;
                                        IFeatureDataset fDS = pFeatureWorkspace.OpenFeatureDataset(dataset.Name);
                                        IEnumDataset enumDS = fDS.Subsets;
                                        IDataset ds;
                                        enumDS.Reset();
                                        while ((ds = enumDS.Next()) != null)
                                        {
                                            if (ds.Name.ToUpper().Contains("PATCHLOCATION"))
                                            {
                                                if (!ds.Name.ToUpper().Contains("PILOTPATCHLOCATION"))
                                                    pPatchLocationFC = pFeatureWorkspace.OpenFeatureClass(ds.Name);
                                            }
                                            if (ds.Name.ToUpper().Contains("FIBEROPTICCABLE"))
                                            {
                                                pFiberCableFC = pFeatureWorkspace.OpenFeatureClass(ds.Name);
                                            }
                                            if (ds.Name.ToUpper().Contains("SPLICEPOINT"))
                                            {
                                                pSpliceFC = pFeatureWorkspace.OpenFeatureClass(ds.Name);
                                            }
                                            if (ds.Name.ToUpper().Contains("PTLOCATION"))
                                            {
                                                pPTLocationFC = pFeatureWorkspace.OpenFeatureClass(ds.Name);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    //pPatchLocationFC = pFeatureWorkspace.OpenFeatureClass("PatchLocation");
                    //pFiberCableFC = pFeatureWorkspace.OpenFeatureClass("FiberOpticCable");
                    //pSpliceFC = pFeatureWorkspace.OpenFeatureClass("SplicePoint");
                    #endregion
                    #region Open tables
                    try
                    {
                        pF_PATCHPANEL = pFeatureWorkspace.OpenTable("F_PATCHPANEL");
                        pF_RACK = pFeatureWorkspace.OpenTable("F_RACK");
                        pF_PATCHPANELCARD = pFeatureWorkspace.OpenTable("F_PATCHPANELCARD");
                        pF_BACKSIDEPORT = pFeatureWorkspace.OpenTable("F_BACKSIDEPORT");
                        pF_FRONTSIDEPORT = pFeatureWorkspace.OpenTable("F_FRONTSIDEPORT");
                        pF_FIBERCONNECTIONOBJECT = pFeatureWorkspace.OpenTable("F_FIBERCONNECTIONOBJECT");
                        pF_FiberTable = pFeatureWorkspace.OpenTable("F_FIBER");
                        pF_BuffertubeTable = pFeatureWorkspace.OpenTable("F_BUFFERTUBE");

                        pF_PTFRONTSIDEPORT = pFeatureWorkspace.OpenTable("F_PtFrontport");
                        pF_PTBACKSIDEPORT = pFeatureWorkspace.OpenTable("F_PtBackport");
                        pF_PTPANEL = pFeatureWorkspace.OpenTable("F_PtPanel");
                    }
                    catch
                    {
                        try
                        {
                            if (((IDataset)(pFeatLayer.FeatureClass)).Name.Contains("."))
                            {
                                string[] name = ((IDataset)(pFeatLayer.FeatureClass)).Name.Split('.');
                                pF_PATCHPANEL = pFeatureWorkspace.OpenTable(name[name.Length - 2].ToString() + ".F_PATCHPANEL");
                                pF_RACK = pFeatureWorkspace.OpenTable(name[name.Length - 2].ToString() + ".F_RACK");
                                pF_PATCHPANELCARD = pFeatureWorkspace.OpenTable(name[name.Length - 2].ToString() + ".F_PATCHPANELCARD");
                                pF_BACKSIDEPORT = pFeatureWorkspace.OpenTable(name[name.Length - 2].ToString() + ".F_BACKSIDEPORT");
                                pF_FRONTSIDEPORT = pFeatureWorkspace.OpenTable(name[name.Length - 2].ToString() + ".F_FRONTSIDEPORT");
                                pF_FIBERCONNECTIONOBJECT = pFeatureWorkspace.OpenTable(name[name.Length - 2].ToString() + ".F_FIBERCONNECTIONOBJECT");
                                pF_FiberTable = pFeatureWorkspace.OpenTable(name[name.Length - 2].ToString() + ".F_FIBER");
                                pF_BuffertubeTable = pFeatureWorkspace.OpenTable(name[name.Length - 2].ToString() + ".F_BUFFERTUBE");

                                pF_PTFRONTSIDEPORT = pFeatureWorkspace.OpenTable(name[name.Length - 2].ToString() + ".F_PtFrontport");
                                pF_PTBACKSIDEPORT = pFeatureWorkspace.OpenTable(name[name.Length - 2].ToString() + ".F_PtBackport");
                                pF_PTPANEL = pFeatureWorkspace.OpenTable(name[name.Length - 2].ToString() + ".F_PtPanel");
                            }
                        }
                        catch
                        {
                            IEnumDataset tblDatasets = pWorkSpace.get_Datasets(esriDatasetType.esriDTTable);
                            dataset = null;
                            while ((dataset = tblDatasets.Next()) != null)
                            {
                                if (dataset.Name.ToUpper().Contains("F_"))
                                {
                                    if (dataset.Type == esriDatasetType.esriDTTable)
                                    {
                                        if (dataset.Name.ToUpper().Contains("F_PATCHPANEL"))
                                        {
                                            if (!dataset.Name.ToUpper().Contains("F_PATCHPANELCARD"))
                                                pF_PATCHPANEL = pFeatureWorkspace.OpenTable(dataset.Name);
                                        }

                                        if (dataset.Name.ToUpper().Contains("F_PTPANEL".ToUpper()))
                                        {
                                            pF_PTPANEL = pFeatureWorkspace.OpenTable(dataset.Name);
                                        }

                                        if (dataset.Name.ToUpper().Contains("F_RACK"))
                                            pF_RACK = pFeatureWorkspace.OpenTable(dataset.Name);
                                        if (dataset.Name.ToUpper().Contains("F_PATCHPANELCARD"))
                                            pF_PATCHPANELCARD = pFeatureWorkspace.OpenTable(dataset.Name);
                                        if (dataset.Name.ToUpper().Contains("F_BACKSIDEPORT"))
                                            pF_BACKSIDEPORT = pFeatureWorkspace.OpenTable(dataset.Name);
                                        if (dataset.Name.ToUpper().Contains("F_FRONTSIDEPORT"))
                                            pF_FRONTSIDEPORT = pFeatureWorkspace.OpenTable(dataset.Name);
                                        if (dataset.Name.ToUpper().Contains("F_FIBERCONNECTIONOBJECT"))
                                            pF_FIBERCONNECTIONOBJECT = pFeatureWorkspace.OpenTable(dataset.Name);
                                        if (dataset.Name.ToUpper().Contains("F_FIBER"))
                                        {
                                            if (!dataset.Name.ToUpper().Contains("F_FIBERCONNECTIONOBJECT"))
                                                pF_FiberTable = pFeatureWorkspace.OpenTable(dataset.Name);
                                        }
                                        if (dataset.Name.ToUpper().Contains("F_BUFFERTUBE"))
                                            pF_BuffertubeTable = pFeatureWorkspace.OpenTable(dataset.Name);

                                        if (dataset.Name.ToUpper().Contains("F_PtBackport".ToUpper()))
                                            pF_PTBACKSIDEPORT = pFeatureWorkspace.OpenTable(dataset.Name);
                                        if (dataset.Name.ToUpper().Contains("F_PtFrontport".ToUpper()))
                                            pF_PTFRONTSIDEPORT = pFeatureWorkspace.OpenTable(dataset.Name);
                                    }
                                }
                            }
                        }
                    }
                    
                    //pF_PATCHPANEL = pFeatureWorkspace.OpenTable("F_PATCHPANEL");
                    //pF_RACK = pFeatureWorkspace.OpenTable("F_RACK");
                    //pF_PATCHPANELCARD = pFeatureWorkspace.OpenTable("F_PATCHPANELCARD");
                    //pF_BACKSIDEPORT = pFeatureWorkspace.OpenTable("F_BACKSIDEPORT");
                    //pF_FRONTSIDEPORT = pFeatureWorkspace.OpenTable("F_FRONTSIDEPORT");
                    //pF_FIBERCONNECTIONOBJECT = pFeatureWorkspace.OpenTable("F_FIBERCONNECTIONOBJECT");
                    //pF_FiberTable = pFeatureWorkspace.OpenTable("F_FIBER");
                    //pF_BuffertubeTable = pFeatureWorkspace.OpenTable("F_BUFFERTUBE");
                    #endregion
                    #region Open relationshipClasses
                    try
                    {
                        pRackRelationshipClass = pFeatureWorkspace.OpenRelationshipClass("F_PatchLocation_Rack");
                        pPatchpanelRelationshipClass = pFeatureWorkspace.OpenRelationshipClass("F_Rack_PatchPanel");
                        pPPCardRelationshipClass = pFeatureWorkspace.OpenRelationshipClass("F_PatchPanel_PatchPanelCard");
                        pFPRelationshipClass = pFeatureWorkspace.OpenRelationshipClass("F_PtchPnlCard_FrontsidePort");
                        pBPRelationshipClass = pFeatureWorkspace.OpenRelationshipClass("F_PtchPnlCard_BacksidePort");
                        pBuffertubeRelationshipClass = pFeatureWorkspace.OpenRelationshipClass("F_FiberOpticCable_BufferTube");
                        pFiberRelationshipClass = pFeatureWorkspace.OpenRelationshipClass("F_Buffertube_Fiber");
                    }
                    catch
                    {
                        try
                        {
                            if (((IDataset)(pFeatLayer.FeatureClass)).Name.Contains("."))
                            {
                                string[] name = ((IDataset)(pFeatLayer.FeatureClass)).Name.Split('.');
                                pRackRelationshipClass = pFeatureWorkspace.OpenRelationshipClass(name[name.Length - 2].ToString() + ".F_PatchLocation_Rack");
                                pPatchpanelRelationshipClass = pFeatureWorkspace.OpenRelationshipClass(name[name.Length - 2].ToString() + ".F_Rack_PatchPanel");
                                pPPCardRelationshipClass = pFeatureWorkspace.OpenRelationshipClass(name[name.Length - 2].ToString() + ".F_PatchPanel_PatchPanelCard");
                                pFPRelationshipClass = pFeatureWorkspace.OpenRelationshipClass(name[name.Length - 2].ToString() + ".F_PtchPnlCard_FrontsidePort");
                                pBPRelationshipClass = pFeatureWorkspace.OpenRelationshipClass(name[name.Length - 2].ToString() + ".F_PtchPnlCard_BacksidePort");
                                pBuffertubeRelationshipClass = pFeatureWorkspace.OpenRelationshipClass(name[name.Length - 2].ToString() + ".F_FiberOpticCable_BufferTube");
                                pFiberRelationshipClass = pFeatureWorkspace.OpenRelationshipClass(name[name.Length - 2].ToString() + ".F_Buffertube_Fiber");
                            }
                        }
                        catch
                        {
                            IEnumDataset relDatasets = pWorkSpace.get_Datasets(esriDatasetType.esriDTRelationshipClass);
                            dataset = null;
                            while ((dataset = relDatasets.Next()) != null)
                            {
                                if (dataset.Name.ToUpper().Contains("F_"))
                                {
                                    if (dataset.Type == esriDatasetType.esriDTRelationshipClass)
                                    {
                                        if (dataset.Name.ToUpper().Contains("F_PATCHLOCATION_RACK"))
                                            pRackRelationshipClass = pFeatureWorkspace.OpenRelationshipClass(dataset.Name);
                                        if (dataset.Name.ToUpper().Contains("F_RACK_PATCHPANEL"))
                                            pPatchpanelRelationshipClass = pFeatureWorkspace.OpenRelationshipClass(dataset.Name);
                                        if (dataset.Name.ToUpper().Contains("F_PATCHPANEL_PATCHPANELCARD"))
                                            pPPCardRelationshipClass = pFeatureWorkspace.OpenRelationshipClass(dataset.Name);
                                        if (dataset.Name.ToUpper().Contains("F_PTCHPNLCARD_FRONTSIDEPORT"))
                                            pFPRelationshipClass = pFeatureWorkspace.OpenRelationshipClass(dataset.Name);
                                        if (dataset.Name.ToUpper().Contains("F_PTCHPNLCARD_BACKSIDEPORT"))
                                            pBPRelationshipClass = pFeatureWorkspace.OpenRelationshipClass(dataset.Name);
                                        if (dataset.Name.ToUpper().Contains("F_FIBEROPTICCABLE_BUFFERTUBE"))
                                            pBuffertubeRelationshipClass = pFeatureWorkspace.OpenRelationshipClass(dataset.Name);
                                        if (dataset.Name.ToUpper().Contains("F_BUFFERTUBE_FIBER"))
                                            pFiberRelationshipClass = pFeatureWorkspace.OpenRelationshipClass(dataset.Name);
                                    }
                                }
                            }
                        }
                    }
                    
                    //pRackRelationshipClass = pFeatureWorkspace.OpenRelationshipClass("F_PatchLocation_Rack");
                    //pPatchpanelRelationshipClass = pFeatureWorkspace.OpenRelationshipClass("F_Rack_PatchPanel");
                    //pPPCardRelationshipClass = pFeatureWorkspace.OpenRelationshipClass("F_PatchPanel_PatchPanelCard");
                    //pFPRelationshipClass = pFeatureWorkspace.OpenRelationshipClass("F_PtchPnlCard_FrontsidePort");
                    //pBPRelationshipClass = pFeatureWorkspace.OpenRelationshipClass("F_PtchPnlCard_BacksidePort");
                    //pBuffertubeRelationshipClass = pFeatureWorkspace.OpenRelationshipClass("F_FiberOpticCable_BufferTube");
                    //pFiberRelationshipClass = pFeatureWorkspace.OpenRelationshipClass("F_Buffertube_Fiber");
                    #endregion
                }
                else
                {
                    MessageBox.Show("FetureWorkspace is NULL", "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            catch
            {
                //throw;
            }
            finally
            {
               
            }
        }

        /// <summary>
        /// Set the form data on cable selection
        /// </summary>
        private void cboCables_SelectedIndexChanged(object sender, EventArgs e)
        
        {
            try
            {
                txtStrandNo.Text = "";
                txtDistance1.Text = "";
                txtDistance2.Text = "";
                txtReservedLength1.Text = "";
                txtReservedLength2.Text = "";
                if (cboCables.Text != "--Enter Cable Name--" && !string.IsNullOrEmpty(cboCables.Text))
                {
                    totalCableLength = 0.0;
                    cable1GlobalId = string.Empty;
                    cable2GlobalId = string.Empty;
                    lblCable1.Text = string.Empty;
                    lblCable2.Text = string.Empty;
                    GetCables(cboCables.Text);

                    if (pCable1Fea != null)
                    {
                        cable1GlobalId = pCable1Fea.get_Value(pCable1Fea.Fields.FindField("GlobalID")).ToString();
                        if (pCable1Fea.get_Value(pCable1Fea.Fields.FindField("CABLENAME")).ToString().Split('-')[0].ToString().Contains(PL1Name))
                        {
                            lblCable1.Text = pCable1Fea.get_Value(pCable1Fea.Fields.FindField("CABLENAME")).ToString().Split('-')[0].ToString();
                            txtReservedLength1.Text = pCable1Fea.get_Value(pCable1Fea.Fields.FindField("RESERVEDLENGTHA")).ToString();
                        }
                        else if (pCable1Fea.get_Value(pCable1Fea.Fields.FindField("CABLENAME")).ToString().Split('-')[1].ToString().Contains(PL1Name))
                        {
                            lblCable2.Text = pCable1Fea.get_Value(pCable1Fea.Fields.FindField("CABLENAME")).ToString().Split('-')[1].ToString();
                            txtReservedLength2.Text = pCable1Fea.get_Value(pCable1Fea.Fields.FindField("RESERVEDLENGTHB")).ToString();
                        }
                    }
                    if (pCable2Fea != null)
                    {
                        cable2GlobalId = pCable1Fea.get_Value(pCable1Fea.Fields.FindField("GlobalID")).ToString();
                        if (pCable2Fea.get_Value(pCable2Fea.Fields.FindField("CABLENAME")).ToString().Split('-')[0].ToString().Contains(PL2Name))
                        {
                            lblCable1.Text = pCable2Fea.get_Value(pCable2Fea.Fields.FindField("CABLENAME")).ToString().Split('-')[0].ToString();
                            txtReservedLength1.Text = pCable2Fea.get_Value(pCable1Fea.Fields.FindField("RESERVEDLENGTHA")).ToString();
                        }
                        else if (pCable2Fea.get_Value(pCable2Fea.Fields.FindField("CABLENAME")).ToString().Split('-')[1].ToString().Contains(PL2Name))
                        {
                            lblCable2.Text = pCable2Fea.get_Value(pCable2Fea.Fields.FindField("CABLENAME")).ToString().Split('-')[1].ToString();
                            txtReservedLength2.Text = pCable2Fea.get_Value(pCable1Fea.Fields.FindField("RESERVEDLENGTHB")).ToString();
                        }
                    }
                    if (string.IsNullOrEmpty(lblCable1.Text))
                        lblCable1.Text = "No PL";
                    if (string.IsNullOrEmpty(lblCable2.Text))
                        lblCable2.Text = "No PL";

                    txtStrandNo.Enabled = true;
                    txtDistance1.Enabled = true;
                    txtDistance2.Enabled = true;
                    txtReservedLength1.Enabled = true;
                    txtReservedLength2.Enabled = true;
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// Get all cables from data with the same name
        /// </summary>
        private void GetCables(string cableName)
        {
            try
            {
                PL1Name = string.Empty;
                PL2Name = string.Empty;
                pCable1Fea = null;
                pCable2Fea = null;
                resultPolyline = new Polyline() as ITopologicalOperator;
                IGeometryCollection geometriesToUnion = new GeometryBag() as IGeometryCollection;

                QueryFilter pCableFil = new QueryFilterClass();
                pCableFil.WhereClause = "CABLENAME = '" + cableName + "'";
                //pCableFil.WhereClause = "CABLENAME = '" + pFeature.get_Value(pFeature.Fields.FindField("CABLENAME")).ToString() + "'";
                int intRowCount = pFiberCableFC.FeatureCount(pCableFil);
                if (intRowCount > 0)
                {
                    IFeatureCursor pCableFeaCur = pFiberCableFC.Search(pCableFil, false);
                    if (pCableFeaCur != null)
                    {
                        IFeature pCableFeature = pCableFeaCur.NextFeature();
                        while (pCableFeature != null)
                        {
                            totalCableLength = totalCableLength + Convert.ToDouble(pCableFeature.get_Value(pCableFeature.Fields.FindField("SHAPE.STLength()")));
                            if(intRowCount > 1)
                                geometriesToUnion.AddGeometry(pCableFeature.Shape as IGeometry);
                            pFeature = pCableFeature;
                            SpatialFilter pSpl = new SpatialFilterClass();
                            pSpl.Geometry = pFeature.Shape;
                            pSpl.SpatialRel = esriSpatialRelEnum.esriSpatialRelIntersects;
                            int intPLRowCount = pPatchLocationFC.FeatureCount(pSpl);
                            if (intPLRowCount > 0)
                            {
                                if (intPLRowCount == 2)
                                {
                                    IFeatureCursor pPLFeaCur = pPatchLocationFC.Search(pSpl, false);
                                    if (pPLFeaCur != null)
                                    {
                                        IFeature pPLFeature = pPLFeaCur.NextFeature();
                                        while (pPLFeature != null)
                                        {
                                            if (pCable1Fea == null)
                                            {
                                                pCable1Fea = pCableFeature;
                                            }
                                            else if (pCable2Fea == null)
                                            {
                                                pCable2Fea = pCableFeature;
                                            }

                                            if (string.IsNullOrEmpty(PL1Name))
                                            {
                                                PL1Name = pPLFeature.get_Value(pPLFeature.Fields.FindField("NAME")).ToString();
                                            }
                                            else if (string.IsNullOrEmpty(PL2Name))
                                            {
                                                PL2Name = pPLFeature.get_Value(pPLFeature.Fields.FindField("NAME")).ToString();
                                            }
                                            //PL1Name = pPLFeature.get_Value(pPLFeature.Fields.FindField("NAME")).ToString();
                                            pPLFeature = pPLFeaCur.NextFeature();
                                        }
                                        Marshal.ReleaseComObject(pPLFeaCur);
                                    }
                                }
                                else
                                {
                                    if (pCable1Fea == null)
                                    {
                                        pCable1Fea = pCableFeature;
                                        IFeatureCursor pPLFeaCur = pPatchLocationFC.Search(pSpl, false);
                                        if (pPLFeaCur != null)
                                        {
                                            IFeature pPLFeature = pPLFeaCur.NextFeature();
                                            while (pPLFeature != null)
                                            {
                                                PL1Name = pPLFeature.get_Value(pPLFeature.Fields.FindField("NAME")).ToString();
                                                pPLFeature = pPLFeaCur.NextFeature();
                                            }
                                            Marshal.ReleaseComObject(pPLFeaCur);
                                        }
                                    }
                                    else if (pCable2Fea == null)
                                    {
                                        pCable2Fea = pCableFeature;
                                        IFeatureCursor pPLFeaCur = pPatchLocationFC.Search(pSpl, false);
                                        if (pPLFeaCur != null)
                                        {
                                            IFeature pPLFeature = pPLFeaCur.NextFeature();
                                            while (pPLFeature != null)
                                            {
                                                PL2Name = pPLFeature.get_Value(pPLFeature.Fields.FindField("NAME")).ToString();
                                                pPLFeature = pPLFeaCur.NextFeature();
                                            }
                                            Marshal.ReleaseComObject(pPLFeaCur);
                                        }
                                    }
                                }
                            }
                            if (intPLRowCount == 0)
                            {
                              int  intPTRowCount = pPTLocationFC.FeatureCount(pSpl);

                              if (intPTRowCount == 2)
                                {
                                    IFeatureCursor pPTFeaCur = pPTLocationFC.Search(pSpl, false);
                                    if (pPTFeaCur != null)
                                    {
                                        IFeature pPTFeature = pPTFeaCur.NextFeature();
                                        while (pPTFeature != null)
                                        {
                                            if (pCable1Fea == null)
                                            {
                                                pCable1Fea = pCableFeature;
                                            }
                                            else if (pCable2Fea == null)
                                            {
                                                pCable2Fea = pCableFeature;
                                            }

                                            if (string.IsNullOrEmpty(PL1Name))
                                            {
                                                PL1Name = pPTFeature.get_Value(pPTFeature.Fields.FindField("NAME")).ToString();
                                            }
                                            else if (string.IsNullOrEmpty(PL2Name))
                                            {
                                                PL2Name = pPTFeature.get_Value(pPTFeature.Fields.FindField("NAME")).ToString();
                                            }
                                            //PL1Name = pPLFeature.get_Value(pPLFeature.Fields.FindField("NAME")).ToString();
                                            pPTFeature = pPTFeaCur.NextFeature();
                                        }
                                        Marshal.ReleaseComObject(pPTFeaCur);
                                    }
                                }
                                else
                                {
                                    if (pCable1Fea == null)
                                    {
                                        pCable1Fea = pCableFeature;
                                        IFeatureCursor pPTFeaCur = pPTLocationFC.Search(pSpl, false);
                                        if (pPTFeaCur != null)
                                        {
                                            IFeature pPTFeature = pPTFeaCur.NextFeature();
                                            while (pPTFeature != null)
                                            {
                                                PL1Name = pPTFeature.get_Value(pPTFeature.Fields.FindField("NAME")).ToString();
                                                pPTFeature = pPTFeaCur.NextFeature();
                                            }
                                            Marshal.ReleaseComObject(pPTFeaCur);
                                        }
                                    }
                                    else if (pCable2Fea == null)
                                    {
                                        pCable2Fea = pCableFeature;
                                        IFeatureCursor pPTFeaCur = pPatchLocationFC.Search(pSpl, false);
                                        if (pPTFeaCur != null)
                                        {
                                            IFeature pPTFeature = pPTFeaCur.NextFeature();
                                            while (pPTFeature != null)
                                            {
                                                PL2Name = pPTFeature.get_Value(pPTFeature.Fields.FindField("NAME")).ToString();
                                                pPTFeature = pPTFeaCur.NextFeature();
                                            }
                                            Marshal.ReleaseComObject(pPTFeaCur);
                                        }
                                    }
                                }
                            }

                            pCableFeature = pCableFeaCur.NextFeature();
                        }
                        if (intRowCount > 1)
                            resultPolyline.ConstructUnion(geometriesToUnion as IEnumGeometry);
                        else
                        {
                            if(pCable1Fea!=null)
                                resultPolyline = pCable1Fea.Shape as ITopologicalOperator;
                        }
                        Marshal.ReleaseComObject(pCableFeaCur);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Trace OTDR
        /// </summary>
        private void btnTrace_Click(object sender, EventArgs e)
        {
            if (ValidationChecks())
            {
                string fromORto = string.Empty;
                pPolyLine = new PolylineClass();

                IPoint point1 = new PointClass();
                IPoint point2 = new PointClass();
                point1 = null;
                point2 = null;
                fromPoint1 = new PointClass();
                fromPoint2 = new PointClass();
                toPoint1 = new PointClass();
                toPoint2 = new PointClass();
                fromPoint1 = null;
                fromPoint2 = null;
                toPoint1 = null;
                toPoint2 = null;
                string point1Side = string.Empty;
                string point2Side = string.Empty;

                if (graphicsContainer != null)
                {
                    graphicsContainer.DeleteAllElements();
                }
                else
                    graphicsContainer = (IGraphicsContainer)pMap;
                
                Boolean isAsideConnected = CheckAsideConnected();
                Boolean isBsideConnected = CheckBsideConnected();
                if (isAsideConnected == true && isBsideConnected == true)
                {
                    IPolyline pPline = (IPolyline)resultPolyline;
                    pPolyLine = pPline;
                    ICurve pCurve = resultPolyline as ICurve;
                    IPoint inPoint = new PointClass();
                    fromORto = string.Empty;
                    if (CheckConnectedPoint(pPline.FromPoint))
                    {
                        double dist = 0.0;
                        if (lblCable1.Text.Contains(PLName))
                        {
                            dist = Convert.ToDouble(txtDistance1.Text);
                            point1Side = "A";
                            PL1Name = PLName;
                        }
                        else if (lblCable2.Text.Contains(PLName))
                        {
                            dist = Convert.ToDouble(txtDistance2.Text);
                            point1Side = "B";
                            PL2Name = PLName;
                        }
                        ICurve subCurve = null;
                        pCurve.GetSubcurve(0.0, dist, false, out subCurve);
                        //if (string.IsNullOrEmpty(txtReservedLength1.Text.Trim()))
                        DrawLine(subCurve, "Red");
                        IPolyline pExtentPline = new PolylineClass();
                        pExtentPline = (IPolyline)subCurve;
                        point1 = pExtentPline.ToPoint;
                    }
                    if (CheckConnectedPoint(pPline.ToPoint))
                    {
                        pCurve.ReverseOrientation();
                        double dist = 0.0;
                        if (lblCable1.Text.Contains(PLName))
                        {
                            dist = Convert.ToDouble(txtDistance1.Text);
                            point2Side = "A";
                            PL1Name = PLName;
                        }
                        else if (lblCable2.Text.Contains(PLName))
                        {
                            dist = Convert.ToDouble(txtDistance2.Text);
                            point2Side = "B";
                            PL2Name = PLName;
                        }
                        ICurve subCurve = null;
                        pCurve.GetSubcurve(0.0, dist, false, out subCurve);
                        //if (string.IsNullOrEmpty(txtReservedLength2.Text.Trim()))
                        DrawLine(subCurve, "Red");
                        IPolyline pExtentPline = new PolylineClass();
                        pExtentPline = (IPolyline)subCurve;
                        point2 = pExtentPline.ToPoint;
                    }

                    fromPoint1 = point1;
                    toPoint1 = point2;
                    DrawCircle(false, point1, point2, pPolyLine, point1Side, point2Side);
                    
                    DrawPoly(false, point1, point2);
                    pCurve.ReverseOrientation();
                    //if (!string.IsNullOrEmpty(txtReservedLength1.Text.Trim()) && !string.IsNullOrEmpty(txtReservedLength2.Text.Trim()))
                    //{
                        TraceWithReserved();
                    //}
                }
                else
                    MessageBox.Show("Entered stand number is invalid or not connected.", "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /// <summary>
        /// Get curve between two locations
        /// </summary>
        private IPolyline GetSubCurve(IPolyline inpolyLine, IPoint pnt1, IPoint pnt2)
        {
            double d1 = GetDistAlong(inpolyLine, pnt1);
            double d2 = GetDistAlong(inpolyLine, pnt2);

            var c = inpolyLine as ICurve;
            ICurve outCurve;
            c.GetSubcurve(d1, d2, false, out outCurve);
            if (c == null || c.IsEmpty)
                throw new Exception("unable to get subcurve");
            var outPolyline = outCurve as IPolyline;
            if (outPolyline == null)
            {
                // this didn't happen in testing, but one never knows ...
                outPolyline = new PolylineClass() as IPolyline;
                var sc = outPolyline as ISegmentCollection;
                sc.AddSegment((ISegment)outCurve);
                ((IGeometry)sc).SpatialReference = outCurve.SpatialReference;
            }
            return outPolyline;
        }

        /// <summary>
        /// Get curve distance 
        /// </summary>
        private double GetDistAlong(IPolyline polyLine, IPoint pnt)
        {
            var outPnt = new PointClass() as IPoint;
            double distAlong = double.NaN;
            double distFrom = double.NaN;
            bool bRight = false;
            polyLine.QueryPointAndDistance(esriSegmentExtension.esriNoExtension, pnt, false, outPnt,
                ref distAlong, ref distFrom, ref bRight);
            return distAlong;
        }

        /// <summary>
        /// OTDR trace using reserved length
        /// </summary>
        private void TraceWithReserved()
        {
            try
            {
                IPolyline pPline = (IPolyline)resultPolyline;
                ICurve pCurve = resultPolyline as ICurve;
                IPoint inPoint = new PointClass();
                IPoint point1 = new PointClass();
                IPoint point2 = new PointClass();
                string point1Side = string.Empty;
                string point2Side = string.Empty;
                inPoint = null;
                point1 = null;
                point2 = null;
                double frmPtDist = 0.0;
                double toPtDist = 0.0;
                if (CheckConnectedPoint(pPline.FromPoint))
                {
                    //double dist = Convert.ToDouble(txtDistance1.Text);
                    double dist = 0.0;
                    if (lblCable1.Text.Contains(PLName))
                    {
                        dist = Convert.ToDouble(txtDistance1.Text);
                        if (!string.IsNullOrEmpty(txtReservedLength1.Text.Trim()))
                        {
                            double reserveDist = Convert.ToDouble(txtReservedLength1.Text);
                            dist = dist - reserveDist;
                            frmPtDist = dist;
                        }
                        point1Side = "A";
                        PL1Name = PLName;
                    }
                    else if (lblCable2.Text.Contains(PLName))
                    {
                        dist = Convert.ToDouble(txtDistance2.Text);
                        if (!string.IsNullOrEmpty(txtReservedLength2.Text.Trim()))
                        {
                            double reserveDist = Convert.ToDouble(txtReservedLength2.Text);
                            dist = dist - reserveDist;
                            frmPtDist = dist;
                        }
                        point1Side = "B";
                        PL2Name = PLName;
                    }
                    //if (!string.IsNullOrEmpty(txtReservedLength1.Text.Trim()))
                    //{
                    //    double reserveDist = Convert.ToDouble(txtReservedLength1.Text);                        
                    //    dist = dist - reserveDist;
                    //}
                    if (frmPtDist > 0)
                    {
                        ICurve subCurve = null;
                        pCurve.GetSubcurve(0.0, dist, false, out subCurve);
                        //DrawLine(subCurve, "Red");
                        IPolyline pExtentPline = new PolylineClass();
                        pExtentPline = (IPolyline)subCurve;
                        point1 = pExtentPline.ToPoint;
                    }
                    else
                        point1 = null;
                }
                if (CheckConnectedPoint(pPline.ToPoint))
                {
                    pCurve.ReverseOrientation();
                    double dist = 0.0;
                    //double dist = Convert.ToDouble(txtDistance2.Text);
                    //if (!string.IsNullOrEmpty(txtReservedLength2.Text.Trim()))
                    //{
                    //    double reserveDist = Convert.ToDouble(txtReservedLength2.Text);
                    //    dist = dist - reserveDist;
                    //}
                    if (lblCable1.Text.Contains(PLName))
                    {
                        dist = Convert.ToDouble(txtDistance1.Text);
                        if (!string.IsNullOrEmpty(txtReservedLength1.Text.Trim()))
                        {
                            double reserveDist = Convert.ToDouble(txtReservedLength1.Text);
                            dist = dist - reserveDist;
                            toPtDist = dist;
                        }
                        point2Side = "A";
                        PL1Name = PLName;
                    }
                    else if (lblCable2.Text.Contains(PLName))
                    {
                        dist = Convert.ToDouble(txtDistance2.Text);
                        if (!string.IsNullOrEmpty(txtReservedLength2.Text.Trim()))
                        {
                            double reserveDist = Convert.ToDouble(txtReservedLength2.Text);
                            dist = dist - reserveDist;
                            toPtDist = dist;
                        }
                        point2Side = "B";
                        PL2Name = PLName;
                    }
                    if (toPtDist > 0)
                    {
                        ICurve subCurve = null;
                        pCurve.GetSubcurve(0.0, dist, false, out subCurve);
                        //DrawLine(subCurve, "Red");
                        IPolyline pExtentPline = new PolylineClass();
                        pExtentPline = (IPolyline)subCurve;
                        point2 = pExtentPline.ToPoint;
                    }
                    else
                        point2 = null;
                }

                fromPoint2 = point1;
                toPoint2 = point2;

                DrawCircle(true, point1, point2, pPolyLine, point1Side, point2Side);
                fromPoint2 = point1;
                toPoint2 = point2;
                DrawPoly(true, point1, point2);
                pCurve.ReverseOrientation();
            }
            catch
            {
            }
        }

        /// <summary>
        /// Mark circle on traced end points
        /// </summary>
        private void DrawCircle(Boolean isReserve, IPoint point1, IPoint point2, IPolyline polyLine, string point1Side, string point2Side)
        {
            try
            {
                var newRgbColor = default(IRgbColor);
                ISimpleLineSymbol lineSymbol = new SimpleLineSymbol();

                //Create a new color marker symbol of the color black;
                if (isReserve == false)
                {
                    newRgbColor = new RgbColor();
                    newRgbColor.Red = 0;
                    newRgbColor.Green = 255;
                    newRgbColor.Blue = 0;
                }
                else
                {
                    newRgbColor = new RgbColor();
                    newRgbColor.Red = 0;
                    newRgbColor.Green = 0;
                    newRgbColor.Blue = 255;
                }

                //Create a new line symbol so that we can set the width outline
                lineSymbol = new SimpleLineSymbol();
                lineSymbol.Color = newRgbColor;
                lineSymbol.Style = esriSimpleLineStyle.esriSLSSolid;
                lineSymbol.Width = 2;

                //var simpleFilleSymbol = default(ISimpleFillSymbol);
                //simpleFilleSymbol = new SimpleFillSymbol();
                //simpleFilleSymbol.Color = newRgbColor;
                //simpleFilleSymbol.Style = esriSimpleFillStyle.esriSFSSolid;
                //simpleFilleSymbol.Outline = lineSymbol;
                ////fillShapeElement.Symbol = simpleFilleSymbol;

                //ISymbol symbol = (ISymbol)simpleFilleSymbol;

                if (point1 != null)
                {
                    //create circle element
                    var pCircleLineElement1 = new LineElementClass();
                    pCircleLineElement1.Symbol = lineSymbol;
                    IElement pCircleElement1 = (IElement)pCircleLineElement1;
                    IConstructCircularArc pCircularArc1 = new CircularArcClass();
                    pCircularArc1.ConstructCircle(point1, 1, true);
                    ISegment Seg1 = (ISegment)pCircularArc1;
                    ISegmentCollection SegCollection1 = (ISegmentCollection)new Polyline();
                    SegCollection1.AddSegment(Seg1, Type.Missing, Type.Missing);
                    pCircleElement1.Geometry = ((IGeometry)SegCollection1);
                    //add the element to the map and draw it.
                    graphicsContainer.AddElement(pCircleElement1, 0);

                    if (isReserve == false)
                    {
                        ITextElement pTextElement1 = new TextElementClass();
                        if (point1Side == "A")
                            pTextElement1.Text = "OTDR-" + PL1Name;
                        else
                            pTextElement1.Text = "OTDR-" + PL2Name;
                        pTextElement1.ScaleText = true;
                        IElement pElement1 = pTextElement1 as IElement;
                        pElement1.Geometry = point1;
                        graphicsContainer.AddElement(pElement1, 0);

                        //ITransform2D pTwoD = pElement1 as ITransform2D;
                        //pTwoD.Rotate(point1, 79);
                    }
                    else
                    {
                        ITextElement pTextElement1 = new TextElementClass();
                        if (point1Side == "A")
                            pTextElement1.Text = "Reserved-" + PL1Name;
                        else
                            pTextElement1.Text = "Reserved-" + PL2Name;
                        pTextElement1.ScaleText = true;
                        IElement pElement1 = pTextElement1 as IElement;
                        pElement1.Geometry = point1;
                        graphicsContainer.AddElement(pElement1, 0);
                    }
                }


                if (point2 != null)
                {
                    //create circle element
                    var pCircleLineElement2 = new LineElementClass();
                    pCircleLineElement2.Symbol = lineSymbol;
                    IElement pCircleElement2 = (IElement)pCircleLineElement2;
                    IConstructCircularArc pCircularArc2 = new CircularArcClass();
                    pCircularArc2.ConstructCircle(point2, 1, true);
                    ISegment Seg2 = (ISegment)pCircularArc2;
                    ISegmentCollection SegCollection2 = (ISegmentCollection)new Polyline();
                    SegCollection2.AddSegment(Seg2, Type.Missing, Type.Missing);
                    pCircleElement2.Geometry = ((IGeometry)SegCollection2);
                    //add the element to the map and draw it.
                    graphicsContainer.AddElement(pCircleElement2, 0);

                    if (isReserve == false)
                    {
                        ITextElement pTextElement2 = new TextElementClass();
                        //pTextElement2.Text = "OTDR-B";
                        if (point2Side == "A")
                            pTextElement2.Text = "OTDR-" + PL1Name;
                        else
                            pTextElement2.Text = "OTDR-" + PL2Name;
                        pTextElement2.ScaleText = true;
                        IElement pElement2 = pTextElement2 as IElement;
                        pElement2.Geometry = point2;
                        graphicsContainer.AddElement(pElement2, 0);
                    }
                    else
                    {
                        ITextElement pTextElement2 = new TextElementClass();
                        //pTextElement2.Text = "Reserved-B";
                        if (point2Side == "A")
                            pTextElement2.Text = "Reserved-" + PL1Name;
                        else
                            pTextElement2.Text = "Reserved-" + PL2Name;
                        pTextElement2.ScaleText = true;
                        IElement pElement2 = pTextElement2 as IElement;
                        pElement2.Geometry = point2;
                        graphicsContainer.AddElement(pElement2, 0);
                    }
                }

                if (isReserve == false)
                {
                    if (polyLine != null)
                    {
                        if (fromPoint1 != null && toPoint1 != null)
                        {
                            var subCurve = GetSubCurve(polyLine, fromPoint1, toPoint1);
                            DrawLine(subCurve, "Green");
                        }
                    }
                }
                else
                {
                    if (polyLine != null)
                    {
                        if (fromPoint1 != null && fromPoint2 != null)
                        {
                            var subCurve = GetSubCurve(polyLine, fromPoint1, fromPoint2);
                            DrawLine(subCurve, "Blue");
                        }
                        if (toPoint1 != null && toPoint2 != null)
                        {
                            var subCurve = GetSubCurve(polyLine, toPoint1, toPoint2);
                            DrawLine(subCurve, "Blue");
                        }
                    }
                }

                pActiveView.Refresh();
            }
            catch
            {
            }
        }

        private void DrawPoly(Boolean isReserve, IPoint point1, IPoint point2)
        {
            try
            {
                ILine pExtentLine = new LineClass();
                pExtentLine.PutCoords(point1, point2);

                IEnvelope env = pExtentLine.Envelope;
                env.Expand(1.5, 1.5, true);

                //IPolygon pPolyGon = new PolygonClass();
                //ISegmentCollection seColl = pPolyGon as ISegmentCollection;
                //seColl.SetRectangle(env);


                //var fillShapeElement = default(IFillShapeElement);
                //var element = default(IElement);
                //var simpleFilleSymbol = default(ISimpleFillSymbol);
                //var newRgbColor = default(IRgbColor);
                //var lineSymbol = default(ILineSymbol);

                ////Use the IElement interface to set the Envelope Element's geo
                //element = new PolygonElement();
                //element.Geometry = pPolyGon;

                ////QI for the IFillShapeElement interface so that the symbol property can be set
                //fillShapeElement = element as IFillShapeElement;

                ////Create a new fill symbol
                //simpleFilleSymbol = new SimpleFillSymbol();

                ////Create a new color marker symbol of the color black;
                //if (isReserve == false)
                //{
                //    newRgbColor = new RgbColor();
                //    newRgbColor.Red = 0;
                //    newRgbColor.Green = 255;
                //    newRgbColor.Blue = 0;
                //}
                //else
                //{
                //    newRgbColor = new RgbColor();
                //    newRgbColor.Red = 0;
                //    newRgbColor.Green = 0;
                //    newRgbColor.Blue = 255;
                //}

                ////Create a new line symbol so that we can set the width outline
                //lineSymbol = new SimpleLineSymbol();
                //lineSymbol.Color = newRgbColor;
                //lineSymbol.Width = 2;

                ////Setup the Simple Fill Symbol
                //simpleFilleSymbol.Color = newRgbColor;
                //simpleFilleSymbol.Style = esriSimpleFillStyle.esriSFSHollow;
                //simpleFilleSymbol.Outline = lineSymbol;
                //fillShapeElement.Symbol = simpleFilleSymbol;

                ////Add the new element at Z order 0
                //graphicsContainer.AddElement((IElement)fillShapeElement, 0);
                pActiveView.Extent = env;
                pActiveView.Refresh();
            }
            catch
            {
            }
        }

        /// <summary>
        /// Check the form values.
        /// </summary>
        private Boolean ValidationChecks()
        {
            if (cboCables.Text == "--Enter Cable Name--" || string.IsNullOrEmpty(cboCables.Text))
            {
                MessageBox.Show("Please select cable.", "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (string.IsNullOrEmpty(txtStrandNo.Text.Trim()))
            {
                MessageBox.Show("Please enter strand number", "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (lblCable1.Text == "No PL" && lblCable2.Text == "No PL")
            {
                MessageBox.Show("Cable is not connected to any of the patchlocation from both the ends", "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (lblCable1.Text == "No PL")
            {
                MessageBox.Show("Cable is not connected to any patchlocation at from end", "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (lblCable2.Text == "No PL")
            {
                MessageBox.Show("Cable is not connected to any patchlocation at to end", "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (string.IsNullOrEmpty(txtDistance1.Text.Trim()))
            {
                MessageBox.Show("Please enter " + lblCable1.Text + " distance.", "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (string.IsNullOrEmpty(txtDistance2.Text.Trim()))
            {
                MessageBox.Show("Please enter " + lblCable2.Text + " distance.", "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (Convert.ToDouble(txtDistance1.Text.Trim()) > totalCableLength)
            {
                MessageBox.Show("Distance should not be greater than cable length. Please check again.", "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (Convert.ToDouble(txtDistance2.Text.Trim()) > totalCableLength)
            {
                MessageBox.Show("Distance should not be greater than cable length. Please check again.", "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            double dist1 = Convert.ToDouble(txtDistance1.Text);
            if (dist1 < 1)
            {
                MessageBox.Show("Distance should be greater than zero. Please enter again.", "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (!string.IsNullOrEmpty(txtReservedLength1.Text.Trim()))
            {
                double reserveDist1 = Convert.ToDouble(txtReservedLength1.Text);
                if (reserveDist1 >= dist1)
                {
                    MessageBox.Show("Reserved length should be less than distance. Please check again.", "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }
            }
            double dist2 = Convert.ToDouble(txtDistance2.Text);
            if (dist2 < 1)
            {
                MessageBox.Show("Distance should be greater than zero. Please enter again.", "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (!string.IsNullOrEmpty(txtReservedLength2.Text.Trim()))
            {
                double reserveDist2 = Convert.ToDouble(txtReservedLength2.Text);
                if (reserveDist2 >= dist2)
                {
                    MessageBox.Show("Reserved length should be less than distance. Please check again.", "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Check A side connectivity
        /// </summary>
        private Boolean CheckAsideConnected()
        {
            Boolean isConnected = false;
            if(!string.IsNullOrEmpty(cable1GlobalId))
                isConnected = CheckConnection(GetCable1StrandGlobalID(cable1GlobalId, txtStrandNo.Text));
            return isConnected;
        }

        /// <summary>
        /// Check B side connectivity
        /// </summary>
        private Boolean CheckBsideConnected()
        {
            Boolean isConnected = false;
            if (!string.IsNullOrEmpty(cable2GlobalId))
                isConnected = CheckConnection(GetCable1StrandGlobalID(cable2GlobalId, txtStrandNo.Text));
            return isConnected;
        }

        /// <summary>
        /// Get cable strand global id
        /// </summary>
        /// <param name="cableID">Cable global id</param>
        /// <param name="strandNumber">Strand number</param>
        private string GetCable1StrandGlobalID(string cableID, string strandNumber)
        {
            string strandID = string.Empty;
            QueryFilter pBufferTubeFil = new QueryFilterClass();
            pBufferTubeFil.WhereClause = "FIBERPARENT = '" + cableID + "'";
            int rowCount = pF_BuffertubeTable.RowCount(pBufferTubeFil);
            if (rowCount > 0)
            {
                ICursor pBufferRowCur = pF_BuffertubeTable.Search(pBufferTubeFil, false);
                if (pBufferRowCur != null)
                {
                    IRow pBufferRow = pBufferRowCur.NextRow();
                    while (pBufferRow != null)
                    {
                        string bufferTubeGlobalId = pBufferRow.get_Value(pBufferRow.Fields.FindField("GlobalID")).ToString();

                        QueryFilter pFiberFil = new QueryFilterClass();
                        pFiberFil.WhereClause = "FIBERPARENT = '" + bufferTubeGlobalId + "' AND FIBERNUMBER = " + strandNumber;
                        int fiberRowCount = pF_FiberTable.RowCount(pFiberFil);
                        if (fiberRowCount > 0)
                        {
                            ICursor pFiberRowCur = pF_FiberTable.Search(pFiberFil, false);
                            if (pFiberRowCur != null)
                            {
                                IRow pFiberRow = pFiberRowCur.NextRow();
                                while (pFiberRow != null)
                                {
                                    strandID = pFiberRow.get_Value(pFiberRow.Fields.FindField("GlobalID")).ToString();
                                    pFiberRow = pFiberRowCur.NextRow();
                                }
                                Marshal.ReleaseComObject(pFiberRowCur);
                            }
                        }

                        pBufferRow = pBufferRowCur.NextRow();
                    }
                    Marshal.ReleaseComObject(pBufferRowCur);
                }
            }

            return strandID;
        }

        /// <summary>
        /// Check the connectivity
        /// </summary>
        /// <param name="fiberGlobalID">Strand global id</param>
        private Boolean CheckConnection(string fiberGlobalID)
        {
            try
            {
                Boolean isConnected = false;
                if (pF_FIBERCONNECTIONOBJECT != null)
                {
                    QueryFilter pConneFil = new QueryFilterClass();
                    pConneFil.WhereClause = "ACONNECTIONOBJECTGLOBALID = '" + fiberGlobalID + "' OR BCONNECTIONOBJECTGLOBALID = '" + fiberGlobalID + "'";
                    int intRowCount = pF_FIBERCONNECTIONOBJECT.RowCount(pConneFil);
                    if (intRowCount > 0)
                    {
                        ICursor pConnRowCur = pF_FIBERCONNECTIONOBJECT.Search(pConneFil, false);
                        if (pConnRowCur != null)
                        {
                            IRow pConnRow = pConnRowCur.NextRow();
                            while (pConnRow != null)
                            {
                                if (pConnRow.get_Value(pConnRow.Fields.FindField("ACONNECTIONOBJECTGLOBALID")).ToString() == fiberGlobalID)
                                {
                                    if (pConnRow.get_Value(pConnRow.Fields.FindField("BCLASSMODELNAME")).ToString() == "PATCHPANELBACKSIDEPORT")
                                    {
                                        string PLName = GetName(pConnRow.get_Value(pConnRow.Fields.FindField("BCONNECTIONOBJECTGLOBALID")).ToString(), "Back");
                                        if (PLName == PL1Name || PLName == PL2Name)
                                        {
                                            isConnected = true;
                                        }
                                        else
                                        {
                                            isConnected = false;
                                        }
                                    }
                                    if (pConnRow.get_Value(pConnRow.Fields.FindField("BCLASSMODELNAME")).ToString() == "PATCHPANELFRONTSIDEPORT")
                                    {
                                        string PLName = GetName(pConnRow.get_Value(pConnRow.Fields.FindField("BCONNECTIONOBJECTGLOBALID")).ToString(), "Front");
                                        if (PLName == PL1Name || PLName == PL2Name)
                                        {
                                            isConnected = true;
                                        }
                                        else
                                        {
                                            isConnected = false;
                                        }
                                    }

                                    if (pConnRow.get_Value(pConnRow.Fields.FindField("BCLASSMODELNAME")).ToString() == "PTBACKSIDEPORT")
                                    {
                                        string PLName = GetName(pConnRow.get_Value(pConnRow.Fields.FindField("BCONNECTIONOBJECTGLOBALID")).ToString(), "Back");
                                        if (PLName == PL1Name || PLName == PL2Name)
                                        {
                                            isConnected = true;
                                        }
                                        else
                                        {
                                            isConnected = false;
                                        }
                                    }
                                    if (pConnRow.get_Value(pConnRow.Fields.FindField("BCLASSMODELNAME")).ToString() == "PTFRONTSIDEPORT")
                                    {
                                        string PLName = GetName(pConnRow.get_Value(pConnRow.Fields.FindField("BCONNECTIONOBJECTGLOBALID")).ToString(), "Back");
                                        if (PLName == PL1Name || PLName == PL2Name)
                                        {
                                            isConnected = true;
                                        }
                                        else
                                        {
                                            isConnected = false;
                                        }
                                    }
                                }
                                if (pConnRow.get_Value(pConnRow.Fields.FindField("BCONNECTIONOBJECTGLOBALID")).ToString() == fiberGlobalID)
                                {
                                    if (pConnRow.get_Value(pConnRow.Fields.FindField("ACLASSMODELNAME")).ToString() == "PATCHPANELBACKSIDEPORT")
                                    {
                                        string PLName = GetName(pConnRow.get_Value(pConnRow.Fields.FindField("ACONNECTIONOBJECTGLOBALID")).ToString(), "Back");
                                        if (PLName == PL1Name || PLName == PL2Name)
                                        {
                                            isConnected = true;
                                        }
                                        else
                                        {
                                            isConnected = false;
                                        }
                                    }
                                    if (pConnRow.get_Value(pConnRow.Fields.FindField("ACLASSMODELNAME")).ToString() == "PATCHPANELFRONTSIDEPORT")
                                    {
                                        string PLName = GetName(pConnRow.get_Value(pConnRow.Fields.FindField("ACONNECTIONOBJECTGLOBALID")).ToString(), "Front");
                                        if (PLName == PL1Name || PLName == PL2Name)
                                        {
                                            isConnected = true;
                                        }
                                        else
                                        {
                                            isConnected = false;
                                        }
                                    }

                                    if (pConnRow.get_Value(pConnRow.Fields.FindField("ACLASSMODELNAME")).ToString() == "PTBACKSIDEPORT")
                                    {
                                        string PLName = GetName(pConnRow.get_Value(pConnRow.Fields.FindField("ACONNECTIONOBJECTGLOBALID")).ToString(), "Back");
                                        if (PLName == PL1Name || PLName == PL2Name)
                                        {
                                            isConnected = true;
                                        }
                                        else
                                        {
                                            isConnected = false;
                                        }
                                    }
                                    if (pConnRow.get_Value(pConnRow.Fields.FindField("ACLASSMODELNAME")).ToString() == "PTFRONTSIDEPORT")
                                    {
                                        string PLName = GetName(pConnRow.get_Value(pConnRow.Fields.FindField("ACONNECTIONOBJECTGLOBALID")).ToString(), "Front");
                                        if (PLName == PL1Name || PLName == PL2Name)
                                        {
                                            isConnected = true;
                                        }
                                        else
                                        {
                                            isConnected = false;
                                        }
                                    }
                                }
                                pConnRow = pConnRowCur.NextRow();
                            }
                            Marshal.ReleaseComObject(pConnRowCur);
                        }
                    }
                }
                return isConnected;
            }
            catch(Exception ex)
            {
                //MessageBox.Show("CheckConnection : " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// Get Patch location name
        /// </summary>
        /// <param name="gID">Port global id</param>
        /// <param name="side">Port side (Back/Front)</param>
        private string GetName(string gID, string side)
        {
            try
            {
                string PLName = string.Empty;
                string rackName = string.Empty;
                string cardName = string.Empty;
                string portNum = string.Empty;
                QueryFilter pFil = new QueryFilterClass();
                pFil.WhereClause = "GLOBALID = '" + gID + "'";
                int rowCount = pF_BACKSIDEPORT.RowCount(pFil);
                if (rowCount == 0)
                {
                    rowCount = pF_PTBACKSIDEPORT.RowCount(pFil);
                }
                if (rowCount > 0)
                {
                    string portDetails = GetPortNum(gID, side);
                    if (!string.IsNullOrEmpty(portDetails))
                    {
                        portNum = portDetails.Split(';')[0].ToString();
                        string CardDetails = GetCardName(portDetails.Split(';')[1].ToString());
                        if (!string.IsNullOrEmpty(CardDetails))
                        {
                            cardName = CardDetails.Split(';')[0].ToString();
                            string PatchPanelDetails = GetPatchPanelDetails(CardDetails.Split(';')[1].ToString());
                            if (!string.IsNullOrEmpty(PatchPanelDetails))
                            {
                                rackName = PatchPanelDetails.Split(';')[0].ToString();
                                string RackDetails = GetRackName(PatchPanelDetails.Split(';')[1].ToString());
                                if (!string.IsNullOrEmpty(RackDetails))
                                {
                                    PLName = GetPLName(RackDetails.Split(';')[1].ToString());
                                }
                            }
                        }
                        if (CardDetails=="")
                        {
                            string PTPanelDetails = GetPatchPanelDetails(portDetails.Split(';')[1].ToString());
                            if (!string.IsNullOrEmpty(PTPanelDetails))
                            {
                                PLName = GetPLName(PTPanelDetails.Split(';')[1].ToString());
                            }
                        }
                    }
                }
                return PLName;
            }
            catch (Exception ex)
            {
                //MessageBox.Show("GetName : " + ex.Message);
                return string.Empty;
            }
        }

        /// <summary>
        /// Get port number
        /// </summary>
        /// <param name="PortGlobalID">Port global Id</param>
        /// <param name="side">Direction</param>
        /// <returns>Port number</returns>
        private string GetPortNum(string PortGlobalID, string side)
        {
            try
            {
                string portDetails = string.Empty;
                QueryFilter pPortFil = new QueryFilterClass();
                pPortFil.WhereClause = "GlobalID = '" + PortGlobalID + "'";
                int intRowCount = 0;
                if (side == "Back")
                {
                    intRowCount = pF_BACKSIDEPORT.RowCount(pPortFil);
                    if (intRowCount==0)
                    {
                        intRowCount = pF_PTBACKSIDEPORT.RowCount(pPortFil);
                    }
                }
                else
                {
                    intRowCount = pF_FRONTSIDEPORT.RowCount(pPortFil);
                    if (intRowCount == 0)
                    {
                        intRowCount = pF_PTFRONTSIDEPORT.RowCount(pPortFil);
                    }
                }
                if (intRowCount > 0)
                {
                    ICursor pPortRowCur = null;
                    if (side == "Back")
                    {
                        pPortRowCur = pF_BACKSIDEPORT.Search(pPortFil, false);

                        if (pPortRowCur != null)
                        {
                            IRow pPortRow = pPortRowCur.NextRow();
                            if (pPortRow == null)
                            {
                                pPortRowCur = pF_PTBACKSIDEPORT.Search(pPortFil, false);

                                if (pPortRowCur != null)
                                {
                                    pPortRow = pPortRowCur.NextRow();
                                    while (pPortRow != null)
                                    {
                                        portDetails = Convert.ToString(pPortRow.get_Value(pPortRow.Fields.FindField("PORTNUMBER")));
                                        portDetails = portDetails + ";" + Convert.ToString(pPortRow.get_Value(pPortRow.Fields.FindField("FIBERPARENT")));
                                        pPortRow = pPortRowCur.NextRow();
                                    }
                                    Marshal.ReleaseComObject(pPortRowCur);
                                }
                            }
                            else
                            {
                                while (pPortRow != null)
                                {
                                    portDetails = Convert.ToString(pPortRow.get_Value(pPortRow.Fields.FindField("PORTNUMBER")));
                                    portDetails = portDetails + ";" + Convert.ToString(pPortRow.get_Value(pPortRow.Fields.FindField("FIBERPARENT")));
                                    pPortRow = pPortRowCur.NextRow();
                                }
                                Marshal.ReleaseComObject(pPortRowCur);
                            }

                        }
                    }
                    else
                    {
                        pPortRowCur = pF_FRONTSIDEPORT.Search(pPortFil, false);

                        if (pPortRowCur != null)
                        {
                            IRow pPortRow = pPortRowCur.NextRow();
                            if (pPortRow == null)
                            {
                                pPortRowCur = pF_PTFRONTSIDEPORT.Search(pPortFil, false);

                                if (pPortRowCur != null)
                                {
                                    pPortRow = pPortRowCur.NextRow();
                                    while (pPortRow != null)
                                    {
                                        portDetails = Convert.ToString(pPortRow.get_Value(pPortRow.Fields.FindField("PORTNUMBER")));
                                        portDetails = portDetails + ";" + Convert.ToString(pPortRow.get_Value(pPortRow.Fields.FindField("FIBERPARENT")));
                                        pPortRow = pPortRowCur.NextRow();
                                    }
                                    Marshal.ReleaseComObject(pPortRowCur);
                                }
                            }
                            else
                            {
                                while (pPortRow != null)
                                {
                                    portDetails = Convert.ToString(pPortRow.get_Value(pPortRow.Fields.FindField("PORTNUMBER")));
                                    portDetails = portDetails + ";" + Convert.ToString(pPortRow.get_Value(pPortRow.Fields.FindField("FIBERPARENT")));
                                    pPortRow = pPortRowCur.NextRow();
                                }
                                Marshal.ReleaseComObject(pPortRowCur);
                            }
                        }

                    }
                   
                }
                return portDetails;
            }
            catch (Exception ex)
            {
                //MessageBox.Show("GetPortNum : " + ex.Message);
                return string.Empty;
            }
        }

        /// <summary>
        /// Get Patch panel card name
        /// </summary>
        /// <param name="cardGlobalID">Card global Id</param>
        /// <returns>Patch panel card name</returns>
        private string GetCardName(string cardGlobalID)
        {
            try
            {
                string cardDetails = string.Empty;
                QueryFilter pCardFil = new QueryFilterClass();
                pCardFil.WhereClause = "GlobalID = '" + cardGlobalID + "'";
                int intRowCount = pF_PATCHPANELCARD.RowCount(pCardFil);
                if (intRowCount > 0)
                {
                    ICursor pCardRowCur = pF_PATCHPANELCARD.Search(pCardFil, false);
                    if (pCardRowCur != null)
                    {
                        IRow pCardRow = pCardRowCur.NextRow();
                        while (pCardRow != null)
                        {
                            cardDetails = Convert.ToString(pCardRow.get_Value(pCardRow.Fields.FindField("CARDNAME")));
                            cardDetails = cardDetails + ";" + Convert.ToString(pCardRow.get_Value(pCardRow.Fields.FindField("FIBERPARENT")));
                            pCardRow = pCardRowCur.NextRow();
                        }
                        Marshal.ReleaseComObject(pCardRowCur);
                    }
                }
                return cardDetails;
            }
            catch (Exception ex)
            {
                //MessageBox.Show("GetCardName : " + ex.Message);
                return string.Empty;
            }
        }

        /// <summary>
        /// Get Rack name
        /// </summary>
        /// <param name="rackGlobalID">Rack global Id</param>
        /// <returns>Rack name</returns>
        private string GetRackName(string rackGlobalID)
        {
            try
            {
                string rackDetails = string.Empty;
                QueryFilter pRackFil = new QueryFilterClass();
                pRackFil.WhereClause = "GlobalID = '" + rackGlobalID + "'";
                int intRowCount = pF_RACK.RowCount(pRackFil);
                if (intRowCount > 0)
                {
                    ICursor pRackRowCur = pF_RACK.Search(pRackFil, false);
                    if (pRackRowCur != null)
                    {
                        IRow pRackRow = pRackRowCur.NextRow();
                        while (pRackRow != null)
                        {
                            rackDetails = Convert.ToString(pRackRow.get_Value(pRackRow.Fields.FindField("NAME")));
                            rackDetails = rackDetails + ";" + Convert.ToString(pRackRow.get_Value(pRackRow.Fields.FindField("FIBERPARENT")));
                            pRackRow = pRackRowCur.NextRow();
                        }
                        Marshal.ReleaseComObject(pRackRowCur);
                    }
                }
                return rackDetails;
            }
            catch (Exception ex)
            {
                //MessageBox.Show("GetRackName : " + ex.Message);
                return string.Empty;
            }
        }

        /// <summary>
        /// Get patch panel details
        /// </summary>
        /// <param name="ppGlobalID">Patch panel global Id</param>
        /// <returns>Patch panel details</returns>
        private string GetPatchPanelDetails(string ppGlobalID)
        {
            try
            {
                string patchPanelDetails = string.Empty;
                QueryFilter pPPFil = new QueryFilterClass();
                pPPFil.WhereClause = "GlobalID = '" + ppGlobalID + "'";
                int intRowCount = pF_PATCHPANEL.RowCount(pPPFil);
                if (intRowCount > 0)
                {
                    ICursor pPPRowCur = pF_PATCHPANEL.Search(pPPFil, false);
                    if (pPPRowCur != null)
                    {
                        IRow pPPRow = pPPRowCur.NextRow();
                        while (pPPRow != null)
                        {
                            patchPanelDetails = Convert.ToString(pPPRow.get_Value(pPPRow.Fields.FindField("NAME")));
                            patchPanelDetails = patchPanelDetails + ";" + Convert.ToString(pPPRow.get_Value(pPPRow.Fields.FindField("FIBERPARENT")));
                            pPPRow = pPPRowCur.NextRow();
                        }
                        Marshal.ReleaseComObject(pPPRowCur);
                    }
                }
                if (intRowCount == 0)
                {
                    ICursor pPPRowCur = pF_PTPANEL.Search(pPPFil, false);
                    if (pPPRowCur != null)
                    {
                        IRow pPPRow = pPPRowCur.NextRow();
                        while (pPPRow != null)
                        {
                            patchPanelDetails = Convert.ToString(pPPRow.get_Value(pPPRow.Fields.FindField("NAME")));
                            patchPanelDetails = patchPanelDetails + ";" + Convert.ToString(pPPRow.get_Value(pPPRow.Fields.FindField("FIBERPARENT")));
                            pPPRow = pPPRowCur.NextRow();
                        }
                        Marshal.ReleaseComObject(pPPRowCur);
                    }
                }
                return patchPanelDetails;
            }
            catch (Exception ex)
            {
                //MessageBox.Show("GetPatchPanelDetails : " + ex.Message);
                return string.Empty;
            }
        }

        /// <summary>
        /// Get patch location name
        /// </summary>
        /// <param name="plGlobalID">Patch location global Id</param>
        /// <returns>Patch location name</returns>
        private string GetPLName(string plGlobalID)
        {
            try
            {
                string plName = string.Empty;
                QueryFilter pPlFil = new QueryFilterClass();
                pPlFil.WhereClause = "GlobalID = '" + plGlobalID + "'";
                int intRowCount = pPatchLocationFC.FeatureCount(pPlFil);
                if (intRowCount > 0)
                {
                    IFeatureCursor pPlFeaCur = pPatchLocationFC.Search(pPlFil, false);
                    if (pPlFeaCur != null)
                    {
                        IFeature pPlFeature = pPlFeaCur.NextFeature();
                        while (pPlFeature != null)
                        {
                            plName = Convert.ToString(pPlFeature.get_Value(pPlFeature.Fields.FindField("NAME")));
                            pPlFeature = pPlFeaCur.NextFeature();
                        }
                        Marshal.ReleaseComObject(pPlFeaCur);
                    }
                }
                if (intRowCount == 0)
                {
                    intRowCount = pPTLocationFC.FeatureCount(pPlFil);
                    if (intRowCount > 0)
                    {
                        IFeatureCursor pPlFeaCur = pPTLocationFC.Search(pPlFil, false);
                        if (pPlFeaCur != null)
                        {
                            IFeature pPlFeature = pPlFeaCur.NextFeature();
                            while (pPlFeature != null)
                            {
                                plName = Convert.ToString(pPlFeature.get_Value(pPlFeature.Fields.FindField("NAME")));
                                pPlFeature = pPlFeaCur.NextFeature();
                            }
                            Marshal.ReleaseComObject(pPlFeaCur);
                        }
                    }
                }
                return plName;
            }
            catch (Exception ex)
            {
                //MessageBox.Show("GetPLName : " + ex.Message);
                return string.Empty;
            }
        }

        /// <summary>
        /// Check cable from/to point is connected to patch location or not
        /// </summary>
        /// <param name="pPoint">Cable From/To point</param>
        private Boolean CheckConnectedPoint(IPoint pPoint)
        {
            try
            {
                Boolean isConnected = false;
                IGeometry pGeo = (IGeometry)pPoint;
                SpatialFilter pPlFil = new SpatialFilterClass();
                pPlFil.Geometry = pGeo;
                pPlFil.SpatialRel = esriSpatialRelEnum.esriSpatialRelIntersects;
                int intRowCount = pPatchLocationFC.FeatureCount(pPlFil);
                if (intRowCount > 0)
                {
                    IFeatureCursor pPlFeaCur = pPatchLocationFC.Search(pPlFil, false);
                    if (pPlFeaCur != null)
                    {
                        IFeature pPlFeature = pPlFeaCur.NextFeature();
                        while (pPlFeature != null)
                        {
                            PLName = Convert.ToString(pPlFeature.get_Value(pPlFeature.Fields.FindField("NAME")));
                            pPlFeature = pPlFeaCur.NextFeature();
                        }
                        Marshal.ReleaseComObject(pPlFeaCur);
                    }
                    isConnected = true;
                }
                if (intRowCount==0)
                {
                    intRowCount = pPTLocationFC.FeatureCount(pPlFil);
                    if (intRowCount > 0)
                    {
                        IFeatureCursor pPlFeaCur = pPTLocationFC.Search(pPlFil, false);
                        if (pPlFeaCur != null)
                        {
                            IFeature pPlFeature = pPlFeaCur.NextFeature();
                            while (pPlFeature != null)
                            {
                                PLName = Convert.ToString(pPlFeature.get_Value(pPlFeature.Fields.FindField("NAME")));
                                pPlFeature = pPlFeaCur.NextFeature();
                            }
                            Marshal.ReleaseComObject(pPlFeaCur);
                        }
                        isConnected = true;
                    }
                }
                return isConnected;
            }
            catch (Exception ex)
            {
                //MessageBox.Show("CheckConnectedPoint : " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// Draw curve
        /// </summary>
        /// <param name="subCurve">Curve</param>
        /// <param name="drawColor">Color</param>
        private void DrawLine(ICurve subCurve, string drawColor)
        {
            IPolyline polyline = new PolylineClass();
            polyline = (IPolyline)subCurve;

            IRgbColor color = new RgbColorClass();
            if (drawColor == "Red")
            {
                color.Red = 255; color.Blue = 0; color.Green = 0;
            }
            else if (drawColor == "Green")
            {
                color.Red = 0; color.Blue = 0; color.Green = 255;
            }
            else if (drawColor == "Blue")
            {
                color.Red = 0; color.Blue = 255; color.Green = 0;
            }

            ISimpleLineSymbol simpleLineSymbol = new SimpleLineSymbolClass();
            simpleLineSymbol.Color = color;
            simpleLineSymbol.Width = 2;

            if (drawColor == "Red")
            {
                simpleLineSymbol.Style = esriSimpleLineStyle.esriSLSSolid;
            }
            else if (drawColor == "Green")
            {
                simpleLineSymbol.Style = esriSimpleLineStyle.esriSLSDashDotDot;
            }
            else if (drawColor == "Blue")
            {
                simpleLineSymbol.Style = esriSimpleLineStyle.esriSLSDashDot;
            }

            IElement element = new LineElementClass();

            ILineElement markerElement = new LineElementClass();
            markerElement.Symbol = simpleLineSymbol;

            element = (IElement)markerElement;
            element.Geometry = subCurve;
            graphicsContainer.AddElement(element, 0);
        }

        private void txtDistance1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void txtDistance2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void txtReservedLength1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void txtReservedLength2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// When user click on cable combobox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cboCables_MouseClick_1(object sender, MouseEventArgs e)
        {
            //try
            //{
            //    if (cboCables.Text == "--Enter Cable Name--")
            //    {
            //        AutoCompleteStringCollection DataCollection = new AutoCompleteStringCollection();
            //        DataCollection = (AutoCompleteStringCollection)cboCables.DataSource;
            //        int idx = DataCollection.IndexOf("--Enter Cable Name--");
            //        if (idx != -1)
            //            DataCollection.RemoveAt(idx);
            //        cboCables.DataSource = null;
            //        cboCables.SelectedIndex = -1;
            //        cboCables.DataSource = DataCollection;
            //        cboCables.Text = "";
            //    }
            //}
            //catch (Exception exp)
            //{
            //    MessageBox.Show(exp.Message, "CEM OTDR Trace", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
        }

        private void frmCemOTDRTraceSelector_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (graphicsContainer != null)
            {
                graphicsContainer.DeleteAllElements();
                pActiveView.Refresh();
            }
        }

        private void txtStrandNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
    }
}
